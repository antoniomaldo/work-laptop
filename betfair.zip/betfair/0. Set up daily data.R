library(jsonlite)
library(stringr)
library(logger)

TODAYS_DIR <- paste0("C:\\Users\\aostios\\Documents\\betfair\\", Sys.Date())

createTodaysFolder <- function(){
  if(!file.exists(TODAYS_DIR)){
    dir.create(TODAYS_DIR)  
  }
  if(!file.exists(paste0(TODAYS_DIR, "\\graphs"))){
    dir.create(paste0(TODAYS_DIR, "\\graphs"))  
  }
}

getTodaysMarketIds <- function(){
  if(!file.exists(paste0(TODAYS_DIR, "\\races.csv"))){
    
    marketStartingAfter = paste0(Sys.Date(),"T00:00:00.000Z")
    marketStartingBefore = paste0(Sys.Date(),"T23:59:59.999Z")
    
    url = paste0("https://apieds.betfair.com/api/eds/meeting-races/v4?_ak=nzIFcwyWhrlwYMrh&countriesGroup=%5B%5B%22GB%22,%22IE%22%5D%5D&countriesList=%5B%22GB%22,%22IE%22%5D&eventTypeId=7&marketStartingAfter=", marketStartingAfter,"&marketStartingBefore=", marketStartingBefore)
    
    races = read_json(url)
    
    raceList = races[[1]]
    
    meetings = raceList$meetings
    
    racesDf <- data.frame()
    for(meeting in meetings){
      venue <- meeting$venue
      meetingRaces <- meeting$races
      for(meetingRace in meetingRaces){
        marketId <- meetingRace$marketId
        marketId <- str_replace(marketId, pattern = "\\.", "_")
        startTime <- meetingRace$startTime
        racesDf <- rbind(racesDf, data.frame(venue, startTime, marketId))
      }
    }
    write.csv(racesDf, paste0(TODAYS_DIR, "\\races.csv"))
  }
}

getTodaysRacesInfo <- function(){
  if(!file.exists(paste0(TODAYS_DIR, "\\allRacesInfo.csv"))){
    races <- read.csv(paste0(TODAYS_DIR, "\\races.csv"), as.is = T)
    allRacesInfo <- data.frame()
    for(i in 1:nrow(races)){
      raceId <- str_remove_all(races$marketId[i], "'")
      raceId <- str_replace(raceId, "_", ".")
      allRacesInfo <- rbind(allRacesInfo, getEventInformation(raceId))  
    }
    write.csv(allRacesInfo, paste0(paste0(TODAYS_DIR,"\\allRacesInfo.csv")))
  }
}

getEventInformation <- function(marketId){
  url <- paste0("https://ero.betfair.com/www/sports/exchange/readonly/v1/bymarket?_ak=nzIFcwyWhrlwYMrh&alt=json&currencyCode=GBP&locale=en_GB&marketIds=",marketId,"&rollupLimit=1&rollupModel=STAKE&types=MARKET_STATE,MARKET_RATES,MARKET_DESCRIPTION,EVENT,RUNNER_DESCRIPTION,RUNNER_STATE,RUNNER_EXCHANGE_PRICES_BEST,RUNNER_METADATA,MARKET_LICENCE,MARKET_LINE_RANGE_INFO,RUNNER_SP,RUNNER_PRICE_TREND")
  eventData <- read_json(url)$eventTypes[[1]]
  eventNodes <- eventData$eventNodes[[1]]
  
  eventName <- eventNodes$event$venue
  
  runners <- eventNodes$marketNodes[[1]]$runners
  
  runnerIds <- data.frame()
  
  marketIdString <- str_replace(marketId, pattern = "\\.", "_")
  for(runner in runners){
    name <- runner$description$runnerName
    id <- runner$selectionId
    runnerIds <- rbind(runnerIds, data.frame(marketIdString, id, name))
  }
  runnerIds$venue <- eventName
  
  return(runnerIds)
}
createTodaysFolder()

log_info(("Getting races for the day."))
getTodaysMarketIds()

log_info("Getting runners for races")
getTodaysRacesInfo()


#generateGraphsForMarketId("1.223568584")
