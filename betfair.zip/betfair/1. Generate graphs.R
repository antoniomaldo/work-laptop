library(anytime)
library(cli)
source("C:\\Users\\aostios\\Documents\\betfair\\0. Set up daily data.R")

generateGraphsForMarketIdAndSelection <- function(marketId, selectionId){
  url <- paste0("https://graphs.betfair.com/loadRunnerChart?marketId=", marketId, "&selectionId=", selectionId,"&handicap=0&logarithmic=false")
  data <- read_json(url)
  points <- data$points
  
  df <- data.frame()
  for (point in points){
    value <- point$value
    timestamp <- point$timestamp
    volume <- point$volume
    
    df <- rbind(df, data.frame(selectionId, value, timestamp, volume))
  }
  df$priceTime <- anytime(df$timestamp / 1000)
  
  df <- subset(df, df$priceTime > Sys.time() - 60 * 60 * 6)
  return(df)
}

generateGraphsForMarketId <- function(marketId, eventInfo){
  noRunners <- nrow(eventInfo)
  
  if(noRunners %% 3 != 0){
    noRunners <- noRunners + (3 - noRunners %% 3)
  }
  if(noRunners > 11){
    noRunners = 9
  }
  windows(title =  paste0(eventInfo$venue[1], " - ", eventInfo$startTime[1]))
  par(mfrow = c(ceiling(noRunners/3),3))
  allGraphs <- data.frame()
  for(i in 1:min(noRunners, nrow(eventInfo))){
    graph <- generateGraphsForMarketIdAndSelection(marketId, eventInfo$id[i])
    if(nrow(graph)>0){
      plot.ts(graph$value, main=paste0(eventInfo$name[i], " - ", graph$value[nrow(graph)]))
    }
    allGraphs <- rbind(allGraphs, graph)
    marketIdForCsv <- str_replace(marketId, "\\.", "_")
  }
  write.csv(allGraphs, file = paste0(TODAYS_DIR, "\\graphs\\", marketIdForCsv, ".csv"))
}

loadRacesInfo <- function(){
  races <- read.csv(paste0(TODAYS_DIR, "\\races.csv"))
  racesInfo <- read.csv(paste0(TODAYS_DIR, "\\allRacesInfo.csv"))
  colnames(racesInfo)[2] <- "marketId"
  racesInfo <- merge(racesInfo, races[c("marketId", "startTime")])
  
  racesInfo$startTime <- as.POSIXlt(racesInfo$startTime, format = "%Y-%m-%dT%H:%M:%S")

  return(racesInfo)
}

getOddsCheckerVenue <- function(venue){
  if(venue == ""){ #mapping the oddsckecher venue to the betfair venue name
    return("")
  }else if(venue == "Down Royal"){
    return("down-royal")
  }
  else{
    return(venue)
  }
}

generateOddsCheckerLink <- function(venue, startTime){
  base_url <- "https://www.oddschecker.com/horse-racing/"
  venue <- getOddsCheckerVenue(tolower(venue))
  venue <- str_replace(venue, " ", "-")
  hour <- substr(start = 12, stop = 16, x = startTime)
  
  url <- paste0(base_url, venue, "/", hour, "/winner")
  return(url)
}

generateBetfairLink <- function(mid){
  base_url <- "https://www.betfair.com/exchange/plus/horse-racing/market/"
  url <- paste0(base_url,mid)
  return(url)
}

displayHyperlink <- function(url, website, venue, startTime){
  hour <- substr(start = 12, stop = 16, x = startTime)
  
  cat(
    cli::style_hyperlink(
      text = paste0(website, " - ", venue, ":", hour),
      url = url
    )
    , sep = "\n"
  )
}

plotRacesWithinNHours <- function(racesInfo, minutes = 120){
  nextTwoHourRaces <- subset(racesInfo, racesInfo$startTime > Sys.time() + 30 * 60 & 
                                        racesInfo$startTime < Sys.time() + 60 * minutes)
  for(mid in unique(nextTwoHourRaces$marketId)){
    raceInfo <- subset(racesInfo, racesInfo$marketId == mid)
    oddsCheckerHyperlink <- generateOddsCheckerLink(raceInfo$venue[1], as.character(raceInfo$startTime[1]))
    displayHyperlink(url <- oddsCheckerHyperlink, website = "Oddschecker", venue = raceInfo$venue[1], startTime = as.character(raceInfo$startTime[1]))
    
    mid <- str_replace(mid, "_", "\\.")
    
    betfairHyperlink <- generateBetfairLink(mid)
    displayHyperlink(url <- betfairHyperlink, website = "Betfair", venue = raceInfo$venue[1], startTime = as.character(raceInfo$startTime[1]))
    
    generateGraphsForMarketId(mid, eventInfo = raceInfo)
    cat(sep = "\n")
  }
}

racesInfo <- loadRacesInfo()

#######


plotRacesWithinNHours(racesInfo = racesInfo, minutes = 120)


