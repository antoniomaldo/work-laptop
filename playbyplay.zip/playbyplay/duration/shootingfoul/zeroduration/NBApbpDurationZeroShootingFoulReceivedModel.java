package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shootingfoul.zeroduration;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;

public class NBApbpDurationZeroShootingFoulReceivedModel implements PBPProbabilityModel<NbaPBPGameState> {

    @Override
    public boolean isSuccess(ISimplePBPGameState simpleGameState) {
        return false;
    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {
        return 0d;
    }
}
