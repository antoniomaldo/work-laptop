package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shootingfoul.nonzeroduration;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

class NBApbpDurationShootingFoulReceivedWoLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {1.385282d, -0.3237767d, 0.3448497d, 0.2611414d, 0.1350047d, -0.4069103d, -0.2828113d, -0.04872859d, 0.05561058d, -0.07472057d, -0.01319294d, -0.01210183d, -0.01457745d, -0.01146754d, 0.002998222d, 0.0009465045d, 0.000154404d, -0.0001417612d, 0.001192919d, 0.001130471d, 0.001059011d, 0.001343648d, 0.001494012d, 0.00160278d, 0.001436482d, 0.001398305d, 1.285923d, 1.224706d, 1.587706d, 0d, 2.351998d, 2.261916d, 2.295739d, 0d, 2.963549d, 2.949504d, 3.195875d, 1.115976d, 2.938015d, 2.808098d, 3.064146d, 2.835088d, 2.933517d, 2.945106d, 3.123921d, 2.582456d, 2.889612d, 2.866927d, 3.0136d, 2.723998d, 3.066503d, 2.970009d, 3.20118d, 2.687043d, 3.393427d, 3.224646d, 3.432395d, 2.902586d, 0.002337293d, 0.003636784d, 0.003403109d, 0.004828216d, -0.001930837d, -0.001916135d, -0.002006839d, -0.001612392d, -0.04257465d, -0.0308255d, -0.04310864d, -0.04050278d, 0.02313938d, 0.01855476d, 0.01337486d, 0.03340303d, 0.008701545d, 0.01060074d, 0.01109231d, 0.007019762d, -0.004125767d, -0.004109969d, -0.003868688d, -0.0002143339d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double START_PERIOD_LAST_POSSESSION = COEF[COUNTER++];

    private static final double MAX_FORTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] TIME_SINCE_LAST_OWN_TIME_OUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] TIME_SINCE_LAST_OPP_TIME_OUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[0], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[0], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[0], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[1], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[1], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[1], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[2], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[2], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[2], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[3], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[3], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[3], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[3]});

    private static final double[] LOSING_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_TWO_MINUTES_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] DEF_FOUL_LESS_THAN_TEN_SECONDS_PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] DEF_FOUL_MORE_THAN_TEN_SECONDS_PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    static {
        for (int time = 0; time <= 720; time++) {
            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
        }
    }

    private static final double SHAPE_PARAMETER = 3.20134279;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(gameState, team) / SHAPE_PARAMETER;
        Random random = new Random();
        return Math.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return Math.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    private static double getMeanDurationTime(NbaPBPGameState gameState, Team team) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        return getMeanDurationTime(simpleGameState);
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean firstPlayOfQuarter = gameState.getFirstPlayOfPeriod();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = gameState.getOwnDefensiveFoulReceivedLastPossession();

        String lastPossessionOutcome = gameState.getLastPossessionOutcome().name();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        return getMeanDurationTime(quarter, startTime, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, lastPossessionOutcome, previousPossessionDuration, oppShotMissedLastPossession, firstPlayOfQuarter, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefensiveFoulReceivedLastPossession);
    }

    public static double getMeanDurationTime(int quarter, int startTime, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, double timeSinceLastOwnTimeOut, double timeSinceLastOppTimeOut, String lastPossessionOutcome, int previousPossessionDuration, boolean oppShotMissedLastPossession, boolean firstPlayOfQuarter, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoul) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, firstPlayOfQuarter, defFoul) //
                + FastMath.max(40 - startTime, 0) * MAX_FORTY_MINUS_START_TIME_AND_ZERO //
                + FastMath.max(24 - startTime, 0) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO //
                + ownExpHalfPoints * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] //
                + (ownExpHalfPoints - oppExpHalfPoints) * OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER[quarter - 1]//
                + Math.max(0, 100 - timeSinceLastOwnTimeOut) * TIME_SINCE_LAST_OWN_TIME_OUT_INTERACTION_QUARTER[quarter - 1]//
                + Math.max(0, 100 - timeSinceLastOppTimeOut) * TIME_SINCE_LAST_OPP_TIME_OUT_INTERACTION_QUARTER[quarter - 1] //
                + getStartTimeSpline(quarter)[startTime] //
                + FastMath.min(ownScoreDiffBeforePlay, 0) * LOSING_INTERACTION_QUARTER[quarter - 1] //
                + FastMath.max(600, startTime) * FIRST_TWO_MINUTES_INTERACTION_QUARTER[quarter - 1] //
                + getFactorForLastPossession(lastPossessionOutcome, quarter, previousPossessionDuration)//
                + previousPossessionDuration * PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1]);

        return exp;
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean startPeriod, boolean defFoul) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (startPeriod) {
            return START_PERIOD_LAST_POSSESSION;
        } else if (defFoul) {
            return OWN_DEFENSIVE_FOUL_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }

    private static double getFactorForLastPossession(String lastPossessionOutcome, int quarter, int previousPossessionDuration) {
        lastPossessionOutcome = lastPossessionOutcome.toLowerCase();

        boolean isTimeOut = lastPossessionOutcome.contains("time_out");
        boolean isDefensiveFoul = lastPossessionOutcome.contains("defensive");
        if (isDefensiveFoul) {
            return FastMath.max(10 - previousPossessionDuration, 0) * DEF_FOUL_LESS_THAN_TEN_SECONDS_PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1] +//
                    FastMath.max(10, previousPossessionDuration) * DEF_FOUL_MORE_THAN_TEN_SECONDS_PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1];
        } else if (isTimeOut) {
            return PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * previousPossessionDuration;
        }
        return 0d;
    }
}
