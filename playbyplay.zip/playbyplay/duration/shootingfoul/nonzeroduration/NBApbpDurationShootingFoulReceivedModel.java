package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shootingfoul.nonzeroduration;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpDurationShootingFoulReceivedModel implements PBPDurationModel<NbaPBPGameState> {

    private static final NBApbpDurationShootingFoulReceivedWoLastFiveMinutesModel MODEL_WO_LAST_FIVE_MINUTES = new NBApbpDurationShootingFoulReceivedWoLastFiveMinutesModel();
    private static final NBApbpDurationShootingFoulReceivedLastFiveMinutesModel MODEL_LAST_FIVE_MINUTES = new NBApbpDurationShootingFoulReceivedLastFiveMinutesModel();

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if ( gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        }
        return generatedTime;
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if ( gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        }
        return generatedTime;
    }
}
