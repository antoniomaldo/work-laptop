package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shootingfoul.nonzeroduration;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

class NBApbpDurationShootingFoulReceivedLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {3.191444d, -0.01016331d, 0.0002213442d, -0.0001901051d, -0.33335d, 0.2065929d, 0.1462742d, -0.1640355d, -0.3830475d, -0.412217d, 0.006703215d, -0.001477216d, -0.001718118d, -0.01659258d, 0.0005213272d, 6.384514e-05d, -0.001739317d, 0.0004464117d, 0.001051345d, 0.0008969618d, 0.0004040602d, -0.008078666d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS = COEF[COUNTER++];
    private static final double TIME_SINCE_LAST_OWN_TIME_OUT = COEF[COUNTER++];
    private static final double TIME_SINCE_LAST_OPP_TIME_OUT = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LOSING = COEF[COUNTER++];

    private static final double MAX_TWO_MINS_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_SIXTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final IntegerSpline OWN_SCORE_DIFF_SPLINE = new IntegerBoundedSpline(new double[] {-53, -10, -5, 0, 5, 10, 50}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] OWN_SCORE_DIFF_SPLINE_ARRAY = new double[101];

    static {
        for (int scoreDiff = -50; scoreDiff <= 50; scoreDiff++) {
            OWN_SCORE_DIFF_SPLINE_ARRAY[scoreDiff + 50] = OWN_SCORE_DIFF_SPLINE.value(scoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 2.7870809;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(gameState, team) / SHAPE_PARAMETER;
        Random random = new Random();
        return Math.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return Math.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    private static double getMeanDurationTime(NbaPBPGameState gameState, Team team) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        return getMeanDurationTime(simpleGameState);
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = gameState.getOwnDefensiveFoulReceivedLastPossession();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        return getMeanDurationTime(startTime, ownExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefensiveFoulReceivedLastPossession);
    }

    public static double getMeanDurationTime(int startTime, double ownExpHalfPoints, int ownScoreDiffBeforePlay, double timeSinceLastOwnTimeOut, double timeSinceLastOppTimeOut, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoul) {
        double exp = MathRnD.fastExp(INTERCEPT //
                + ownExpHalfPoints * OWN_EXP_HALF_POINTS //
                + Math.max(0, 100 - timeSinceLastOwnTimeOut) * TIME_SINCE_LAST_OWN_TIME_OUT//
                + Math.max(0, 100 - timeSinceLastOppTimeOut) * TIME_SINCE_LAST_OPP_TIME_OUT //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, defFoul) //
                + FastMath.min(ownScoreDiffBeforePlay, 0) * LOSING //
                + FastMath.max(120 - startTime, 0) * MAX_TWO_MINS_MINUS_START_TIME_AND_ZERO //
                + FastMath.max(60 - startTime, 0) * MAX_SIXTY_MINUS_START_TIME_AND_ZERO //
                + FastMath.max(24 - startTime, 0) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO //
                + OWN_SCORE_DIFF_SPLINE_ARRAY[ownScoreDiffBeforePlay + 50] * (300 - startTime));

        return exp;
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean defFoul) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (defFoul) {
            return OWN_DEFENSIVE_FOUL_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }

}
