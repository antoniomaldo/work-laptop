package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shotmissed;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationShotMissedLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {2.353115d, -0.008559262d, -0.008135097d, -0.001204046d, -0.004200417d, -0.04451022d, -0.02624867d, -0.0813975d, -0.05141074d, 0.884305d, 0.8487736d, 0.8557913d, 0.8263506d, 0.8391706d, 0.01237696d, -0.1640219d, 0.1831444d, 0.12102d, -0.2505711d, -0.1588667d, -0.119856d, -0.004387181d, -0.001377793d, -0.0002512501d, -0.02060284d, 0.001248045d, -0.04767127d, -0.02933417d, -0.09420973d, 0.1109078d, 0.03322392d, 0.008434792d, -0.06364933d, 0.09355414d, 0.09739846d, -0.1936723d, 0.05472954d, -0.1613479d, 0.02202987d, 0.09465203d, 0.1531816d, 0.1736442d, -0.01266319d, 0.0127753d, 0.03164326d, -0.148709d, -0.1125521d, -0.1552568d, -0.4152128d, 0.3662354d, 0.1016602d, 0.2804738d, 0.03998944d, 0.06587308d, 0.3421563d, -0.4056488d, 0.1534098d, -0.1724856d, -0.2103181d, 0.06359971d, 0.1260529d, 0.1042611d, -0.2114675d, 0.2720358d, -0.0371718d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS = COEF[COUNTER++];
    private static final double OPP_TEAM_IN_BONUS = COEF[COUNTER++];
    private static final double OWN_TEAM_IN_BONUS = COEF[COUNTER++];

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double LESS_THAN_A_MINUTE_SINCE_LAST_OPP_TIME_OUT = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS = COEF[COUNTER++];
    private static final double PREVIOUS_DURATION = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double LESS_THAN_FORTY_SECONDS = COEF[COUNTER++];
    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final double MAX_TWELVE_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_TWELVE_SECONDS = COEF[COUNTER++];

    private static final double MORE_THAN_NINETY_SECONDS_LEFT = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE = new IntegerBoundedSpline(new double[] {-56, -20, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE = new IntegerBoundedSpline(new double[] {-56, -20, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE = new IntegerBoundedSpline(new double[] {-56, -20, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE.value(time);
        }
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE.value(ownScoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 5.80782266;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double meanDuration = getMeanDurationTime(simpleGameState);
        double scaleParameter = meanDuration / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double meanDuration = getMeanDurationTime(simpleGameState);
        double scaleParameter = meanDuration / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int startTime = gameState.getPeriodSecondsRemaining();
        int ownTeamInBonus = gameState.getOwnTeamInBonus();
        int oppTeamInBonus = gameState.getOppTeamInBonus();
        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefFoulRec = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(startTime, ownExpHalfPoints, oppExpHalfPoints, ownTeamInBonus, oppTeamInBonus, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, gameState.getCurrentNBASeasonYear(), oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefFoulRec);
    }

    public static double getMeanDurationTime(int startTime, double ownExpHalfPoints, double oppExpHalfPoints, int ownTeamInBonus, int oppTeamInBonus, int ownScoreDiffBeforePlay, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int previousPossessionDuration, int seasonYear, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoulReceived) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + FastMath.max(44, ownExpHalfPoints) * OWN_EXP_HALF_POINTS //
                + OPP_TEAM_IN_BONUS * oppTeamInBonus //
                + OWN_TEAM_IN_BONUS * ownTeamInBonus //
                + TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] //
                + TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] //
                + FastMath.max(60 - timeSinceLastOppTimeOut, 0) * LESS_THAN_A_MINUTE_SINCE_LAST_OPP_TIME_OUT //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, defFoulReceived) ///
                + getFactorForLastPossession(defFoulReceived, ownTimeOutLastPossession, startTime, previousPossessionDuration) //
                + previousPossessionDuration * PREVIOUS_DURATION //
                + (startTime < 40 ? LESS_THAN_FORTY_SECONDS : 0d) //
                + (startTime < 24 ? (24 - startTime) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime < 12 ? (12 - startTime) * MAX_TWELVE_MINUS_START_TIME_AND_ZERO + LESS_THAN_TWELVE_SECONDS : 0d) //
                + (startTime > 90 ? MORE_THAN_NINETY_SECONDS_LEFT : 0d) //
                + (startTime < 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + (startTime < 120 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiffBeforePlay + 50] : 0d)//
                + SEASON_YEAR_ARRAY[seasonYear - 2015]

        );
        return exp;
    }

    private static double getFactorForLastPossession(boolean defFoulReceived, boolean ownTimeOutLastPossession, int startTime, int previousPossessionDuration) {
        if (defFoulReceived || ownTimeOutLastPossession) {
            double commonFactor = FastMath.max(10, previousPossessionDuration) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS;

            if (defFoulReceived) {
                double startTimeFactor = START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER * startTime;
                return startTimeFactor + commonFactor;
            } else {
                double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER * previousPossessionDuration;
                double startTimeFactor = START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER * startTime;
                return previousDurationFactor + startTimeFactor + commonFactor;
            }
        } else {
            return 0;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean defFoulReceived) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (defFoulReceived) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
