package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shotmissed;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import java.util.Random;

public class NBApbpDurationShotMissedWoLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {3.328166d, -0.2690296d, 0.1875699d, 0.1119996d, 0.04647129d, -0.1749965d, -0.1511809d, 0.0565083d, -0.2549269d, -0.09129511d, -0.1492481d, -0.01563871d, -0.07617774d, -0.005242016d, -0.008573079d, -0.008396452d, -0.01032401d, -0.009936361d, 0.001317714d, -0.007275489d, -0.006023897d, 0.003590335d, -0.005537507d, -0.008806055d, -0.005720009d, -0.005164592d, 0.493488d, 0.5493207d, 0.6566206d, -0.1757934d, 0.5552619d, 0.5731891d, 0.6909212d, -0.09278373d, 0.4198783d, 0.5302249d, 0.583984d, -0.1930999d, 0.4980104d, 0.5072748d, 0.6296026d, -0.2085494d, 0.6427202d, 0.5499569d, 0.6797701d, -0.1980896d, -0.06530411d, -0.08514357d, -0.08830405d, -0.09143057d, -0.07691765d, -0.1062046d, -0.1044092d, -0.1164219d, -0.04602806d, -0.0669262d, -0.09395386d, -0.08939242d, -0.1192141d, -0.1428065d, -0.116744d, -0.2552918d, -0.06020414d, -0.08916673d, -0.08187439d, -0.2443245d, -0.006343442d, -0.006793572d, -0.005850763d, -0.007640011d, -0.002433862d, -0.002708112d, -0.001877474d, -0.001761169d, -0.02410165d, -0.02732164d, -0.03434386d, -0.03136312d, -0.5682471d, -0.463922d, -0.4258327d, -0.3906955d, -0.4530262d, -0.195088d, 0.4185442d, 0.2186893d, 0.4531522d, 0.4514978d, 0.2522192d, 0.7368091};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double MAX_FOURTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_FOURTY_SECONDS = COEF[COUNTER++];

    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS = COEF[COUNTER++];

    private static final double MAX_TWENTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final double MAX_TWELVE_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    //    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double SEASON_YEAR_2019 = COEF[COUNTER++];

    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_TEAM_IN_BONUS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_DEF_FOULS_RECEIVED_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 600, 720}, new double[]{FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[0], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[0], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[0], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 600, 720}, new double[]{FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[1], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[1], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[1], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 600, 720}, new double[]{FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[2], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[2], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[2], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 600, 720}, new double[]{FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[3], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[3], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[3], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 300, 720}, new double[]{FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 300, 720}, new double[]{FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 300, 720}, new double[]{FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[]{0, 100, 300, 720}, new double[]{FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS = new IntegerBoundedSpline(new double[]{-56, -20, 0, 20, 56}, new double[]{COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER = new IntegerBoundedSpline(new double[]{-56, -20, 0, 20, 56}, new double[]{COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER_ARRAY = new double[101];

    static {

        for (int time = 0; time <= 720; time++) {
            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
        }

        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER.value(ownScoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 7.45971006;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;

        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;

        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        double percentageGamePlayed = gameState.getPercentageGamePlayed();

        int ownTeamInBonus = gameState.getOwnTeamInBonus();
        int periodOwnDefensiveFoulsReceived = gameState.getPeriodOwnDefensiveFoulsReceived();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean defFoulReceived = gameState.getOwnDefensiveFoulReceivedLastPossession();

        double meanDurationTime = getMeanDurationTime(quarter, startTime, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, percentageGamePlayed, ownTeamInBonus, periodOwnDefensiveFoulsReceived, gameState.getCurrentNBASeasonYear(), oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, defFoulReceived);

        return FastMath.min(60, meanDurationTime);
    }

    public static double getMeanDurationTime(int quarter,
                                             int startTime,
                                             double ownExpHalfPoints,
                                             double oppExpHalfPoints,
                                             int ownScoreDiffBeforePlay,
                                             int timeSinceLastOwnTimeOut,
                                             int timeSinceLastOppTimeOut,
                                             int previousPossessionDuration,
                                             double percGamePlayed,
                                             int ownTeamInBonus,
                                             int periodOwnDefensiveFoulsReceived,
                                             int seasonYear,
                                             boolean oppShotMissedLastPossession,
                                             boolean oppThreePointsLastPossession,
                                             boolean ownTimeOutLastPossession,
                                             boolean oppTurnoverLastPossession,
                                             boolean oppTwoPointsLastPossession,
                                             boolean defFoulReceived) {

        ownExpHalfPoints = FastMath.max(39, FastMath.min(69, ownExpHalfPoints));
        double exp = MathRnD.fastExp(INTERCEPT //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, defFoulReceived) ///
                + (startTime < 40 ? (40 - startTime) * MAX_FOURTY_MINUS_START_TIME_AND_ZERO + LESS_THAN_FOURTY_SECONDS : 0d) //
                + (startTime < 24 ? (24 - startTime) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO + LESS_THAN_TWENTY_FOUR_SECONDS : 0d) //
                + (startTime < 20 ? (20 - startTime) * MAX_TWENTY_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime < 12 ? (12 - startTime) * MAX_TWELVE_MINUS_START_TIME_AND_ZERO : 0d) //

                + SEASON_YEAR_2019 * (seasonYear == 2019 ? 1 : 0)

                + OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] * ownExpHalfPoints

                + ownTeamInBonus * OWN_TEAM_IN_BONUS_INTERACTION_QUARTER[quarter - 1] //
                + FastMath.min(periodOwnDefensiveFoulsReceived, 4) * OWN_DEF_FOULS_RECEIVED_INTERACTION_QUARTER[quarter - 1]//
                + (quarter < 4 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS_ARRAY : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + getStartTimeSpline(quarter)[startTime]  //
                + getTimeSinceLastOwnTimeOutSpline(quarter)[timeSinceLastOwnTimeOut] //
                + getTimeSinceLastOppTimeOutSpline(quarter)[timeSinceLastOppTimeOut]  //
                + getFactorForLastPossession(defFoulReceived, ownTimeOutLastPossession, startTime, quarter, previousPossessionDuration, ownScoreDiffBeforePlay, percGamePlayed) //
                + previousPossessionDuration * PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1]  //

        );
        return exp;
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOwnTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOppTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }


    private static double getFactorForLastPossession(boolean defFoulReceived, boolean ownTimeOutLastPossession, int startTime, int quarter, int previousPossessionDuration, int ownScoreDiffBeforePlay, double percGamePlayed) {
        if (defFoulReceived || ownTimeOutLastPossession) {
            double commonFactor = FastMath.max(10, previousPossessionDuration) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER[quarter - 1];

            if (defFoulReceived) {
                return commonFactor;
            } else {
                double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * previousPossessionDuration;
                return previousDurationFactor + commonFactor;
            }
        } else {
            return 0;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean defFoulReceived) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (defFoulReceived) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
