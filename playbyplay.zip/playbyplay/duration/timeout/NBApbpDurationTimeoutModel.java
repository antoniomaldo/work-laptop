package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.timeout;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;

public class NBApbpDurationTimeoutModel implements PBPDurationModel<NbaPBPGameState> {

    static final double[] COEF = {2.195606d, -0.41628d, -1.000123d, -0.7478436d, 0.2685108d, 0.009159067d, 0.01642254d, -0.05229531d, -0.2850643d, -0.2484256d, -0.002749486d, 0.04420056d, 0.04745634d};

    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];

    private static final double OWN_SCORE_DIFF_BEFORE_PLAY = COEF[COUNTER++];

    private static final double PREVIOUS_POSSESSION_DURATION = COEF[COUNTER++];

    private static final double[] QUARTER_FACTOR = {0d, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double FOURTH_QUARTER_OWN_SCORE_DIFF_INTERACTION = COEF[COUNTER++];
    private static final double LAST_TWO_MINS_OWN_SCORE_DIFF_INTERACTION = COEF[COUNTER++];
    private static final double LAST_MINUTE_WINNING_BY_LESS_THAN_THREE = COEF[COUNTER++];

    private static final double SHAPE_PARAMETER = 1.36825776;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(gameState, team) / SHAPE_PARAMETER;
        Random random = new Random();
        return Math.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return Math.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    private static double getMeanDurationTime(NbaPBPGameState gameState, Team team) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        return getMeanDurationTime(simpleGameState);
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();
        int timeRemInMatch = gameState.getMatchSecondsRemaining();

        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();

        double meanDurationTime = getMeanDurationTime(quarter, startTime, timeRemInMatch, ownScoreDiffBeforePlay, previousPossessionDuration, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTwoPointsScoredLastPossession);


        return FastMath.min(24, meanDurationTime);

    }

    public static double getMeanDurationTime(int quarter, int startTime, int timeRemInMatch, int ownScoreDiffBeforePlay, double previousPossessionDuration, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTwoPointsLastPossession) {

        boolean lastTwoMinutes = timeRemInMatch <= 120;
        boolean lastMinute = timeRemInMatch <= 60;

        double exp = FastMath.exp(INTERCEPT //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession) //
                + ownScoreDiffBeforePlay * OWN_SCORE_DIFF_BEFORE_PLAY //
                + (previousPossessionDuration > -1 ? previousPossessionDuration * PREVIOUS_POSSESSION_DURATION : 0) //
                + QUARTER_FACTOR[quarter - 1] //
                + (quarter == 4 ? FastMath.max(0, ownScoreDiffBeforePlay) * FOURTH_QUARTER_OWN_SCORE_DIFF_INTERACTION : 0d) //
                + (lastTwoMinutes ? FastMath.min(0, ownScoreDiffBeforePlay) * LAST_TWO_MINS_OWN_SCORE_DIFF_INTERACTION : 0d) //
                + (lastMinute ? FastMath.max(0, FastMath.min(ownScoreDiffBeforePlay, 3)) * LAST_MINUTE_WINNING_BY_LESS_THAN_THREE : 0d)//
        );
        return exp;
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
