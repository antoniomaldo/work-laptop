package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.timeout;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationZeroTimeoutModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {5.701278d, -0.9154731d, -1.259085d, -1.879058d, 0.1834676d, -1.507942d, -1.332942d, -1.647176d, -1.936442d, -3.48935d, -3.931824d, -0.2390002d, 0.303925d, -2.9069d, -2.950811d, -0.003082552d, -3.689392d, -0.4767942d, -0.6547468d, -2.110814d, -0.02901569d, -0.08361498d};

    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];
    private static final double[] QUARTER_FACTOR = {0d, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_REM_IN_MATCH_SPLINE = new IntegerBoundedSpline(new double[] {0, 180, 360, 450, 1200, 2880}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double OWN_CUM_TIME_OUTS_IN_QUARTER = COEF[COUNTER++];

    private static final double OPP_CUM_TIME_OUTS_IN_QUARTER_ZERO = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double START_TIME_LAST_POSSESSION = COEF[COUNTER++];
    private static final double TECH_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];

    private static final double PREVIOUS_POSSESSION_DURATION = COEF[COUNTER++];

    private static final double OWN_SCORE_DIFF_LAST_TWO_MINUTES = COEF[COUNTER++];

    private static final double[] TIME_REM_IN_MATCH_SPLINE_ARRAY = new double[2881];

    static {
        for (int timeRemInMatch = 0; timeRemInMatch <= 2880; timeRemInMatch++) {
            TIME_REM_IN_MATCH_SPLINE_ARRAY[timeRemInMatch] = TIME_REM_IN_MATCH_SPLINE.value(timeRemInMatch);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int timeRemInMatch = gameState.getMatchSecondsRemaining();

        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int ownTimeOutsInQuarter = gameState.getPeriodOwnTimeOuts();
        int oppTimeOutsInQuarter = gameState.getPeriodOppTimeOuts();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean startTimeLastPossession = gameState.getLastPossessionOutcome() == PossessionOutcome.START_OF_PERIOD;
        boolean lastPossessionTechFoul = false; //TODO
        boolean ownTimeOutCalledLastPossession = gameState.getOwnTimeOutCalledLastPossession();

        return getProbability(quarter, timeRemInMatch, ownScoreDiffBeforePlay, ownTimeOutsInQuarter, oppTimeOutsInQuarter, previousPossessionDuration, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, startTimeLastPossession, lastPossessionTechFoul, ownTimeOutCalledLastPossession);
    }

    public static double getProbability(int quarter, int timeRemInMatch, int ownScoreDiffBeforePlay, int ownCumTimeOutsInQuarter, int oppCumTimeOutsInQuarter, double previousPossessionDuration, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean startTimeLastPossession, boolean lastPossessionTechFoul, boolean ownTimeOutCalledLastPossession) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + QUARTER_FACTOR[quarter - 1] //
                + TIME_REM_IN_MATCH_SPLINE_ARRAY[timeRemInMatch] //
                + ownCumTimeOutsInQuarter * OWN_CUM_TIME_OUTS_IN_QUARTER//
                + (oppCumTimeOutsInQuarter == 0 ? OPP_CUM_TIME_OUTS_IN_QUARTER_ZERO : 0d) //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, startTimeLastPossession, lastPossessionTechFoul, ownTimeOutCalledLastPossession) //
                + (previousPossessionDuration > -1 ? previousPossessionDuration * PREVIOUS_POSSESSION_DURATION : 0) //
                + (timeRemInMatch <= 120 ? ownScoreDiffBeforePlay * OWN_SCORE_DIFF_LAST_TWO_MINUTES : 0d) //
        );

        return exp / (1 + exp);

    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean startTime, boolean lastPossessionTechFoul, boolean ownTimeOutCalledLastPossession) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (startTime) {
            return START_TIME_LAST_POSSESSION;
        } else if (lastPossessionTechFoul) {
            return TECH_FOUL_LAST_POSSESSION;
        } else if (ownTimeOutCalledLastPossession) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }

}
