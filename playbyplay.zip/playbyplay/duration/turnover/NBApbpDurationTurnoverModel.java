package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.turnover;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpDurationTurnoverModel implements PBPDurationModel<NbaPBPGameState> {

    private static final NBApbpDurationTurnoverWoLastFiveMinutesModel MODEL_WO_LAST_FIVE_MINUTES = new NBApbpDurationTurnoverWoLastFiveMinutesModel();
    private static final NBApbpDurationTurnoverLastFiveMinutesModel MODEL_LAST_FIVE_MINUTES = new NBApbpDurationTurnoverLastFiveMinutesModel();

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if (gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, team, PossessionOutcome.SHOT_MISSED);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        }
        return generatedTime;
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if (gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, PossessionOutcome.SHOT_MISSED);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        }
        return generatedTime;
    }
}
