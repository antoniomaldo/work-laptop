package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.turnover;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.PossessionOutcomeModelUtils;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationTurnoverLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {-27.74672d, -0.01218538d, -0.01881581d, 8.102747d, 21.40992d, 30.79862d, 30.89593d, 31.13749d, 31.00259d, 30.99103d, 0.08640227d, 0.003832764d, 0.0535792d, 0.01413399d, -0.02452461d, 0.1250275d, 0.03184166d, -0.01080812d, 0.1087494d, -0.0274117d, -0.2080503d, 0.1852297d, 0.1334464d, -0.6395537d, -0.5483493d, -0.1978705d, 0.04279402d, 0.002151265d, -0.003889638d, 0.0005581502d, -0.006528385d, 0.001496492d, 0.01250342d, 0.02228713d, -0.6910447d, -0.2888842d, 0.1294951d, -0.343608d, -0.0801685d, 0.1196658d, 0.0630624d, 0.05033678d, -0.04661043d, -0.03051099d, -0.08223001d, 0.3353512d, -0.2082177d, -0.09246066d, -0.5941174d, 0.3828649d, -0.2877988d, 0.4765605d, 0.2016941d, 0.964085d, 0.8022766d, -0.6976775d, 0.2186576d, -0.1578764d, -0.1624025d, 0.1653449d, 0.05078372d, 0.1325417d, -0.06714127d, -0.3218044d, -0.2521328d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double PREVIOUS_POSSESSION_DURATION = COEF[COUNTER++];

    private static final IntegerSpline START_TIME_SPLINE = new IntegerBoundedSpline(new double[] {0, 10, 24, 35, 100, 300}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LAST_POSS_DEF_FOUL_OR_TIME_OUT_LESS_THAN_TEN_SECONDS_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double PREVIOUS_DURATION_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double LAST_THIRTY_FIVE_SECONDS_OF_QUARTER_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double LAST_TWENTY_FOUR_SECONDS_OF_QUARTER_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double WINNING_BY_LESS_THAN_SEVEN_LAST_POSSESSION = COEF[COUNTER++];

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE = new IntegerBoundedSpline(new double[] {-56, -20, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE = new IntegerBoundedSpline(new double[] {-56, -20, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE = new IntegerBoundedSpline(new double[] {-56, -20, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] START_TIME_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {
            START_TIME_SPLINE_ARRAY[time] = START_TIME_SPLINE.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE.value(time);
        }
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE.value(ownScoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 2.75416892;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefFoulRec = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(startTime, ownExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefFoulRec);
    }

    public static double getMeanDurationTime(int startTime, double ownExpHalfPoints, int ownScoreDiffBeforePlay, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int previousPossessionDuration, boolean oppShotMissedLastPossession, boolean oppThreePointsScoredLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsScoredLastPossession, boolean ownDefFoulRec) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + FastMath.max(44, ownExpHalfPoints) * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER  //
                + (previousPossessionDuration > -1 ? FastMath.max(5 - previousPossessionDuration, 0) * PREVIOUS_POSSESSION_DURATION : 0d) //
                + START_TIME_SPLINE_ARRAY[startTime] //
                + TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] //
                + TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsScoredLastPossession, oppTwoPointsScoredLastPossession, ownTimeOutLastPossession, ownDefFoulRec) //
                + getFactorForLastPossession(ownDefFoulRec, ownTimeOutLastPossession, startTime, previousPossessionDuration) //
                + previousPossessionDuration * PREVIOUS_DURATION_INTERACTION_QUARTER  //
                + PossessionOutcomeModelUtils.square(FastMath.max(35 - startTime, 0)) * LAST_THIRTY_FIVE_SECONDS_OF_QUARTER_INTERACTION_QUARTER //
                + PossessionOutcomeModelUtils.square(FastMath.max(24 - startTime, 0)) * LAST_TWENTY_FOUR_SECONDS_OF_QUARTER_INTERACTION_QUARTER //
                + (startTime < 25 & ownScoreDiffBeforePlay > 0 & ownScoreDiffBeforePlay < 7 ? WINNING_BY_LESS_THAN_SEVEN_LAST_POSSESSION : 0d) //
                + (startTime < 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + (startTime < 120 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiffBeforePlay + 50] : 0d) //
        ); //

        return exp;
    }

    private static double getFactorForLastPossession(boolean ownDefFoulRec, boolean ownTimeOutLastPossession, int startTime, int previousPossessionDuration) {
        if (ownDefFoulRec || ownTimeOutLastPossession) {
            double commonFactor = FastMath.max(10 - previousPossessionDuration, 0) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_LESS_THAN_TEN_SECONDS_INTERACTION_QUARTER +//
                    FastMath.max(10, previousPossessionDuration) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER;

            if (ownDefFoulRec) {
                double startTimeFactor = START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER * startTime;
                return startTimeFactor + commonFactor;
            } else {
                double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER * previousPossessionDuration;
                double startTimeFactor = START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER * startTime;
                return previousDurationFactor + startTimeFactor + commonFactor;
            }
        } else {
            return 0;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean ownDefFoulRec) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (ownDefFoulRec) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
