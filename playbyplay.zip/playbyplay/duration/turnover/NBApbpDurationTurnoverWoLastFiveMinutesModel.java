package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.turnover;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.PossessionOutcomeModelUtils;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationTurnoverWoLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {-46.57718d, 0.002548064d, -0.3773068d, 0.2422629d, 0.1559737d, -0.3792578d, -0.3819769d, -0.2696266d, 0.004085069d, -0.01538996d, -0.003911938d, 0.002526609d, -0.0153341d, -0.01218666d, -0.01774677d, -0.01584679d, 0.002639117d, 0.0007130241d, 0.003064827d, -0.0003564012d, 12.30459d, 12.29679d, 12.22786d,  34.09176d, 34.05988d, 34.76624d,  50.02675d, 49.77072d, 50.23676d,  50.28763d, 50.08281d, 50.35958d, 50.6091d, 50.24364d, 50.0573d, 50.45263d, 50.13872d, 50.28171d, 50.09015d, 50.29615d, 50.30291d, 50.16956d, 50.02955d, 50.33807d, 50.1582d, 50.29427d, 50.03475d, 50.34992d, 50.24916d, -0.1312388d, -0.1081224d, -0.1195477d, -0.1075569d, -0.1391005d, -0.1157189d, -0.09644901d, -0.09098035d, -0.2152708d, -0.123411d, -0.1772202d, -0.2347351d, -0.2072509d, -0.159414d, -0.1568119d, 0.2687699d, -0.2381184d, -0.08491733d, -0.1254739d, -7.529805d, -0.03356682d, -0.01911958d, -0.03272906d, 0.1135356d, -0.1164004d, -0.1466362d, -0.1139786d, -0.1048336d, -0.1308605d, -0.067581d, -0.07977191d, 0.2028757d, -0.127664d, -0.1347882d, -0.1517054d, -0.5416975d, -0.1343412d, -0.06481414d, -0.07265335d, 4.499501d, 0.02623705d, 0.02400626d, 0.02855437d, 0.02817973d, 0.004287745d, 0.004461766d, 0.003694248d, 0.005189743d, -0.002154112d, -0.004069162d, -0.001843237d, -0.002769543d, -0.0001993722d, -0.0001579236d, -0.0001797489d, -0.0002379299d, -0.02433657d, -0.02356164d, -0.02516144d, -0.02601521d, 0.000189547d, 0.0002165214d, 0.0001330678d, -1.629546e-05d, 0.02449071d, 0.02438616d, 0.02275676d, 0.0300925d, 0.02965256d, 0.03408861d,  0.001871612d, 0.003492484d, 0.002697038d, 0.005772708};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double PREVIOUS_POSSESSION_DURATION = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIRST_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};

    private static final double[] SECOND_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};

    private static final double[] THIRD_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};

    private static final double[] FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 35, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[0], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[0], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[0], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 35, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[1], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[1], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[1], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 35, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[2], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[2], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[2], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 35, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[3], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[3], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[3], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] LAST_POSS_DEF_FOUL_OR_TIME_OUT_LESS_THAN_TEN_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] LAST_THIRTY_FIVE_SECONDS_OF_QUARTER_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};

    private static final double[] LAST_TWENTY_FOUR_SECONDS_OF_QUARTER_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    static {
        for (int time = 0; time <= 720; time++) {
            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
        }
    }

    private static final double SHAPE_PARAMETER = 3.15731319;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;

        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;

        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefFoulRec = gameState.getOwnDefensiveFoulReceivedLastPossession(); //TODO

        return getMeanDurationTime(quarter, startTime, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, gameState.getCurrentNBASeasonYear(), oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefFoulRec);
    }

    public static double getMeanDurationTime(int quarter, int startTime, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int previousPossessionDuration, int seasonYear, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoulReceived) {

        return MathRnD.fastExp(INTERCEPT //
                + (previousPossessionDuration > -1 ? FastMath.max(5 - previousPossessionDuration, 0) * PREVIOUS_POSSESSION_DURATION : 0d) //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, defFoulReceived) ///
                + FastMath.max(44, ownExpHalfPoints) * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1]  //
                + (ownExpHalfPoints - oppExpHalfPoints) * OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER[quarter - 1] //
                + getStartTimeSpline(quarter)[startTime] //
                + getTimeSinceLastOwnTimeOutSpline(quarter)[timeSinceLastOwnTimeOut] //
                + getTimeSinceLastOppTimeOutSpline(quarter)[timeSinceLastOppTimeOut] //
                + getFactorForLastPossession(defFoulReceived, ownTimeOutLastPossession, startTime, quarter, previousPossessionDuration) //
                + previousPossessionDuration * PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1]  //
                + PossessionOutcomeModelUtils.square(FastMath.max(35 - startTime, 0)) * LAST_THIRTY_FIVE_SECONDS_OF_QUARTER_INTERACTION_QUARTER[quarter - 1] //
                + PossessionOutcomeModelUtils.square(FastMath.max(24 - startTime, 0)) * LAST_TWENTY_FOUR_SECONDS_OF_QUARTER_INTERACTION_QUARTER[quarter - 1] //
                + FastMath.min(ownScoreDiffBeforePlay, 0) * OWN_SCORE_DIFF_BEFORE_PLAY_INTERACTION_QUARTER[quarter - 1]//
                + SEASON_YEAR_ARRAY[seasonYear - 2015]
        );
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOwnTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOppTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double getFactorForLastPossession(boolean defFoulReceived, boolean ownTimeOutLastPossession, int startTime, int quarter, int previousPossessionDuration) {
        if (defFoulReceived || ownTimeOutLastPossession) {
            double commonFactor = FastMath.max(10 - previousPossessionDuration, 0) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_LESS_THAN_TEN_SECONDS_INTERACTION_QUARTER[quarter - 1] +//
                    FastMath.max(10, previousPossessionDuration) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER[quarter - 1];

            if (defFoulReceived) {
                double startTimeFactor = START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER[quarter - 1] * startTime;
                return startTimeFactor + commonFactor;
            } else {
                double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * previousPossessionDuration;
                double startTimeFactor = START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * startTime;
                return previousDurationFactor + startTimeFactor + commonFactor;
            }
        } else {
            return 0;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean defFoulReceived) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (defFoulReceived) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
