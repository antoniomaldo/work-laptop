package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.deffensivefoul.zeroduration;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationZeroDefensiveFoulReceivedModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {-2.546732d, -1.306074e-08d, 1.591054d, -2.60995d, -1.960682d, 0.5816798d, 0.03749315d, 1.339667d, -0.4661394d, -0.6731555d, 2.436141d, -0.0007467381d, 0.007721048d, 0.0116037d, 0.01965882d, -0.006691094d, -0.006153584d, -0.006670698d, -0.01618378d, 0.16504d, 0.1817568d, -1.761784d, -2.7617d, -1.087904d, -1.43835d, -0.9318923d, -1.84646d, -0.9723961d, -3.72446d, -1.014715d, -2.181749d, -0.6407875d, -3.355125d, -0.06684161d, -1.112335d, -0.3546761d, -3.254108d, 3.002533d, 1.869004d, 3.158537d, 0.5924946d, 3.505789d, 3.204246d, 4.26291d, 1.701873d, 3.245339d, 3.10088d, 2.468729d, 1.502231d, 3.077897d, 2.709203d, 1.503824d, 1.881124d, 3.228752d, 3.211394d, 2.141457d, 1.477993d, 3.24775d, 2.588315d, 1.550957d, 2.290843d, 3.191994d, 3.360571d, 2.199258d, 1.783218d, 3.519696d, 2.48647d, 1.838184d, -0.9521761d, -1.407652d, -2.408905d, -1.506174d, -0.594319d, -1.083497d, -1.857625d, -1.442649d, -1.102921d, -1.088419d, -2.033253d, -1.48666d, -0.4788226d, -1.000566d, -1.569031d, -1.280785d, -0.9840623d, -1.100493d, -2.307181d, -1.677602d, -0.02142037d, -1.20541d, -1.712073d, -2.338691d, 0.333842d, 0.1032844d, 0.1536481d, 0.02965424d, -0.01761786d, -0.01387833d, -0.01119113d, -0.01476095d, -0.001720318d, -0.0005200684d, -0.0002444756d, -0.0005520932d, 0.1284309d, 0.1983589d, 0.1580689d, 0.09607212d, -0.0004245948d, -0.0325387d, -0.03528397d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double START_TIME_CUBED = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double[] QUARTER_FACTOR = {0d, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double LAST_FIVE_SECONDS_FIRST_THREE_QUARTERS = COEF[COUNTER++];
    private static final double LAST_FIVE_SECONDS_FOURTH_QUARTER = COEF[COUNTER++];

    private static final double[] FIRST_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[0], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[0], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[0], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[1], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[1], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[1], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[2], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[2], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[2], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[3], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[3], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[3], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SIXTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SIXTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SIXTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SIXTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SIXTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SIXTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], SIXTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], SIXTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], SIXTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], SIXTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] OPP_TEAM_IN_BONUS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double OWN_SCORE_WITHIN_TEN_LAST_TWO_MINUTES = COEF[COUNTER++];

    private static final double LAST_MINUTE_WINNING_BY_LESS_THAN_FIVE_FALSE = COEF[COUNTER++];
    private static final double LAST_MINUTE_WINNING_BY_LESS_THAN_FIVE_TRUE = COEF[COUNTER++];

    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    static {
        for (int time = 0; time <= 720; time++) {
            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();

        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        int oppTeamInBonus = gameState.getOppTeamInBonus();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean defFoulReceived = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getProbability(quarter, startTime, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, previousPossessionDuration, oppTeamInBonus, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, defFoulReceived);
    }

    public static double getProbability(int quarter, int startTime, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, int previousPossessionDuration, int oppTeamInBonus, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoulReceived) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + Math.pow(startTime, 3) * START_TIME_CUBED //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, defFoulReceived) ///
                + QUARTER_FACTOR[quarter - 1] //
                + ownExpHalfPoints * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] //
                + (ownExpHalfPoints - oppExpHalfPoints) * OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER[quarter - 1] //
                + (quarter < 4 ? LAST_FIVE_SECONDS_FIRST_THREE_QUARTERS : LAST_FIVE_SECONDS_FOURTH_QUARTER) * FastMath.max(0, 5 - startTime) //
                + getStartTimeSpline(quarter)[startTime] //
                + getTimeSinceLastOwnTimeOutSpline(quarter)[timeSinceLastOwnTimeOut] //
                + getTimeSinceLastOppTimeOutSpline(quarter)[timeSinceLastOppTimeOut] //
                + oppTeamInBonus * OPP_TEAM_IN_BONUS_INTERACTION_QUARTER[quarter - 1] //
                + previousPossessionDuration * PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1]//
                + getFactorForLastPossession(defFoulReceived, ownTimeOutLastPossession, startTime, quarter, previousPossessionDuration) //
                + (quarter == 4 ? FastMath.max(120 - startTime, 0) : 0) * FastMath.min(10, FastMath.max(-10, ownScoreDiffBeforePlay)) * OWN_SCORE_WITHIN_TEN_LAST_TWO_MINUTES //
                + (quarter == 4 && startTime < 60 ? (60 - startTime) * (ownScoreDiffBeforePlay > 0 && ownScoreDiffBeforePlay < 5 ? LAST_MINUTE_WINNING_BY_LESS_THAN_FIVE_TRUE : LAST_MINUTE_WINNING_BY_LESS_THAN_FIVE_FALSE) : 0d)//
        ); //

        return exp / (1 + exp);
    }

    private static double getFactorForLastPossession(boolean defFoulReceived, boolean ownTimeOutLastPossession, int startTime, int quarter, int previousPossessionDuration) {
        if (defFoulReceived || ownTimeOutLastPossession) {

            if (defFoulReceived) {
                return START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER[quarter - 1] * startTime;
            } else {
                return PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * previousPossessionDuration;
            }
        } else {
            return 0;
        }
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOwnTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOppTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean defFoulReceived) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (defFoulReceived) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }

}
