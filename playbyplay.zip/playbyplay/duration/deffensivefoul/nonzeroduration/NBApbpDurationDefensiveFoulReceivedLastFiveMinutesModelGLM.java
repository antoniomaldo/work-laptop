package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.deffensivefoul.nonzeroduration;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationDefensiveFoulReceivedLastFiveMinutesModelGLM implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {2.406117d, -0.009774403d, -0.1681092d, 0.1595328d, 0.1172157d, -0.2852697d, -0.1563633d, 0.00798179d, 0.1541726d, 0.09111496d, 0.1790467d, 0.01878832d, 0.1266589d, 0.2962548d, 0.3324303d, 0.1914613d, 0.2463567d, 0.1438876d, -0.002584735d, -0.01762923d, -0.01190498d, -0.1381104d, 0.6104766d, 0.06959325d, -0.26661d, 0.09185625d, 0.1401795d, 0.2412611d, 0.2728914d, 0.3171577d, -0.09409062d, 0.1416394d, -0.06672368d, 0.3448333d, 0.07927121d, -0.2522665d, -0.003323231d, 0.3941544d, 0.2747924d, 0.05497682d, 0.9762015d, -0.01943023d, -0.2871041d, 0.01607374d, 0.02235904d, -0.01440241d, -0.0410411d, -0.01972969d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double PREVIOUS_DURATION_LESS_THAN_TEN = COEF[COUNTER++];

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 24, 300, 719}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 24, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double MAX_TWO_MINUTES_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_ONE_MINUTE_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_FORTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_FIVE_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final double WINNING_BY_LESS_THAN_FOUR_LAST_MINUTE = COEF[COUNTER++];

    private static final IntegerSpline OWN_SCORE_DIFF_LAST_MINUTE_FALSE_SPLINE = new IntegerBoundedSpline(new double[] {-52, -10, -5, -2, 0, 2, 5, 10, 52}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_LAST_MINUTE_TRUE_SPLINE = new IntegerBoundedSpline(new double[] {-52, -10, -5, -2, 0, 2, 5, 10, 52}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double TIED_GAME_LAST_MINUTE = COEF[COUNTER++];
    private static final double LOSING_LAST_MINUTE = COEF[COUNTER++];
    private static final double LOSING_FALSE_LAST_POSSESSION = COEF[COUNTER++];
    private static final double LOSING_TRUE_LAST_POSSESSION = COEF[COUNTER++];
    private static final double LOSING_BY_ONE_OR_TWO_LAST_POSSESSION = COEF[COUNTER++];

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_LAST_MINUTE_FALSE_SPLINE_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_LAST_MINUTE_TRUE_SPLINE_ARRAY = new double[721];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE.value(time);
        }
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_LAST_MINUTE_FALSE_SPLINE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_LAST_MINUTE_FALSE_SPLINE.value(ownScoreDiff);
            OWN_SCORE_DIFF_LAST_MINUTE_TRUE_SPLINE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_LAST_MINUTE_TRUE_SPLINE.value(ownScoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 1.97767526;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(gameState, team) / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    private static double getMeanDurationTime(NbaPBPGameState gameState, Team team) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        return getMeanDurationTime(simpleGameState);
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(startTime, ownExpHalfPoints, ownScoreDiffBeforePlay, previousPossessionDuration, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefensiveFoulReceivedLastPossession);
    }

    public static double getMeanDurationTime(int startTime, double ownExpHalfPoints, int ownScoreDiffBeforePlay, double previousPossessionDuration, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, boolean oppShotMissedLastPossession, boolean oppThreePointsLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoulReceived) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + ownExpHalfPoints * OWN_EXP_HALF_POINTS //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, defFoulReceived) //
                + FastMath.max(10 - previousPossessionDuration, 0) * PREVIOUS_DURATION_LESS_THAN_TEN //
                + TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] //
                + TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] //
                + FastMath.max(120 - startTime, 0) * MAX_TWO_MINUTES_MINUS_START_TIME_AND_ZERO //
                + FastMath.max(60 - startTime, 0) * MAX_ONE_MINUTE_MINUS_START_TIME_AND_ZERO //
                + FastMath.max(40 - startTime, 0) * MAX_FORTY_MINUS_START_TIME_AND_ZERO //
                + FastMath.max(5 - startTime, 0) * MAX_FIVE_MINUS_START_TIME_AND_ZERO //
                + (startTime < 60 && startTime > 24 && (ownScoreDiffBeforePlay == 1 || ownScoreDiffBeforePlay == 2 || ownScoreDiffBeforePlay == 3) ? WINNING_BY_LESS_THAN_FOUR_LAST_MINUTE : 0d) //
                + (startTime < 60 ? OWN_SCORE_DIFF_LAST_MINUTE_TRUE_SPLINE_ARRAY : OWN_SCORE_DIFF_LAST_MINUTE_FALSE_SPLINE_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + (ownScoreDiffBeforePlay == 0 ? FastMath.max(60 - startTime, 0) * TIED_GAME_LAST_MINUTE : 0d) //
                + (ownScoreDiffBeforePlay < 0 ? FastMath.max(60 - startTime, 0) * LOSING_LAST_MINUTE : 0d) //
                + (ownScoreDiffBeforePlay < 0 ? LOSING_TRUE_LAST_POSSESSION : LOSING_FALSE_LAST_POSSESSION) * FastMath.max(24 - startTime, 0) //
                + (ownScoreDiffBeforePlay == -1 || ownScoreDiffBeforePlay == -2 ? FastMath.max(24 - startTime, 0) * LOSING_BY_ONE_OR_TWO_LAST_POSSESSION : 0d)); //

        return exp;
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean defFoulReceived) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (defFoulReceived) {
            return DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }

}
