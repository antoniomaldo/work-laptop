package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.deffensivefoul.nonzeroduration;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpDurationDefensiveFoulReceivedModel implements PBPDurationModel<NbaPBPGameState> {

    private static final NBApbpDurationDefensiveFoulReceivedWoLastFiveMinutesModelGLM MODEL_WO_LAST_FIVE_MINUTES = new NBApbpDurationDefensiveFoulReceivedWoLastFiveMinutesModelGLM();
    private static final NBApbpDurationDefensiveFoulReceivedLastFiveMinutesModelGLM MODEL_LAST_FIVE_MINUTES = new NBApbpDurationDefensiveFoulReceivedLastFiveMinutesModelGLM();

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if (gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        }
        return generatedTime;
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if (gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        }
        return generatedTime;
    }
}
