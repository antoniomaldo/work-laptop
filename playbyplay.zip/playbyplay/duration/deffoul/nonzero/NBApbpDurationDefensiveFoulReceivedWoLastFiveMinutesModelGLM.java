package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.deffensivefoul.nonzeroduration;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationDefensiveFoulReceivedWoLastFiveMinutesModelGLM implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {0.9522448d, -0.3818143d, 0.2417405d, 0.1474055d, -0.2268351d, -0.4229987d, -0.3780307d, -0.1630018d, -0.1152827d, -0.1563616d, -0.2244422d, -0.1163068d, -0.2552962d, 0.196315d, -0.01193321d, 0.08898918d, 0.00710111d, 0.1288078d, 0.06395215d, -0.2187695d, -0.1163383d, -0.1044911d, 1.089099d, 1.905472d, 2.156448d, 2.241219d, 2.121638d, 2.220743d, 2.103121d, 2.379847d, 1.155592d, 1.709065d, 2.157149d, 2.193359d, 2.127906d, 2.20673d, 2.083105d, 2.267536d, 1.36694d, 1.88291d, 2.342242d, 2.307927d, 2.27454d, 2.250814d, 2.216523d, 2.349082d,  -0.5775683d, 2.466387d, 2.320541d, 2.390415d, 2.228679d, 2.411409d, -0.0115986d, -0.01098088d, -0.01314809d, -0.01355133d, 0.003552549d, 0.001675836d, -7.81342e-05d, 5.286062e-05d, 0.01712684d, 0.01518055d, 0.01618839d, 0.01349622d, 0.004419991d, 0.003470214d, 0.0038802d, 0.006141758d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double START_PERIOD_LAST_POSSESSION = COEF[COUNTER++];

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 24, 300, 719}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 24, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double MAX_FORTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_FORTY_SECONDS = COEF[COUNTER++];
    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_TWELVE_SECONDS = COEF[COUNTER++];

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 100, 350, 650, 720}, new double[] {0d, 0d, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OPP_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_LESS_THAN_TEN_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LOSING_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE.value(time);
            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
        }
    }

    private static final double SHAPE_PARAMETER = 2.93449963;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(gameState, team) / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    private static double getMeanDurationTime(NbaPBPGameState gameState, Team team) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        return getMeanDurationTime(simpleGameState);
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean firstPlayOfQuarter = gameState.getFirstPlayOfPeriod();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(quarter, startTime, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, previousPossessionDuration, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, oppShotMissedLastPossession, firstPlayOfQuarter, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefensiveFoulReceivedLastPossession);
    }

    public static double getMeanDurationTime(int quarter, int startTime, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, double previousPossessionDuration, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, boolean oppShotMissedLastPossession, boolean firstPlayOfQuarter, boolean oppThreePointsLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsLastPossession, boolean defFoulReceived) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, oppTurnoverLastPossession, oppThreePointsLastPossession, oppTwoPointsLastPossession, ownTimeOutLastPossession, firstPlayOfQuarter, defFoulReceived) //
                + TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] //
                + TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] //
                + FastMath.max(40 - startTime, 0) * MAX_FORTY_MINUS_START_TIME_AND_ZERO //
                + (startTime < 40 ? LESS_THAN_FORTY_SECONDS : 0d) //
                + FastMath.max(24 - startTime, 0) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO //
                + (startTime < 12 ? LESS_THAN_TWELVE_SECONDS : 0d) //
                + getStartTimeSpline(quarter)[startTime] //
                + ownExpHalfPoints * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] //
                + (ownExpHalfPoints - oppExpHalfPoints) * OPP_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER[quarter - 1] //
                + FastMath.max(10 - previousPossessionDuration, 0) * PREVIOUS_DURATION_LESS_THAN_TEN_INTERACTION_QUARTER[quarter - 1]//
                + FastMath.min(0, ownScoreDiffBeforePlay) * LOSING_INTERACTION_QUARTER[quarter - 1]//
        ); //

        return exp;
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut, boolean startPeriod, boolean defFoulReceived) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else if (startPeriod) {
            return START_PERIOD_LAST_POSSESSION;
        } else if (defFoulReceived) {
            return DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }

}
