package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.threepoints;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

class NBApbpDurationThreePointsScoredWoLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {-1.046819d, 0.01836925d, -0.3655014d, 0.2083493d, 0.1294066d, -0.09266828d, -0.2957464d, -0.2490738d, 0.1071535d, -0.3201055d, -0.09718093d, -0.1695457d, -0.04962426d, 4.406728d, -0.00115775d, -0.1001055d, -0.09899269d, -0.08552479d, -0.01193768d, -0.01173768d, -0.01597145d, -0.01440809d, 0.002375444d, 0.001488289d, 0.003234742d, 0.0002578767d, 0.008655084d, 0.03180625d, 0.0006190606d, -0.01766465d, -0.002909023d, -0.009946492d, -0.003988753d, -0.009426132d, 1.933246d, 2.045327d, 2.298126d,  2.781508d, 2.869666d, 2.933658d,  4.347859d, 4.377658d, 4.649248d,  4.516312d, 4.662069d, 4.813506d, 1.283528d, 4.557426d, 4.623036d, 4.789509d, -0.3143224d, 4.474858d, 4.674396d, 4.775092d, 0.3414462d, 4.446856d, 4.605781d, 4.752848d, -0.03827781d, 4.545387d, 4.615526d, 4.728908d,  -0.136624d, -0.03727202d, -0.0767976d, -0.0595826d, -0.1436775d, -0.106247d, -0.116455d, -0.1510438d, -0.2006528d, -0.05904635d, -0.09861996d, -0.02673651d, -0.163195d, -0.1217384d, -0.1160639d, -0.4620106d, -0.1979072d, -0.04857469d, -0.05954372d, 0.9008018d, -0.007821458d, -0.08106358d, -0.1218281d, -0.02387381d, -0.09780353d, -0.1494505d, -0.144378d, -0.1407925d, -0.0749554d, -0.08290137d, -0.129516d, -0.01476212d, -0.1794123d, -0.1629943d, -0.1064965d, -0.19297d, 0.03408977d, -0.1178996d, -0.2205178d, -1.002347d, -0.00462307d, -0.005815386d, -0.004566203d, -0.005797385d, -0.002206334d, -0.001977013d, -0.001761851d, -0.001574547d, -0.02733283d, -0.02463369d, -0.0274422d, -0.03097441d, 8.701477e-05d, 0.0001477124d, 0.0001555669d, 8.356813e-05d, 0.1520724d, 0.09835324d, 0.2017448d, 0.192665d, 0.3203665d, -0.2797246d, 0.3337717d, 0.1048897d, 0.4056523d, 0.4194086d, 0.177401d, 1.030463d, -0.002036334d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double PREVIOUS_POSSESSION_DURATION = COEF[COUNTER++];

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double MAX_FOURTY_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_FOURTY_SECONDS = COEF[COUNTER++];

    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final double[] QUARTER_ARRAYS = {0d, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OPP_TEAM_IN_BONUS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_DEF_FOULS_RECEIVED_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};
    private static final double[] SECOND_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};
    private static final double[] THIRD_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};
    private static final double[] FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 60, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[0], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[0], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[0], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[0], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 60, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[1], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[1], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[1], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[1], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 60, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[2], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[2], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[2], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[2], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 10, 24, 60, 100, 600, 720}, new double[] {FIRST_COEF_START_TIME_SPLINE_BY_QUARTER[3], SECOND_COEF_START_TIME_SPLINE_BY_QUARTER[3], THIRD_COEF_START_TIME_SPLINE_BY_QUARTER[3], FOURTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], FIFTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SIXTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], SEVENTH_COEF_START_TIME_SPLINE_BY_QUARTER[3], EIGHTH_COEF_START_TIME_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS = new IntegerBoundedSpline(new double[] {-58, -20, 0, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER = new IntegerBoundedSpline(new double[] {-58, -20, 0, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED = COEF[COUNTER++];

    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {

            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
        }
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER.value(ownScoreDiff);

        }
    }

    private static final double SHAPE_PARAMETER = 5.34416508;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;

        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double scaleParameter = getMeanDurationTime(simpleGameState) / SHAPE_PARAMETER;

        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();

        int ownCumThreePointers = gameState.getOwnThreePointers();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        double percentageGamePlayed = gameState.getPercentageGamePlayed();

        int oppTeamInBonus = gameState.getOppTeamInBonus();
        int periodOwnDefensiveFoulsReceived = gameState.getPeriodOwnDefensiveFoulsReceived();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefFoulRec = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(quarter, startTime, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, percentageGamePlayed, oppTeamInBonus, periodOwnDefensiveFoulsReceived, ownCumThreePointers, gameState.getCurrentNBASeasonYear(), oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefFoulRec);
    }

    public static double getMeanDurationTime(int quarter, int startTime, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int previousPossessionDuration, double percGamePlayed, int oppTeamInBonus, int periodOwnDefensiveFoulsReceived, int ownCumThreePointers, int seasonYear, boolean oppShotMissedLastPossession, boolean oppThreePointsScoredLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsScoredLastPossession, boolean ownDefFoulRec) {

        return MathRnD.fastExp(INTERCEPT //
                + (previousPossessionDuration > -1 ? FastMath.max(5 - previousPossessionDuration, 0) * PREVIOUS_POSSESSION_DURATION : 0d) //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, ownDefFoulRec, oppTurnoverLastPossession, oppThreePointsScoredLastPossession, oppTwoPointsScoredLastPossession, ownTimeOutLastPossession) //
                + (startTime < 40 ? (40 - startTime) * MAX_FOURTY_MINUS_START_TIME_AND_ZERO + LESS_THAN_FOURTY_SECONDS : 0d) //
                + (startTime < 24 ? (24 - startTime) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO : 0d) //

                + QUARTER_ARRAYS[quarter - 1] +//
                +SEASON_YEAR_ARRAY[seasonYear - 2015]

                + FastMath.max(44, ownExpHalfPoints) * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1]  //
                + (ownExpHalfPoints - oppExpHalfPoints) * OWN_EXP_HALF_POINTS_DIFF_INTERACTION_QUARTER[quarter - 1] //
                + oppTeamInBonus * OPP_TEAM_IN_BONUS_INTERACTION_QUARTER[quarter - 1] //
                + FastMath.min(periodOwnDefensiveFoulsReceived, 4) * OWN_DEF_FOULS_RECEIVED_INTERACTION_QUARTER[quarter - 1]//
                + (quarter < 4 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_THREE_QUARTERS_ARRAY : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_QUARTER_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + getStartTimeSpline(quarter)[startTime]  //
                + getTimeSinceLastOwnTimeOutSpline(quarter)[timeSinceLastOwnTimeOut] //
                + getTimeSinceLastOppTimeOutSpline(quarter)[timeSinceLastOppTimeOut] //
                + getFactorForLastPossession(ownDefFoulRec, ownTimeOutLastPossession, startTime, quarter, previousPossessionDuration, ownScoreDiffBeforePlay, percGamePlayed) //
                + previousPossessionDuration * PREVIOUS_DURATION_INTERACTION_QUARTER[quarter - 1]  //
                + ownCumThreePointers * (1 - percGamePlayed) * OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED);
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOwnTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOppTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double getFactorForLastPossession(boolean ownDefFoulRec, boolean ownTimeOutLastPossession, int startTime, int quarter, int previousPossessionDuration, int ownScoreDiffBeforePlay, double percGamePlayed) {
        if (ownDefFoulRec || ownTimeOutLastPossession) {
            double commonFactor = FastMath.max(10, previousPossessionDuration) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS_INTERACTION_QUARTER[quarter - 1];

            if (ownDefFoulRec) {
                return commonFactor;
            } else {
                double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * previousPossessionDuration;
                double startTimeFactor = START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER[quarter - 1] * startTime;
                return previousDurationFactor + startTimeFactor + commonFactor;
            }
        } else {
            return 0;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean ownDefFoulRec, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (ownDefFoulRec) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
