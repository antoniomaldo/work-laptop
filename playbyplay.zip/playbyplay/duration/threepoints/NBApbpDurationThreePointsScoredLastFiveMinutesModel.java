package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.threepoints;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationThreePointsScoredLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {3.525944d, -0.01393349d, 0.04456182d, 0.007390152d, 0.00388977d, -0.05594258d, -0.002817751d, -0.005755917d, -0.06229653d, -0.081685d, -0.09743102d, -0.03566787d, -0.2837408d, 0.1537863d, 0.0764533d, -0.3692269d, -0.3583352d, -0.2416346d, -0.02058071d, 0.001650317d, -0.04129323d, -0.01755064d, -0.03495664d, -0.293176d, -0.09661914d, -0.3548596d, -0.09825236d, -0.1301615d, -0.03156713d, -0.1887641d, -0.0752722d, 0.1192193d, 0.1536802d, 0.1828754d, -0.1840623d, 0.495942d, -1.053324d, 0.0632094d, -0.3277327d, -0.1351179d, -0.6128612d, 0.4055629d, 0.1520477d, 0.454081d, -0.6194672d, 1.55685d, -2.056904d, -0.6107711d, 0.3131974d, -0.3061648d, -0.2166991d, 0.06909932d, 0.04663565d, 0.04662785d, -0.04854348d, -0.608281d, 1.284202d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS = COEF[COUNTER++];

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double LESS_THAN_FORTY_SECONDS = COEF[COUNTER++];
    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final double MAX_TEN_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_FIVE_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_TWELVE_SECONDS = COEF[COUNTER++];

    private static final double WINNING_IN_LAST_POSSESSION = COEF[COUNTER++];
    private static final double LOSING_BY_LESS_THAN_FIVE_IN_LAST_POSSESSION = COEF[COUNTER++];

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 5, 10, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 5, 10, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 5, 10, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE.value(time);
        }

        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE.value(ownScoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 5.19554381;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double meanDuration = getMeanDurationTime(simpleGameState);

        double scaleParameter = meanDuration / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double meanDuration = getMeanDurationTime(simpleGameState);

        double scaleParameter = meanDuration / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int startTime = gameState.getPeriodSecondsRemaining();
        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefFoulRec = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(startTime, ownExpHalfPoints, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefFoulRec);
    }

    public static double getMeanDurationTime(int startTime, double ownExpHalfPoints, int ownScoreDiffBeforePlay, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int previousPossessionDuration, boolean oppShotMissedLastPossession, boolean oppThreePointsScoredLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsScoredLastPossession, boolean ownDefFoulRec) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + FastMath.max(44, ownExpHalfPoints) * OWN_EXP_HALF_POINTS //
                + TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] //
                + TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, ownDefFoulRec, oppTurnoverLastPossession, oppThreePointsScoredLastPossession, oppTwoPointsScoredLastPossession, ownTimeOutLastPossession) //
                + getFactorForLastPossession(ownTimeOutLastPossession, startTime, previousPossessionDuration)//
                + (startTime < 40 ? LESS_THAN_FORTY_SECONDS : 0d) //
                + (startTime < 24 ? (24 - startTime) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime < 10 ? (10 - startTime) * MAX_TEN_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime < 12 ? LESS_THAN_TWELVE_SECONDS : 0d) //
                + (startTime < 5 ? (5 - startTime) * MAX_FIVE_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime < 24 && ownScoreDiffBeforePlay > 0 ? WINNING_IN_LAST_POSSESSION : 0d) //
                + (startTime < 24 && ownScoreDiffBeforePlay < 0 && ownScoreDiffBeforePlay > -5 ? LOSING_BY_LESS_THAN_FIVE_IN_LAST_POSSESSION : 0d) //

                + (startTime < 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + (startTime < 120 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiffBeforePlay + 50] : 0d)//
        );
        return exp;
    }

    private static double getFactorForLastPossession(boolean ownTimeOutLastPossession, int startTime, int previousPossessionDuration) {
        if (ownTimeOutLastPossession) {
            double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER * previousPossessionDuration;
            double startTimeFactor = START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER * startTime;
            return previousDurationFactor + startTimeFactor;
        } else {
            return 0;
        }

    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean ownDefFoulRec, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (ownDefFoulRec) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
