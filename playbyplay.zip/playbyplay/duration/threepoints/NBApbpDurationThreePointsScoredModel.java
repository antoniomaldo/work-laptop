package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.threepoints;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpDurationThreePointsScoredModel implements PBPDurationModel<NbaPBPGameState> {

    private static final NBApbpDurationThreePointsScoredWoLastFiveMinutesModel MODEL_WO_LAST_FIVE_MINUTES = new NBApbpDurationThreePointsScoredWoLastFiveMinutesModel();
    private static final NBApbpDurationThreePointsScoredLastFiveMinutesModel MODEL_LAST_FIVE_MINUTES = new NBApbpDurationThreePointsScoredLastFiveMinutesModel();

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        if (gameState.getSecondsRemainingInPeriod() > 300) {
            return MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, team, null);
        } else {
            return MODEL_LAST_FIVE_MINUTES.generateTime(gameState, team, null);
        }
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        if (gameState.getSecondsRemainingInPeriod() > 300) {
            return MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, null);
        } else {
            return MODEL_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, null);
        }
    }
}
