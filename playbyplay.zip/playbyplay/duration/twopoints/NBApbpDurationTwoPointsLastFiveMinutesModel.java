package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.twopoints;

import java.util.Random;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.GammaRNG;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDurationTwoPointsLastFiveMinutesModel implements PBPDurationModel<NbaPBPGameState> {

    private static final double[] COEF = {3.32583d, -0.01057611d, -0.01968257d, 0.03068383d, -0.02502994d, 0.02468763d, -0.09046803d, -0.02607713d, 0.06163368d, -0.07003472d, 0.01216372d, -0.05831249d, 0.03114555d, -0.2852376d, 0.1812037d, 0.1196972d, -0.2170502d, -0.2187332d, -0.3958167d, -0.00410385d, -0.002310156d, -0.0001233373d, -0.01881267d, 0.001167138d, -0.09210831d, -0.0170924d, -0.06186395d, -0.2565281d, -0.02960973d, 0.03539826d, -0.787273d, -0.2151954d, -0.01309954d, -0.09166806d, -0.02760614d, -0.1733485d, -0.04085265d, 0.09604906d, 0.137695d, 0.1335713d, -0.04450402d, 0.2301919d, -0.7656352d, -0.05964601d, 0.03140726d, -0.1545442d, -0.4128577d, 0.4318854d, -0.1110737d, 0.03482583d, 0.4852436d, -0.180424d, 0.426831d, -0.6564052d, 0.02990838d, -0.2286802d, -0.3668401d, 0.07556602d, 0.04403716d, 0.07227859d, -0.3515818d, -0.0593404d, 0.4622938d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS = COEF[COUNTER++];
    private static final double OPP_TEAM_IN_BONUS = COEF[COUNTER++];

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double OPP_SHOT_MISSED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_THREE_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TWO_POINTS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TIMEOUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS = COEF[COUNTER++];
    private static final double PREVIOUS_DURATION = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];
    private static final double START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER = COEF[COUNTER++];

    private static final double LESS_THAN_FORTY_SECONDS = COEF[COUNTER++];
    private static final double MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];

    private static final double MAX_TEN_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double MAX_FIVE_MINUS_START_TIME_AND_ZERO = COEF[COUNTER++];
    private static final double LESS_THAN_TWELVE_SECONDS = COEF[COUNTER++];

    private static final double MORE_THAN_NINETY_SECONDS_LEFT = COEF[COUNTER++];

    private static final double WINNING_IN_LAST_POSSESSION = COEF[COUNTER++];
    private static final double LOSING_BY_LESS_THAN_FIVE_IN_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LAST_TWO_SEASONS =  COEF[COUNTER++];

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 5, 10, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 5, 10, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 5, 10, 20, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY = new double[721];

    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE.value(time);
        }

        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE.value(ownScoreDiff);
        }
    }

    private static final double SHAPE_PARAMETER = 3.73239967;

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        ISimplePBPGameState simpleGameState = new SimplePBPGameState(gameState, team);
        double meanDuration = getMeanDurationTime(simpleGameState);
        double scaleParameter = meanDuration / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        double meanDuration = getMeanDurationTime(simpleGameState);
        double scaleParameter = meanDuration / SHAPE_PARAMETER;
        Random random = new Random();
        return FastMath.max(1, MathRnD.roundPositive(GammaRNG.FAST_RNG.generate(random, SHAPE_PARAMETER, scaleParameter)));
    }

    public static double getMeanDurationTime(ISimplePBPGameState gameState) {

        int startTime = gameState.getPeriodSecondsRemaining();
        int oppTeamInBonus = gameState.getOppTeamInBonus();
        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int previousPossessionDuration = gameState.getPreviousPossessionDuration();

        Pair<Integer, Integer> timeSinceLastTimeOuts = gameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppShotMissedLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppThreePointsScoredLastPossession = gameState.getOppScoredThreePointsLastPossession();
        boolean ownTimeOutLastPossession = gameState.getOwnTimeOutCalledLastPossession();
        boolean oppTurnoverLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean oppTwoPointsScoredLastPossession = gameState.getOppScoredTwoPointsLastPossession();
        boolean ownDefFoulRec = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getMeanDurationTime(startTime, ownExpHalfPoints, oppTeamInBonus, ownScoreDiffBeforePlay, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, previousPossessionDuration, gameState.getCurrentNBASeasonYear(), oppShotMissedLastPossession, oppThreePointsScoredLastPossession, ownTimeOutLastPossession, oppTurnoverLastPossession, oppTwoPointsScoredLastPossession, ownDefFoulRec);
    }

    public static double getMeanDurationTime(int startTime, double ownExpHalfPoints, int oppTeamInBonus, int ownScoreDiffBeforePlay, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int previousPossessionDuration, int seasonYear, boolean oppShotMissedLastPossession, boolean oppThreePointsScoredLastPossession, boolean ownTimeOutLastPossession, boolean oppTurnoverLastPossession, boolean oppTwoPointsScoredLastPossession, boolean ownDefFoulRec) {

        double exp = MathRnD.fastExp(INTERCEPT //
                + FastMath.max(44, ownExpHalfPoints) * OWN_EXP_HALF_POINTS //
                + OPP_TEAM_IN_BONUS * oppTeamInBonus //
                + TIME_SINCE_OWN_TIMEOUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] //
                + TIME_SINCE_OPP_TIMEOUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] //
                + getPreviousPossessionCoefficient(oppShotMissedLastPossession, ownDefFoulRec, oppTurnoverLastPossession, oppThreePointsScoredLastPossession, oppTwoPointsScoredLastPossession, ownTimeOutLastPossession) //
                + getFactorForLastPossession(ownDefFoulRec, ownTimeOutLastPossession, startTime, previousPossessionDuration)//
                + previousPossessionDuration * PREVIOUS_DURATION //
                + (startTime < 40 ? LESS_THAN_FORTY_SECONDS : 0d) //
                + (startTime < 24 ? (24 - startTime) * MAX_TWENTY_FOUR_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime < 10 ? (10 - startTime) * MAX_TEN_MINUS_START_TIME_AND_ZERO + LESS_THAN_TWELVE_SECONDS : 0d) //
                + (startTime < 5 ? (5 - startTime) * MAX_FIVE_MINUS_START_TIME_AND_ZERO : 0d) //
                + (startTime > 90 ? MORE_THAN_NINETY_SECONDS_LEFT : 0d) //
                + (startTime < 24 && ownScoreDiffBeforePlay > 0 ? WINNING_IN_LAST_POSSESSION : 0d) //
                + (startTime < 24 && ownScoreDiffBeforePlay < 0 && ownScoreDiffBeforePlay > -5 ? LOSING_BY_LESS_THAN_FIVE_IN_LAST_POSSESSION : 0d) //

                + (seasonYear >= 2018 ? LAST_TWO_SEASONS: 0d) //

                + (startTime < 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_TRUE_ARRAY : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_A_MINUTE_FALSE_ARRAY)[ownScoreDiffBeforePlay + 50] //
                + (startTime < 120 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LESS_THAN_TWO_MINUTES_TRUE_ARRAY[ownScoreDiffBeforePlay + 50] : 0d)//
        );
        return exp;
    }

    private static double getFactorForLastPossession(boolean ownDefFoulRec, boolean ownTimeOutLastPossession, int startTime, int previousPossessionDuration) {
        if (ownDefFoulRec || ownTimeOutLastPossession) {
            double commonFactor = FastMath.max(10, previousPossessionDuration) * LAST_POSS_DEF_FOUL_OR_TIME_OUT_MORE_THAN_TEN_SECONDS;

            if (ownDefFoulRec) {
                double startTimeFactor = START_TIME_GIVEN_DEFENSIVE_FOUL_RECEIVED_INTERACTION_QUARTER * startTime;
                return startTimeFactor + commonFactor;
            } else {
                double previousDurationFactor = PREVIOUS_DURATION_GIVEN_TIMEOUT_INTERACTION_QUARTER * previousPossessionDuration;
                double startTimeFactor = START_TIME_GIVEN_TIMEOUT_INTERACTION_QUARTER * startTime;
                return previousDurationFactor + startTimeFactor + commonFactor;
            }
        } else {
            return 0;
        }
    }

    private static double getPreviousPossessionCoefficient(boolean oppShotMissed, boolean ownDefFoulRec, boolean oppTurnover, boolean oppThreePoints, boolean oppTwoPoints, boolean ownTimeOut) {
        if (oppShotMissed) {
            return OPP_SHOT_MISSED_LAST_POSSESSION;
        } else if (ownDefFoulRec) {
            return OWN_DEFENSIVE_FOUL_RECEIVED_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TURNOVER_LAST_POSSESSION;
        } else if (oppTwoPoints) {
            return OPP_TWO_POINTS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TIMEOUT_LAST_POSSESSION;
        } else if (oppThreePoints) {
            return OPP_THREE_POINTS_LAST_POSSESSION;
        } else {
            return 0d;
        }
    }
}
