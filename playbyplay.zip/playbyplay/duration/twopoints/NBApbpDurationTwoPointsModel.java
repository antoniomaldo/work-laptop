package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.twopoints;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpDurationTwoPointsModel implements PBPDurationModel<NbaPBPGameState> {

    private static final NBApbpDurationTwoPointsWoLastFiveMinutesModel MODEL_WO_LAST_FIVE_MINUTES = new NBApbpDurationTwoPointsWoLastFiveMinutesModel();
    private static final NBApbpDurationTwoPointsLastFiveMinutesModel MODEL_LAST_FIVE_MINUTES = new NBApbpDurationTwoPointsLastFiveMinutesModel();

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if (gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, team, currentPossessionOutcome);
        }
        return generatedTime;
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        int generatedTime;
        if (gameState.getSecondsRemainingInMatch() > 300) {
            generatedTime = MODEL_WO_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        } else {
            generatedTime = MODEL_LAST_FIVE_MINUTES.generateTime(gameState, simpleGameState, currentPossessionOutcome);
        }
        return generatedTime;
    }
}
