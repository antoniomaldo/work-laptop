package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.changepossession;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shotmissed.NBApbpDurationShotMissedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.turnover.NBApbpDurationTurnoverModel;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpDurationChangePossessionModel implements PBPDurationModel<NbaPBPGameState> {

    private static final NBApbpDurationTurnoverModel TURNOVER_MODEL = new NBApbpDurationTurnoverModel();
    private static final NBApbpDurationShotMissedModel SHOT_MISSED_MODEL = new NBApbpDurationShotMissedModel();

    @Override
    public int generateTime(NbaPBPGameState gameState, Team team, PossessionOutcome currentPossessionOutcome) {
        if (currentPossessionOutcome == PossessionOutcome.SHOT_MISSED) {
            return SHOT_MISSED_MODEL.generateTime(gameState, team, PossessionOutcome.SHOT_MISSED);
        } else {
            return TURNOVER_MODEL.generateTime(gameState, team, PossessionOutcome.TURNOVER);
        }
    }

    @Override
    public int generateTime(NbaPBPGameState gameState, ISimplePBPGameState simpleGameState, PossessionOutcome currentPossessionOutcome) {
        if (currentPossessionOutcome == PossessionOutcome.SHOT_MISSED) {
            return SHOT_MISSED_MODEL.generateTime(gameState, simpleGameState, PossessionOutcome.SHOT_MISSED);
        } else {
            return TURNOVER_MODEL.generateTime(gameState, simpleGameState, PossessionOutcome.TURNOVER);
        }
    }
}
