package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.timeout;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpTimeOutModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {-3.564346d, -2.840754d, -2.219872d, -0.7887824d, -1.313283d, -1.59694d, -1.418135d, -1.120335d, 1.633818d, 1.735244d, 2.439186d, 2.292463d, 4.141823d, 3.249845d, 4.592232d, 3.453555d, -0.6588191d, 0.456797d, 1.510664d, 2.266506d, 1.047796d, 0.1080737d, -0.009093701d, -0.04444635d, -0.02452281d, -0.03840343d, -0.05115908d, -0.1588563d, 0.5244258d, -0.07906671d, -0.02726068d, 0.03436946d, -1.773376d, -0.7279177d, -1.182275d, -0.5696945d, -0.1414079d, -0.01925519d, -0.02952596d, -0.01255839d, 0.04950732d, 0.01317708d, 0.01994485d, -0.0841147d, -0.00434464d, -0.01464584d, -0.01521863d, 0.02934008d, 0.01274264d, 0.008634669d, 0.02645505d, 0.2267629d, 0.02563151d, 0.04730152d, 0.03710373d, -5.287418d, -0.7047458d, -2.892671d, 37.09288d, -1.480017d, -2.247888d, -2.033731d, 46.21532d, -0.02804844d, -0.2629005d, -0.5741367d, 2.14427d, -1.47783d, -1.175053d, -1.455031d, -0.1742342d, -3.630375d, -1.603394d, -2.756255d, -0.1160671d, -2.024865d, -1.491939d, -1.019968d, 0.2771882d, 0.007267448d, -0.01792545d, 0.00620137d, 0.004945642d, -0.001189211d, -0.01011277d, -0.01229292d, 0.02056708d, -0.1684632d, -0.0146409d, 0.09517027d, 0.1449378d, -0.9513642d, 0.5734996d, -0.129555d, -0.1718863d, -0.1085005d, 0.1209614d, -0.1825187d, -4.376745d, 0.0004463681d, 0.0003388139d, 0.0002403322d, 0.0003613765d};
    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SHOOTING_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double FIRST_PLAY_QUARTER = COEF[COUNTER++];

    private static final double MAX_TIME_OUTS_IN_QUARTER = COEF[COUNTER++];

    private static final double NO_TIME_OUTS_IN_FIRST_FIVE_MINUTES = COEF[COUNTER++];
    private static final double ONE_TIME_OUT_IN_FIRST_9_MINUTES = COEF[COUNTER++];

    private static final IntegerSpline TIME_SINCE_LAST_OWN_TIME_OUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 60, 120, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline TIME_SINCE_LAST_OPP_TIME_OUT_SPLINE = new IntegerBoundedSpline(new double[] {0, 60, 120, 300, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER_MAP = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double OPP_TEAM_SCORED_LAST_POSSESSION_INTERACTION_OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_FALSE = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_LAST_POSSESSION_INTERACTION_OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_TRUE = COEF[COUNTER++];

    private static final double TIME_OUT_REMAINING_BY_PERC_GAME = COEF[COUNTER++];
    private static final double TIME_OUT_REMAINING_INTERACTION_QUARTER_MAP[] = new double[] {0d, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double TIME_OUT_IN_QUARTER_GREATER_THAN_ZERO_INTERACTION_QUARTER_MAP[] = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] LOSING_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER_MAP = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] WINNING_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER_MAP = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], 0d};
    private static final double[] LOSING_INTERACTION_QUARTER_MAP = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LOSING_BY_MORE_THAN_TEN_INTERACTION_QUARTER_MAP = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LOSING_BY_MORE_THAN_TWENTY_INTERACTION_QUARTER_MAP = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_SPLINE_FIRST_COEF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_SPLINE_SECOND_COEF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_SPLINE_THIRD_COEF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_SPLINE_FOURTH_COEF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_SPLINE_FIFTH_COEF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_SPLINE_SIXTH_COEF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline START_TIME_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {START_TIME_SPLINE_FIRST_COEF[0], START_TIME_SPLINE_SECOND_COEF[0], START_TIME_SPLINE_THIRD_COEF[0], START_TIME_SPLINE_FOURTH_COEF[0], START_TIME_SPLINE_FIFTH_COEF[0], START_TIME_SPLINE_SIXTH_COEF[0]});
    private static final IntegerSpline START_TIME_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {START_TIME_SPLINE_FIRST_COEF[1], START_TIME_SPLINE_SECOND_COEF[1], START_TIME_SPLINE_THIRD_COEF[1], START_TIME_SPLINE_FOURTH_COEF[1], START_TIME_SPLINE_FIFTH_COEF[1], START_TIME_SPLINE_SIXTH_COEF[1]});
    private static final IntegerSpline START_TIME_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {START_TIME_SPLINE_FIRST_COEF[2], START_TIME_SPLINE_SECOND_COEF[2], START_TIME_SPLINE_THIRD_COEF[2], START_TIME_SPLINE_FOURTH_COEF[2], START_TIME_SPLINE_FIFTH_COEF[2], START_TIME_SPLINE_SIXTH_COEF[2]});
    private static final IntegerSpline START_TIME_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 24, 100, 300, 720}, new double[] {START_TIME_SPLINE_FIRST_COEF[3], START_TIME_SPLINE_SECOND_COEF[3], START_TIME_SPLINE_THIRD_COEF[3], START_TIME_SPLINE_FOURTH_COEF[3], START_TIME_SPLINE_FIFTH_COEF[3], START_TIME_SPLINE_SIXTH_COEF[3]});

    private static final IntegerSpline OWN_SCORE_DIFF_SPLINE_LAST_FIVE_MINUTES = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_LAST_MINUTE_SPLINE = new IntegerBoundedSpline(new double[] {-58, -20, -10, -5, 0, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final IntegerSpline START_TIME_SPLINE_LAST_FIVE_MINUTES = new IntegerBoundedSpline(new double[] {0, 24, 100, 200, 720}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final double[] OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_INTERACTION_TIME_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] TIME_SINCE_LAST_OWN_TIME_OUT_SPLINE_ARRAY = new double[721];
    private static final double[] TIME_SINCE_LAST_OPP_TIME_OUT_SPLINE_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] START_TIME_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    private static final double[] START_TIME_SPLINE_LAST_FIVE_MINUTES_ARRAY = new double[721];

    private static final double[] OWN_SCORE_DIFF_SPLINE_LAST_FIVE_MINUTES_ARRAY = new double[101];
    private static final double[] OWN_SCORE_DIFF_LAST_MINUTE_SPLINE_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_LAST_OWN_TIME_OUT_SPLINE_ARRAY[time] = TIME_SINCE_LAST_OWN_TIME_OUT_SPLINE.value(time);
            TIME_SINCE_LAST_OPP_TIME_OUT_SPLINE_ARRAY[time] = TIME_SINCE_LAST_OPP_TIME_OUT_SPLINE.value(time);

            START_TIME_SPLINE_FIRST_QUARTER_ARRAY[time] = START_TIME_SPLINE_FIRST_QUARTER.value(time);
            START_TIME_SPLINE_SECOND_QUARTER_ARRAY[time] = START_TIME_SPLINE_SECOND_QUARTER.value(time);
            START_TIME_SPLINE_THIRD_QUARTER_ARRAY[time] = START_TIME_SPLINE_THIRD_QUARTER.value(time);
            START_TIME_SPLINE_FOURTH_QUARTER_ARRAY[time] = START_TIME_SPLINE_FOURTH_QUARTER.value(time);
            START_TIME_SPLINE_LAST_FIVE_MINUTES_ARRAY[time] = START_TIME_SPLINE_LAST_FIVE_MINUTES.value(time);
        }
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_SPLINE_LAST_FIVE_MINUTES_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_SPLINE_LAST_FIVE_MINUTES.value(ownScoreDiff);
            OWN_SCORE_DIFF_LAST_MINUTE_SPLINE_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_LAST_MINUTE_SPLINE.value(ownScoreDiff);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {

        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        int timeRemInMatch = simpleGameState.getMatchSecondsRemaining();
        double percGamePlayed = simpleGameState.getPercentageGamePlayed();

        int ownScoreDiffBeforePlay = simpleGameState.getBoundedOwnScoreDiffBeforePlay();
        int ownTimeOutsInGame = simpleGameState.getMatchOwnTimeOuts();
        int ownTimeOutsInQuarter = simpleGameState.getPeriodOwnTimeOuts();
        int oppTimeOutsInQuarter = simpleGameState.getPeriodOppTimeOuts();

        Pair<Integer, Integer> timeSinceLastTimeOuts = simpleGameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        int ownScoreDiffSinceLastTimeOut = simpleGameState.getOwnScoreDiffSinceLastTimeOut();

        boolean oppMissedShotInLastPossession = simpleGameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = simpleGameState.getOppTurnoverInLastPossession();
        boolean oppScoredInLastPossession = simpleGameState.getOppScoredTwoPointsLastPossession() || simpleGameState.getOppScoredThreePointsLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = simpleGameState.getOwnDefensiveFoulReceivedLastPossession();
        boolean firstPlayOfQuarter = simpleGameState.getFirstPlayOfPeriod();
        boolean oppShootingFoulReceivedLastPossession = simpleGameState.getOppShootingFoulReceivedLastPossession();

        return getProbability(ownExpHalfPoints, quarter, startTime, timeRemInMatch, percGamePlayed, ownTimeOutsInGame, ownTimeOutsInQuarter, oppTimeOutsInQuarter, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, ownScoreDiffSinceLastTimeOut, ownScoreDiffBeforePlay, oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredInLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter, oppShootingFoulReceivedLastPossession);
    }

    public static double getProbability(double ownExpHalfPoints, int quarter, int startTime, int timeRemInMatch, double percGamePlayed, int ownTimeOutsInGame, int ownCumTimeOutsInQuarter, int oppCumTimeOutsInQuarter, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int ownScoreDiffSinceLastTimeOut, int ownScoreDiffBeforePlay, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean oppScoredInLastPossession, boolean ownDefensiveFoulReceivedLastPossession, boolean firstPlayOfQuarter, boolean oppShootingFoulReceivedLastPossession) {
        int timeSinceLastTimeOut = FastMath.min(timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut);
        double exp = MathRnD.fastExp(INTERCEPT + //

                (oppMissedShotInLastPossession ? OPP_TEAM_MISSED_SHOT_LAST_POSSESSION : 0d) +//
                (oppTurnoverInLastPossession ? OPP_TEAM_TURNOVER_LAST_POSSESSION : 0d) +//
                (oppScoredInLastPossession ? OPP_TEAM_SCORED_LAST_POSSESSION : 0d) + //
                (oppShootingFoulReceivedLastPossession ? OPP_TEAM_SHOOTING_FOUL_LAST_POSSESSION : 0d) + //
                (ownDefensiveFoulReceivedLastPossession ? OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION : 0d) +//
                (firstPlayOfQuarter ? FIRST_PLAY_QUARTER : 0d) +//
                (ownCumTimeOutsInQuarter + oppCumTimeOutsInQuarter == 0 & startTime <= 420 ? NO_TIME_OUTS_IN_FIRST_FIVE_MINUTES : 0d) +//
                (ownCumTimeOutsInQuarter + oppCumTimeOutsInQuarter == 1 & startTime <= 180 ? ONE_TIME_OUT_IN_FIRST_9_MINUTES : 0d) + //
                (ownCumTimeOutsInQuarter == 3 && quarter <= 3 || ownCumTimeOutsInQuarter == 4 && quarter == 4 ? MAX_TIME_OUTS_IN_QUARTER : 0d) +//

                TIME_SINCE_LAST_OWN_TIME_OUT_SPLINE_ARRAY[timeSinceLastOwnTimeOut] +//
                TIME_SINCE_LAST_OPP_TIME_OUT_SPLINE_ARRAY[timeSinceLastOppTimeOut] +//

                ownExpHalfPoints * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER_MAP[quarter - 1] +//
                (oppScoredInLastPossession ? OPP_TEAM_SCORED_LAST_POSSESSION_INTERACTION_OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_TRUE : OPP_TEAM_SCORED_LAST_POSSESSION_INTERACTION_OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_FALSE) * ownScoreDiffSinceLastTimeOut + //
                (7 - ownTimeOutsInGame) * (1 - percGamePlayed) * TIME_OUT_REMAINING_BY_PERC_GAME +//
                (7 - ownTimeOutsInGame) * TIME_OUT_REMAINING_INTERACTION_QUARTER_MAP[quarter - 1] + //
                (ownCumTimeOutsInQuarter > 0 ? TIME_OUT_IN_QUARTER_GREATER_THAN_ZERO_INTERACTION_QUARTER_MAP[quarter - 1] : 0d) + //
                FastMath.min(ownScoreDiffSinceLastTimeOut, 0) * LOSING_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER_MAP[quarter - 1] +//
                FastMath.max(ownScoreDiffSinceLastTimeOut, 0) * WINNING_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER_MAP[quarter - 1] +//
                FastMath.min(ownScoreDiffBeforePlay, 0) * LOSING_INTERACTION_QUARTER_MAP[quarter - 1] +//
                FastMath.min(ownScoreDiffBeforePlay, -10) * LOSING_BY_MORE_THAN_TEN_INTERACTION_QUARTER_MAP[quarter - 1] +//
                FastMath.min(ownScoreDiffBeforePlay, -20) * LOSING_BY_MORE_THAN_TWENTY_INTERACTION_QUARTER_MAP[quarter - 1] +//
                getStartTimeSpline(quarter)[startTime] +//
                FastMath.max(300 - timeRemInMatch, 0) * OWN_SCORE_DIFF_SPLINE_LAST_FIVE_MINUTES_ARRAY[ownScoreDiffBeforePlay + 50] +//
                FastMath.max(60 - timeRemInMatch, 0) * OWN_SCORE_DIFF_LAST_MINUTE_SPLINE_ARRAY[ownScoreDiffBeforePlay + 50] + //
                FastMath.max(300 - timeRemInMatch, 0) * START_TIME_SPLINE_LAST_FIVE_MINUTES_ARRAY[startTime] +//
                FastMath.max(60, timeSinceLastTimeOut) * ownScoreDiffSinceLastTimeOut * OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_INTERACTION_TIME_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER[quarter - 1]//
        );

        return exp / (1 + exp);
    }

    private static double[] getStartTimeSpline(int quarter) {
        if (quarter == 1) {
            return START_TIME_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return START_TIME_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return START_TIME_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return START_TIME_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }
}






