package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.deffensivefoul;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpDefensiveFoulReceivedModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {1.318088d, 0.02001103d, 0.2455237d, 0.1703263d, 0.139817d, 0.07678141d, -0.09775241d, -0.06184241d, -0.0467583d, -0.007691808d, 0.020303d, -0.02589853d, -0.01736404d, -0.01625427d, -0.01617863d, -0.01423089d, 0.06367467d, 0.06938864d, 0.01174887d, 0.01580758d, -2.138248e-06d, 0.0002163829d, 0.0004432142d, 8.745158e-06d, -0.0002621463d, 0.0003024265d, 0.000310842d, 0.001065136d, -0.2169482d, -0.1253245d, -0.1261371d, -0.04185802d, 0.1103496d, 0.04335495d, 0.05191051d, 0.1343091d, -0.8597644d, -0.0007709105d, -0.3816425d, -0.66924d, 2.106468d, -3.856477d, 4.398429d, -10.19314d, 0.3665681d, 0.03600938d, 0.005164784d, -0.0307933d, -0.01272199d, -0.09119204d, -0.8910867d, -0.2686811d, 0.2743266d, 0.2610272d, 0.004977688d, -0.1243417d, -0.03708654d, 0.1742583d, -0.01591494d, -0.3715483d, -0.03245999d, -0.00832683d, -0.01201402d, -0.01510566d, -0.02889789d, 0.05782794d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double LAST_THIRTY_SECONDS_OF_QUARTER = COEF[COUNTER++];

    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_TIME_OUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double FIRST_PLAY_QUARTER = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_SEVEN_LAST_QUARTER_FALSE = COEF[COUNTER++];
    private static final double OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_SEVEN_LAST_QUARTER_TRUE = COEF[COUNTER++];

    private static final double OWN_SCORE_DIFF_INTERACTION_PERC_GAME_PLAYED = COEF[COUNTER++];
    private static final double OWN_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED = COEF[COUNTER++];
    private static final double[] LESS_THAN_HUNDRED_SECONDS_SINCE_LAST_OWN_TIME_OUT = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LESS_THAN_HUNDRED_SECONDS_SINCE_LAST_OPP_TIME_OUT = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OPP_TEAM_IN_BONUS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_TEAM_IN_BONUS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE = new IntegerBoundedSpline(new double[] {-53, -10, -5, 0, 5, 10, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE = new IntegerBoundedSpline(new double[] {-53, -10, -5, 0, 5, 10, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double LAST_MINUTE_LOSING_BY_MORE_THAN_EIGHT_FALSE = COEF[COUNTER++];
    private static final double LAST_MINUTE_LOSING_BY_MORE_THAN_EIGHT_TRUE = COEF[COUNTER++];

    private static final double LAST_MINUTE_WINNING_OR_TIE = COEF[COUNTER++];
    private static final double LAST_MINUTE_WINNING_BY_MORE_THAN_SEVEN = COEF[COUNTER++];

    private static final double LAST_POSSESSION_WINNING_WITHIN_ONE_AND_FOUR_FALSE = COEF[COUNTER++];
    private static final double LAST_POSSESSION_WINNING_WITHIN_ONE_AND_FOUR_TRUE = COEF[COUNTER++];

    private static final double LAST_TEN_SECONDS_WINNING_WITHIN_ONE_AND_FOUR_FALSE = COEF[COUNTER++];
    private static final double LAST_TEN_SECONDS_WINNING_WITHIN_ONE_AND_FOUR_TRUE = COEF[COUNTER++];

    private static final double LAST_POSSESSION_LOSING_BY_MORE_THAN_FOUR = COEF[COUNTER++];
    private static final double[] OWN_CUM_DEF_FOUL_RECEIVED_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double LAST_POSSESSION_LOSING_BY_THREE = COEF[COUNTER++];

    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP = new double[101];

    static {
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE.value(ownScoreDiff);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {

        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        double percGamePlayed = simpleGameState.getPercentageGamePlayed();

        double timeRemInMatch = simpleGameState.getMatchSecondsRemaining();
        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = simpleGameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = simpleGameState.getBoundedOwnScoreDiffBeforePlay();
        int ownTeamInBonus = simpleGameState.getOwnTeamInBonus();
        int oppTeamInBonus = simpleGameState.getOppTeamInBonus();
        int ownCumThreePointers = simpleGameState.getOwnThreePointers();

        Pair<Integer, Integer> timeSinceLastTimeOuts = simpleGameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        int cumOwnDefensiveFoulReceived = simpleGameState.getPeriodOwnDefensiveFoulsReceived();

        boolean oppMissedShotInLastPossession = simpleGameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = simpleGameState.getOppTurnoverInLastPossession();
        boolean oppScoredOrFreeThrowsInLastPossession = simpleGameState.getOppScoredOrFreeThrowsInLastPossession();
        boolean ownTimeOutCalledLastPossession = simpleGameState.getOwnTimeOutCalledLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = simpleGameState.getOwnDefensiveFoulReceivedLastPossession();
        boolean firstPlayOfQuarter = simpleGameState.getFirstPlayOfPeriod();

        return getProbability(quarter, startTime, timeRemInMatch, percGamePlayed, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, ownCumThreePointers, ownTeamInBonus, oppTeamInBonus, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, cumOwnDefensiveFoulReceived, simpleGameState.getCurrentNBASeasonYear(), oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter);
    }

    public static double getProbability(int quarter, int startTime, double timeRemInMatch, double percGamePlayed, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, int ownCumThreePointers, int ownTeamInBonus, int oppTeamInBonus, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int cumOwnDefensiveFoulReceived, int seasonYear, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean oppScoredOrFreeThrowsInLastPossession, boolean ownTimeOutCalledLastPossession, boolean ownDefensiveFoulReceivedLastPossession, boolean firstPlayOfQuarter) {
        double exp = MathRnD.fastExp(INTERCEPT + FastMath.max(0, 30 - startTime) * LAST_THIRTY_SECONDS_OF_QUARTER +//
                (oppMissedShotInLastPossession ? OPP_TEAM_MISSED_SHOT_LAST_POSSESSION : 0d) +//
                (oppTurnoverInLastPossession ? OPP_TEAM_TURNOVER_LAST_POSSESSION : 0d) + //
                (oppScoredOrFreeThrowsInLastPossession ? OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION : 0d) +//
                (ownTimeOutCalledLastPossession ? OWN_TEAM_TIME_OUT_LAST_POSSESSION : 0d) + //
                (ownDefensiveFoulReceivedLastPossession ? OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION : 0d) + //
                (firstPlayOfQuarter ? FIRST_PLAY_QUARTER : 0d) +//
                ownTeamInBonus * OWN_TEAM_IN_BONUS_INTERACTION_QUARTER[quarter - 1] + //
                oppTeamInBonus * OPP_TEAM_IN_BONUS_INTERACTION_QUARTER[quarter - 1] + //

                SEASON_YEAR_ARRAY[seasonYear - 2015] +//

                ownExpHalfPoints * OWN_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] + //
                FastMath.min(ownExpHalfPoints - oppExpHalfPoints, -7) * (quarter == 4 ? OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_SEVEN_LAST_QUARTER_TRUE : OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_SEVEN_LAST_QUARTER_FALSE) +//
                percGamePlayed * ownScoreDiffBeforePlay * OWN_SCORE_DIFF_INTERACTION_PERC_GAME_PLAYED + //
                ownCumThreePointers * (1 - percGamePlayed) * OWN_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED +//
                FastMath.max(100 - timeSinceLastOwnTimeOut, 0) * LESS_THAN_HUNDRED_SECONDS_SINCE_LAST_OWN_TIME_OUT[quarter - 1] +//
                FastMath.max(100 - timeSinceLastOppTimeOut, 0) * LESS_THAN_HUNDRED_SECONDS_SINCE_LAST_OPP_TIME_OUT[quarter - 1] +//
                (timeRemInMatch > 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP)[ownScoreDiffBeforePlay + 50] +//
                FastMath.max(60 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay < -8 ? LAST_MINUTE_LOSING_BY_MORE_THAN_EIGHT_TRUE : LAST_MINUTE_LOSING_BY_MORE_THAN_EIGHT_FALSE) +//
                FastMath.max(60 - timeRemInMatch, 0) * FastMath.max(ownScoreDiffBeforePlay, 0) * LAST_MINUTE_WINNING_OR_TIE +//
                FastMath.max(60 - timeRemInMatch, 0) * FastMath.log(FastMath.max(ownScoreDiffBeforePlay, 8)) * LAST_MINUTE_WINNING_BY_MORE_THAN_SEVEN +//
                FastMath.max(24 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay >= 1 & ownScoreDiffBeforePlay <= 4 ? LAST_POSSESSION_WINNING_WITHIN_ONE_AND_FOUR_TRUE : LAST_POSSESSION_WINNING_WITHIN_ONE_AND_FOUR_FALSE) +//
                FastMath.max(10 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay >= 1 & ownScoreDiffBeforePlay <= 4 ? LAST_TEN_SECONDS_WINNING_WITHIN_ONE_AND_FOUR_TRUE : LAST_TEN_SECONDS_WINNING_WITHIN_ONE_AND_FOUR_FALSE) +//
                FastMath.max(24 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay < -4 ? LAST_POSSESSION_LOSING_BY_MORE_THAN_FOUR : 0d) +//
                FastMath.min(cumOwnDefensiveFoulReceived, 4) * OWN_CUM_DEF_FOUL_RECEIVED_INTERACTION_QUARTER[quarter - 1] + //

                FastMath.max(24 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay == -3 ? LAST_POSSESSION_LOSING_BY_THREE : 0d)//

        ); //

        return exp / (1 + exp);
    }

}
