package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.threepoints;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.FreeThrowPBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.FreeThrowSimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;

public class NBApbpAdditionalFTAfterThreePointerModel implements FreeThrowPBPProbabilityModel<NbaPBPGameState> {

    @Override
    public double getProbability(FreeThrowSimplePBPGameState simpleGameState) {
        int period = simpleGameState.getModelPeriod();

        return getProbability(period);
    }

    public static double getProbability(int period) {
        double halfFactor;
        if (period == 1) {
            halfFactor = 0;
        } else if (period == 2) {
            halfFactor = 0.269839d;
        } else if (period == 3) {
            halfFactor = -0.0153299d;
        } else {
            halfFactor = 0.396272;
        }
        double exp =  MathRnD.fastExp(-4.71918d + halfFactor);

        return exp / (1 + exp);
    }
}
