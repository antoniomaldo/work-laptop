package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.threepoints;

import org.apache.commons.math3.util.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.PossessionOutcomeModelUtils;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpThreePointsScoredModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {-1.522585d, 0.05187684d, -0.05981204d, 0.4270876d, 0.2863255d, 0.5268815d, 0.4952872d, 0.586231d, 0.4471077d, -4.644527d, -4.04012d, -0.06636612d, -1.663594d, 0.5280376d, 0.1821762d, 0.04591828d, 0.1114169d, 0.2034756d, 0.1886894d, 0.2720143d, 0.01138061d, 0.02123883d, 0.02054699d, 0.0237503d, 0.001657191d, 0.0006114556d, 0.0004866927d, 0.0001593998d, 5.84232e-06d, 1.184667e-06d, 3.382463e-06d, 7.859247e-07d, 0.01138936d, 0.007022363d, 0.005055005d, 0.007389889d, -0.1533354d, -0.1648946d, 0.2574159d, -0.3388905d, -3.490052d, -0.2751218d, 1.520797d, -3.170438d, 13.15833d, -0.8951802d, -0.03877013d, -0.2887776d, -0.1042507d, -0.540885d, -0.5896857d, 0.9091352d, -0.7511481d, 1.761817d, 0.4227387d, -0.3256914d, -0.01363089d, -0.1739055d, 0.2403115d, 0.3340316d, -1.245555d, 1.069485d, -2.391734d, 0.08904705d, 0.03719885d, 0.02082619d, 0.01136448d, 0.0787759d, 0.04827299d, 0.03461851d, 0.02513783d, 0.02730001d, 0.0168536d, 0.01237275d, 0.01063933};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_TEAM_IN_BONUS = COEF[COUNTER++];
    private static final double OWN_TEAM_IN_BONUS = COEF[COUNTER++];

    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_TIME_OUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double FIRST_PLAY_QUARTER = COEF[COUNTER++];

    private static final double WINNING_BETWEEN_FOUR_AND_NINE_LAST_POSSESSION = COEF[COUNTER++];
    private static final double WINNING_BY_LESS_THAN_FOUR_LAST_POSSESSION = COEF[COUNTER++];
    private static final double LOSING_BY_THREE_LAST_POSSESSION = COEF[COUNTER++];
    private static final double LOSING_BY_THREE_LAST_TEN_SECONDS = COEF[COUNTER++];
    private static final double LOSING_BY_MORE_THAN_THREE_LAST_POSSESSION = COEF[COUNTER++];
    private static final double WINNING_BY_TWENTY_FIRST_ELEVEN_MINUTES_LAST_QUARTER = COEF[COUNTER++];

    private static final double LAST_TEN_SECONDS_OF_GAME = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    //    private static final double[] OWN_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OPP_CUM_TIME_OUTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_FOUR_MINUTES_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 20, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final double[] OWN_CUM_DEF_FOUL_RECEIVED_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_CUM_SHOT_MISSED_INTERACTION_PERC_GAME_PLAYED = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE_MAP = new double[101];

    static {
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE.value(ownScoreDiff);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {

        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        double percGamePlayed = simpleGameState.getPercentageGamePlayed();
        int timeRemInMatch = simpleGameState.getMatchSecondsRemaining();

        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = simpleGameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = simpleGameState.getBoundedOwnScoreDiffBeforePlay();
        int ownThreePointers = simpleGameState.getOwnThreePointers();
        int oppTimeOutsInQuarter = simpleGameState.getPeriodOppTimeOuts();
        int oppTeamInBonus = simpleGameState.getOppTeamInBonus();
        int ownTeamInBonus = simpleGameState.getOwnTeamInBonus();

        int ownScoreDiffSinceLastTimeOut = simpleGameState.getOwnScoreDiffSinceLastTimeOut();
        int ownCumShotMissed = simpleGameState.getOwnCumShotMissed();

        int cumOwnDefensiveFoulReceived = simpleGameState.getPeriodOwnDefensiveFoulsReceived();

        boolean oppMissedShotInLastPossession = simpleGameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = simpleGameState.getOppTurnoverInLastPossession();
        boolean oppScoredOrFreeThrowsInLastPossession = simpleGameState.getOppScoredOrFreeThrowsInLastPossession();
        boolean ownTimeOutCalledLastPossession = simpleGameState.getOwnTimeOutCalledLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = simpleGameState.getOwnDefensiveFoulReceivedLastPossession();
        boolean firstPlayOfQuarter = simpleGameState.getFirstPlayOfPeriod();

        return getProbability(quarter, startTime, percGamePlayed, timeRemInMatch, ownExpHalfPoints, oppExpHalfPoints, oppTeamInBonus, ownTeamInBonus, ownScoreDiffBeforePlay, ownScoreDiffSinceLastTimeOut, ownThreePointers, oppTimeOutsInQuarter, cumOwnDefensiveFoulReceived, simpleGameState.getCurrentNBASeasonYear(), oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter, ownCumShotMissed);
    }

    public static double getProbability(int quarter, double startTime, double percGamePlayed, double timeRemInMatch, double ownExpHalfPoints, double oppExpHalfPoints, int oppTeamInBonus, int ownTeamInBonus, int ownScoreDiffBeforePlay, int ownScoreDiffSinceLastTimeOut, int ownCumThreePointers, int oppTimeOutsInQuarter, int cumOwnDefensiveFoulReceived, int seasonYear, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean oppScoredOrFreeThrowsInLastPossession, boolean ownTimeOutCalledLastPossession, boolean ownDefensiveFoulReceivedLastPossession, boolean firstPlayOfQuarter, int ownCumShotMissed) {

        double exp = MathRnD.fastExp(INTERCEPT + //
                oppTeamInBonus * OPP_TEAM_IN_BONUS + //
                ownTeamInBonus * OWN_TEAM_IN_BONUS + //
                (oppMissedShotInLastPossession ? OPP_TEAM_MISSED_SHOT_LAST_POSSESSION : 0d) + //
                (oppTurnoverInLastPossession ? OPP_TEAM_TURNOVER_LAST_POSSESSION : 0d) + //
                (oppScoredOrFreeThrowsInLastPossession ? OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION : 0d) +//
                (ownTimeOutCalledLastPossession ? OWN_TEAM_TIME_OUT_LAST_POSSESSION : 0d) +//
                (ownDefensiveFoulReceivedLastPossession ? OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION : 0d) +//
                (firstPlayOfQuarter ? FIRST_PLAY_QUARTER : 0d) +//
                (timeRemInMatch < 25 & ownScoreDiffBeforePlay > 3 & ownScoreDiffBeforePlay < 10 ? WINNING_BETWEEN_FOUR_AND_NINE_LAST_POSSESSION : 0d) +//
                (timeRemInMatch < 25 & ownScoreDiffBeforePlay > 0 & ownScoreDiffBeforePlay < 4 ? WINNING_BY_LESS_THAN_FOUR_LAST_POSSESSION : 0d) +//
                (timeRemInMatch < 25 & ownScoreDiffBeforePlay == -3 ? LOSING_BY_THREE_LAST_POSSESSION : 0d) +//
                (timeRemInMatch < 10 & ownScoreDiffBeforePlay == -3 ? LOSING_BY_THREE_LAST_TEN_SECONDS : 0d) +//
                (timeRemInMatch < 25 & ownScoreDiffBeforePlay < -3 ? LOSING_BY_MORE_THAN_THREE_LAST_POSSESSION : 0d) +//
                (timeRemInMatch > 60 & quarter == 4 & ownScoreDiffBeforePlay > 20 ? WINNING_BY_TWENTY_FIRST_ELEVEN_MINUTES_LAST_QUARTER : 0d) +//
                FastMath.max(10 - timeRemInMatch, 0) * LAST_TEN_SECONDS_OF_GAME +//

                SEASON_YEAR_ARRAY[seasonYear - 2015] +//

                //                ownExpHalfPoints * OWN_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] +//
                oppTimeOutsInQuarter * OPP_CUM_TIME_OUTS_INTERACTION_QUARTER[quarter - 1] + //
                startTime * START_TIME_INTERACTION_QUARTER[quarter - 1] + //
                PossessionOutcomeModelUtils.square(FastMath.max(startTime - 480, 0)) * FIRST_FOUR_MINUTES_INTERACTION_QUARTER[quarter - 1] +//
                ownScoreDiffSinceLastTimeOut * OWN_SCORE_DIFF_SINCE_LAST_TIME_OUT_INTERACTION_QUARTER[quarter - 1] + //
                (timeRemInMatch > 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP)[ownScoreDiffBeforePlay + 50] +//
                (timeRemInMatch > 180 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE_MAP[ownScoreDiffBeforePlay + 50] : 0d) + //
                FastMath.min(cumOwnDefensiveFoulReceived, 4) * OWN_CUM_DEF_FOUL_RECEIVED_INTERACTION_QUARTER[quarter - 1] + //
                percGamePlayed * FastMath.min(15, FastMath.max(4.5, ownCumThreePointers / FastMath.max(0.001, percGamePlayed))) * OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED[quarter - 1] +//
                percGamePlayed * FastMath.min(37, FastMath.max(27, ownCumShotMissed / FastMath.max(0.001, percGamePlayed))) * OWN_CUM_SHOT_MISSED_INTERACTION_PERC_GAME_PLAYED[quarter - 1]

        );//

        return exp / (1 + exp);
    }
}
