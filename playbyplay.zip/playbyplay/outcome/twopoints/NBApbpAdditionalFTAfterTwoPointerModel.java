package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.twopoints;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.FreeThrowPBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.FreeThrowSimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;

public class NBApbpAdditionalFTAfterTwoPointerModel implements FreeThrowPBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {-3.3829d, -0.4957965d, 0.02032496d, 0.01939898d, 0.01200727d, 0.00618669d, -0.001077709d, -0.0002660205d, -0.0004595569d, -0.0001396613d, -0.01486222d, -0.006242127d, -0.008080208d, -0.01253856d, -0.02811899d, -0.1063714d, -0.01322633d, -0.03379054d, -0.09025077d, -0.01298372d, -0.05927537d, -0.0594734d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double LOSING_IN_THE_LAST_POSSESSION = COEF[COUNTER++];

    private static final double OWN_EXP_HALF_POINTS_SECOND_HALF = COEF[COUNTER++];
    private static final double OWN_EXP_HALF_POINTS_FIRST_HALF = COEF[COUNTER++];
    private static final double OWN_EXP_HALF_POINTS_DIFF_SECOND_HALF = COEF[COUNTER++];
    private static final double OWN_EXP_HALF_POINTS_DIFF_FIRST_HALF = COEF[COUNTER++];

    private static final double[] START_TIME_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_SCORE_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OPP_TIME_OUTS_IN_QUARTER_GREATER_THAN_TEN_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_TIME_OUTS_IN_QUARTER_GREATER_THAN_TEN_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    @Override
    public double getProbability(FreeThrowSimplePBPGameState simpleGameState) {

        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        int timeRemInMatch = simpleGameState.getMatchSecondsRemaining();

        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = simpleGameState.getOppExpHalfPoints();
        int ownTimeOutsInQuarter = simpleGameState.getPeriodOwnTimeOuts();
        int oppTimeOutsInQuarter = simpleGameState.getPeriodOppTimeOuts();
        int ownScoreDiffBeforePlay = simpleGameState.getOwnScoreDiffBeforePlay();

        return getProbability(quarter, startTime, timeRemInMatch, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, ownTimeOutsInQuarter, oppTimeOutsInQuarter);
    }

    public static double getProbability(int quarter, int startTime, int timeRemInMatch, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, int ownCumTimeOutsInQuarter, int oppCumTimeOutsInQuarter) {
        double exp = MathRnD.fastExp(INTERCEPT +//
                ownExpHalfPoints * (quarter < 3 ? OWN_EXP_HALF_POINTS_FIRST_HALF : OWN_EXP_HALF_POINTS_SECOND_HALF) + //
                (ownExpHalfPoints - oppExpHalfPoints) * (quarter < 3 ? OWN_EXP_HALF_POINTS_DIFF_FIRST_HALF : OWN_EXP_HALF_POINTS_DIFF_SECOND_HALF) +//
                (timeRemInMatch < 24 & ownScoreDiffBeforePlay < 0 ? LOSING_IN_THE_LAST_POSSESSION : 0d) +//
                startTime * START_TIME_INTERACTION_QUARTER[quarter - 1] + //
                ownScoreDiffBeforePlay * OWN_SCORE_DIFF_INTERACTION_QUARTER[quarter - 1] + //
                (ownCumTimeOutsInQuarter > 0 ? 1d : 0d) * OWN_TIME_OUTS_IN_QUARTER_GREATER_THAN_TEN_INTERACTION_QUARTER[quarter - 1] + //
                (oppCumTimeOutsInQuarter > 0 ? 1d : 0d) * OPP_TIME_OUTS_IN_QUARTER_GREATER_THAN_TEN_INTERACTION_QUARTER[quarter - 1]);

        return exp / (1 + exp);
    }
}
