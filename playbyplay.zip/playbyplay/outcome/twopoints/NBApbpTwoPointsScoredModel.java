package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.twopoints;

import net.jafama.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpTwoPointsScoredModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {1.103227d, -0.03570233d, 0.0410044d, -0.01811972d, 0.1990087d, 0.4158994d, 0.2615024d, 0.2044984d, 0.3351032d, 0.2895257d, -2.20927d, -2.531032d, -0.3673287d, -0.7386442d, -0.5396736d, -0.5410574d, -1.720285d, -6.865996d, 0.3062166d, -0.01390843d, -0.04349103d, -0.09812164d, -0.1321166d, -0.02248439d, -0.07418145d, 0.03802487d, 0.02721136d, 0.02540611d, 0.03063762d, 0.003517979d, 0.002331209d, 0.04171662d, 0.02193359d, -0.001168449d, -0.03200755d, 0.0002197227d, 0.0008573231d, -2.310091d, -0.10628d, -1.393957d, -0.8882982d, -2.407284d, 0.5595835d, -2.614824d, 1.737683d, -1.238795d, -0.7539609d, -1.317764d, -0.8169642d, -1.249264d, -0.600094d, -0.3132114d, -0.4549507d, 0.7511396d, -0.2646362d, 0.2409909d, -0.238322d, 0.183419d, -0.3835991d, 0.05574269d, 0.2906517d, -6.200236e-07d, 0.00168087d, 0.01832511d, 0.02567913d, 0.08692601d, -0.0678195d, -0.0372737d, -0.066386d, -0.07362077d, -0.05716517d, -0.06689748d, 0.1186505d, 0.1250834d, 0.001271528d, 0.01028057d, 0.01367753d, 0.02906671d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OWN_TEAM_IN_BONUS = COEF[COUNTER++];
    private static final double OPP_TEAM_IN_BONUS = COEF[COUNTER++];

    private static final double LAST_MINUTE_OF_QUARTER = COEF[COUNTER++];
    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_TIME_OUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double FIRST_PLAY_QUARTER = COEF[COUNTER++];

    private static final double LAST_POSSESSION_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_THREE = COEF[COUNTER++];
    private static final double LAST_POSSESSION_WINNING_BY_LESS_THAN_FOUR = COEF[COUNTER++];

    private static final double LAST_NINETY_SECONDS_WINNING_BY_LESS_THAN_FIFTEEN_AND_MORE_THAN_SIX = COEF[COUNTER++];

    private static final double LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_SIX = COEF[COUNTER++];
    private static final double LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_SEVEN_AND_MORE_THAN_THREE = COEF[COUNTER++];

    private static final double LOSING_BY_THREE_LAST_TWENTY_FOUR_SECONDS = COEF[COUNTER++];
    private static final double LOSING_BY_THREE_LAST_TEN_SECONDS = COEF[COUNTER++];
    private static final double LOSING_BY_THREE_LAST_FIVE_SECONDS = COEF[COUNTER++];

    private static final double LOSING_BY_ONE_LAST_TWENTY_FOUR_SECONDS = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] OWN_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] OWN_EXP_HALF_POINTS_LESS_THAN_FORTY_FOUR_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_MINUS_FOUR_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_MINUS_SIX_FIVE_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double MORE_THAN_TWELVE_THREE_POINTERS_THIRD_QUARTER_FALSE = COEF[COUNTER++];
    private static final double MORE_THAN_TWELVE_THREE_POINTERS_THIRD_QUARTER_TRUE = COEF[COUNTER++];

    private static final double[] CUM_DEF_FOULS_RECEIVED_INTERACTION_QUARTER = {

            COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double TIME_SINCE_LAST_TIME_OUT_INTERACTION_TIME_OUTS_IN_QUARTER_FALSE = COEF[COUNTER++];
    private static final double TIME_SINCE_LAST_TIME_OUT_INTERACTION_TIME_OUTS_IN_QUARTER_TRUE = COEF[COUNTER++];

    private static final double[] START_TIME_INTERACTION_QUARTER = {

            COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double LAST_FOUR_HUNDRED_SECONDS_FIRST_QUARTER_FALSE = COEF[COUNTER++];
    private static final double LAST_FOUR_HUNDRED_SECONDS_FIRST_QUARTER_TRUE = COEF[COUNTER++];

    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 56}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double OWN_SCORE_DIFF_SQUARED_LAST_QUARTER = COEF[COUNTER++];

    // private static final double[] LOSING_BY_MORE_THAN_THEN_INTERACTION_HALF = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_CUM_TWO_POINTERS_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_CUM_THREE_POINTERS_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_CUM_THREE_POINTERS_MORE_THAN_ELEVEN_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_CUM_SHOT_MISSED_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

//    private static final double[] OWN_EXP_HALF_POINTS_DIFF_LAST_TWO_YEARS_FALSE = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
//    private static final double[] OWN_EXP_HALF_POINTS_DIFF_LAST_TWO_YEARS_TRUE = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
//
//    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER_LAST_YEARS_FALSE = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
//    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER_LAST_YEARS_TRUE = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP = new double[101];
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE_MAP = new double[101];

    static {
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE.value(ownScoreDiff);
            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE_MAP[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE.value(ownScoreDiff);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {

        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        double percGamePlayed = simpleGameState.getPercentageGamePlayed();
        int timeRemInMatch = simpleGameState.getMatchSecondsRemaining();

        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = simpleGameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = simpleGameState.getBoundedOwnScoreDiffBeforePlay();
        int ownTimeOutsInQuarter = simpleGameState.getPeriodOwnTimeOuts();
        int ownTwoPointers = simpleGameState.getOwnTwoPointers();
        int ownThreePointers = simpleGameState.getOwnThreePointers();
        int ownShotsMissed = simpleGameState.getOwnCumShotMissed();
        int ownTeamInBonus = simpleGameState.getOwnTeamInBonus();
        int oppTeamInBonus = simpleGameState.getOppTeamInBonus();

        Pair<Integer, Integer> timeSinceLastTimeOuts = simpleGameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();
        int timeSinceLastTimeOut = FastMath.min(timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut);

        boolean oppMissedShotInLastPossession = simpleGameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = simpleGameState.getOppTurnoverInLastPossession();
        boolean oppScoredOrFreeThrowsInLastPossession = simpleGameState.getOppScoredOrFreeThrowsInLastPossession();
        boolean ownTimeOutCalledLastPossession = simpleGameState.getOwnTimeOutCalledLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = simpleGameState.getOwnDefensiveFoulReceivedLastPossession();
        boolean firstPlayOfQuarter = simpleGameState.getFirstPlayOfPeriod();

        int cumOwnDefensiveFoulReceived = simpleGameState.getPeriodOwnDefensiveFoulsReceived();

        return getProbability(quarter, startTime, percGamePlayed, timeRemInMatch, ownExpHalfPoints, oppExpHalfPoints, ownTimeOutsInQuarter, cumOwnDefensiveFoulReceived, ownTeamInBonus, oppTeamInBonus, timeSinceLastTimeOut, ownScoreDiffBeforePlay, ownTwoPointers, ownShotsMissed, ownThreePointers, simpleGameState.getCurrentNBASeasonYear(), oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter);
    }

    public static double getProbability(int quarter, int startTime, double percGamePlayed, int timeRemInMatch, double ownExpHalfPoints, double oppExpHalfPoints, int ownCumTimeOutsInQuarter, int cumOwnDefensiveFoulReceived, int ownTeamInBonus, int oppTeamInBonus, double timeSinceLastTimeOut, int ownScoreDiffBeforePlay, int ownCumTwoPointers, int ownCumShotsMissed, int ownCumThreePointers, int seasonYear, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean oppScoredOrFreeThrowsInLastPossession, boolean ownTimeOutCalledLastPossession, boolean ownDefensiveFoulReceivedLastPossession, boolean firstPlayOfQuarter) {
        final double ownExpHalfPointsDiff = ownExpHalfPoints - oppExpHalfPoints;

        double exp = MathRnD.fastExp(INTERCEPT + //
                ownTeamInBonus * OWN_TEAM_IN_BONUS + //
                oppTeamInBonus * OPP_TEAM_IN_BONUS + //
                FastMath.max(0, 24 - startTime) * LAST_MINUTE_OF_QUARTER + //
                (oppMissedShotInLastPossession ? OPP_TEAM_MISSED_SHOT_LAST_POSSESSION : 0d) + //
                (oppTurnoverInLastPossession ? OPP_TEAM_TURNOVER_LAST_POSSESSION : 0d) + //
                (oppScoredOrFreeThrowsInLastPossession ? OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION : 0d) + //
                (ownTimeOutCalledLastPossession ? OWN_TEAM_TIME_OUT_LAST_POSSESSION : 0d) + //
                (ownDefensiveFoulReceivedLastPossession ? OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION : 0d) + //
                (firstPlayOfQuarter ? FIRST_PLAY_QUARTER : 0d) + //
                (timeRemInMatch < 25 && ownScoreDiffBeforePlay > 3 && ownScoreDiffBeforePlay < 10 ? LAST_POSSESSION_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_THREE : 0d) +//
                (timeRemInMatch < 25 && ownScoreDiffBeforePlay > 0 && ownScoreDiffBeforePlay < 4 ? LAST_POSSESSION_WINNING_BY_LESS_THAN_FOUR : 0d) +//
                (timeRemInMatch < 90 && timeRemInMatch > 60 && ownScoreDiffBeforePlay > 6 && ownScoreDiffBeforePlay < 14 ? LAST_NINETY_SECONDS_WINNING_BY_LESS_THAN_FIFTEEN_AND_MORE_THAN_SIX : 0d) +//
                (timeRemInMatch < 60 && timeRemInMatch > 25 && ownScoreDiffBeforePlay > 6 && ownScoreDiffBeforePlay < 10 ? LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_SIX : 0d) +//
                (timeRemInMatch < 60 && timeRemInMatch > 25 && ownScoreDiffBeforePlay > 3 && ownScoreDiffBeforePlay < 7 ? LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_SEVEN_AND_MORE_THAN_THREE : 0d) +//

                (ownScoreDiffBeforePlay == -3 && timeRemInMatch < 24 ? LOSING_BY_THREE_LAST_TWENTY_FOUR_SECONDS : 0) +//
                (ownScoreDiffBeforePlay == -3 && timeRemInMatch < 10 ? LOSING_BY_THREE_LAST_TEN_SECONDS : 0) +//
                (ownScoreDiffBeforePlay == -3 && timeRemInMatch < 5 ? LOSING_BY_THREE_LAST_FIVE_SECONDS : 0) +//
                (ownScoreDiffBeforePlay == -1 && timeRemInMatch < 24 ? LOSING_BY_ONE_LAST_TWENTY_FOUR_SECONDS : 0) +//

                SEASON_YEAR_ARRAY[seasonYear - 2015] +//
                //                ownExpHalfPoints * OWN_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] + //
                //                FastMath.min(45.5, ownExpHalfPoints) * OWN_EXP_HALF_POINTS_LESS_THAN_FORTY_FOUR_INTERACTION_QUARTER[quarter - 1] +//
                FastMath.max(ownCumThreePointers, 12) * (quarter != 3 ? MORE_THAN_TWELVE_THREE_POINTERS_THIRD_QUARTER_FALSE : MORE_THAN_TWELVE_THREE_POINTERS_THIRD_QUARTER_TRUE) + //
                //                (ownExpHalfPointsDiff < -4 ? OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_MINUS_FOUR_INTERACTION_QUARTER[quarter - 1] : 0d) + //
                //                (ownExpHalfPointsDiff < -6.5 ? OWN_EXP_HALF_POINTS_DIFF_LESS_THAN_MINUS_SIX_FIVE_INTERACTION_QUARTER[quarter - 1] : 0d) + //

                FastMath.min(cumOwnDefensiveFoulReceived, 4) * CUM_DEF_FOULS_RECEIVED_INTERACTION_QUARTER[quarter - 1] + //
                FastMath.max(0, 48 - timeSinceLastTimeOut) * (ownCumTimeOutsInQuarter > 1 ? TIME_SINCE_LAST_TIME_OUT_INTERACTION_TIME_OUTS_IN_QUARTER_TRUE : TIME_SINCE_LAST_TIME_OUT_INTERACTION_TIME_OUTS_IN_QUARTER_FALSE) + //

                FastMath.sqrt(startTime) * START_TIME_INTERACTION_QUARTER[quarter - 1] + //
                FastMath.max(0, 400 - startTime) * (quarter == 1 ? LAST_FOUR_HUNDRED_SECONDS_FIRST_QUARTER_TRUE : LAST_FOUR_HUNDRED_SECONDS_FIRST_QUARTER_FALSE) + //
                (timeRemInMatch > 60 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_MINUTE_MAP : OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_LAST_MINUTE_MAP)[ownScoreDiffBeforePlay + 50] +//
                (timeRemInMatch > 180 ? OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_WO_LAST_THREE_MINUTE_MAP[ownScoreDiffBeforePlay + 50] : 0) +//

                FastMath.min(timeRemInMatch, 720) * FastMath.pow(ownScoreDiffBeforePlay, 2) * OWN_SCORE_DIFF_SQUARED_LAST_QUARTER +//

                //                FastMath.min(ownScoreDiffBeforePlay, -10) * LOSING_BY_MORE_THAN_THEN_INTERACTION_HALF[quarter - 1] +//

                ownCumTwoPointers * (1 - percGamePlayed) * OWN_CUM_TWO_POINTERS_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED[quarter - 1] +//
                ownCumThreePointers * (1 - percGamePlayed) * OWN_CUM_THREE_POINTERS_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED[quarter - 1] +//

                FastMath.max(11, ownCumThreePointers) * (1 - percGamePlayed) * OWN_CUM_THREE_POINTERS_MORE_THAN_ELEVEN_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED[quarter - 1] + //
                ownCumShotsMissed * (1 - percGamePlayed) * OWN_CUM_SHOT_MISSED_INTERACTION_QUARTER_INTERACTION_PERC_GAME_PLAYED[quarter - 1] //
//                (seasonYear >= 2018 ? OWN_EXP_HALF_POINTS_INTERACTION_QUARTER_LAST_YEARS_TRUE : OWN_EXP_HALF_POINTS_INTERACTION_QUARTER_LAST_YEARS_FALSE)[quarter - 1] * ownExpHalfPoints + //
//
//                (ownExpHalfPoints - oppExpHalfPoints) * (seasonYear >= 2018 ? OWN_EXP_HALF_POINTS_DIFF_LAST_TWO_YEARS_TRUE : OWN_EXP_HALF_POINTS_DIFF_LAST_TWO_YEARS_FALSE)[quarter - 1]   //

        );//

        return exp / (1 + exp);
    }

}
