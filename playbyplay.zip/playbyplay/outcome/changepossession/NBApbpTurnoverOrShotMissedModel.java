package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.changepossession;

import org.apache.commons.math3.util.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

/**
 * Binomial model with outcomes being either turnover or shot missed,
 * it needs to be called in case of a positive response from  NBApbpChangeOfPossessionModel
 */
public class NBApbpTurnoverOrShotMissedModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {-0.1681502d, 0.04510585d, 0.1021831d, -0.04261854d, 0.2771242d, -0.007489445d, 0.001749927d, -0.05046856d, -0.01259991d, 0.005483591d, 0.002426005d, 0.005201191d, -0.004323469d, 0.0004057061d, -0.003066027d, -0.007511008d, -0.004766027d, -0.001065815d, -0.0006509234d, -0.0009385155d, -0.0001959611d, -8.588883e-05d, -1.214823e-05d, 6.591667e-05d, 0.0001384627d, 0.006852198d, -0.003922175d, 0.04581709d, 0.05132611d, 0.04469352d, -0.04503249d, -0.5412631d, -0.337954d, -0.4269388d, -0.4294221d, -0.4062913d, -0.2720095d, -0.3478973d, -0.9928901d, -1.532354d, -0.0169377d, -0.7348358d, -0.6725892d, 0.8487714d, 0.04915185d, -0.3231161d, 1.104328d, 0.5861517d, 0.06766747d, -0.1103351d, 1.073978d, 2.779307d, 0.8980748d, 1.970447d, 23.56807d};
    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LAST_TEN_SECONDS_LEFT = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] HALF_POINTS_DIFF_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_TWO_MINUTES_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] START_TIME_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double OWN_SCORE_DIFF_INTERACTION_PERC_GAME_PLAYED = COEF[COUNTER++];
    private static final double OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED = COEF[COUNTER++];
    private static final double[] LAST_TWENTY_FOUR_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline LAST_MINUTE_SPLINE_FALSE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});
    private static final IntegerSpline LAST_MINUTE_SPLINE_TRUE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final IntegerSpline LAST_POSSESSION_SPLINE_TRUE = new IntegerBoundedSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double[] LAST_MINUTE_SPLINE_FALSE_ARRAY = new double[101];
    private static final double[] LAST_MINUTE_SPLINE_TRUE_ARRAY = new double[101];
    private static final double[] LAST_POSSESSION_SPLINE_TRUE_ARRAY = new double[101];

    static {
        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
            LAST_MINUTE_SPLINE_FALSE_ARRAY[ownScoreDiff + 50] = LAST_MINUTE_SPLINE_FALSE.value(ownScoreDiff);
            LAST_MINUTE_SPLINE_TRUE_ARRAY[ownScoreDiff + 50] = LAST_MINUTE_SPLINE_TRUE.value(ownScoreDiff);
            LAST_POSSESSION_SPLINE_TRUE_ARRAY[ownScoreDiff + 50] = LAST_POSSESSION_SPLINE_TRUE.value(ownScoreDiff);
        }
    }

    @Override
    public double getProbability(ISimplePBPGameState gameState) {

        int quarter = gameState.getModelPeriod();
        int startTime = gameState.getPeriodSecondsRemaining();
        double percGamePlayed = gameState.getPercentageGamePlayed();
        int timeRemInMatch = gameState.getMatchSecondsRemaining();

        double ownExpHalfPoints = gameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = gameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = gameState.getBoundedOwnScoreDiffBeforePlay();
        int ownThreePointers = gameState.getOwnThreePointers();

        boolean oppMissedShotInLastPossession = gameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = gameState.getOppTurnoverInLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = gameState.getOwnDefensiveFoulReceivedLastPossession();

        return getProbability(quarter, startTime, percGamePlayed, timeRemInMatch, ownExpHalfPoints, oppExpHalfPoints, ownScoreDiffBeforePlay, ownThreePointers, gameState.getCurrentNBASeasonYear(), oppMissedShotInLastPossession, oppTurnoverInLastPossession, ownDefensiveFoulReceivedLastPossession);
    }

    public static double getProbability(int quarter, double startTime, double percGamePlayed, double timeRemInMatch, double ownExpHalfPoints, double oppExpHalfPoints, int ownScoreDiffBeforePlay, int ownCumThreePointers, int seasonYear, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean ownDefensiveFoulReceivedLastPossession) {

        double exp = MathRnD.fastExp(INTERCEPT + //
                (oppMissedShotInLastPossession ? OPP_TEAM_MISSED_SHOT_LAST_POSSESSION : 0d) +//
                (oppTurnoverInLastPossession ? OPP_TEAM_TURNOVER_LAST_POSSESSION : 0d) +//
                (ownDefensiveFoulReceivedLastPossession ? OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION : 0d) +//
                FastMath.max(10 - timeRemInMatch, 0) * LAST_TEN_SECONDS_LEFT +//
                SEASON_YEAR_ARRAY[seasonYear - 2015] +//
                ownExpHalfPoints * OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[quarter - 1] + //
                (ownExpHalfPoints - oppExpHalfPoints) * HALF_POINTS_DIFF_INTERACTION_QUARTER[quarter - 1] +//
                FastMath.max(600, startTime) * FIRST_TWO_MINUTES_INTERACTION_QUARTER[quarter - 1] +//
                startTime * START_TIME_INTERACTION_QUARTER[quarter - 1] +//
                ownScoreDiffBeforePlay * percGamePlayed * OWN_SCORE_DIFF_INTERACTION_PERC_GAME_PLAYED +//
                ownCumThreePointers * percGamePlayed * OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_PLAYED +//
                FastMath.max(0, 24 - startTime) * LAST_TWENTY_FOUR_SECONDS_INTERACTION_QUARTER[quarter - 1] +//
                (timeRemInMatch < 60 ? LAST_MINUTE_SPLINE_TRUE_ARRAY : LAST_MINUTE_SPLINE_FALSE_ARRAY)[ownScoreDiffBeforePlay + 50] +//
                (timeRemInMatch < 24 ? LAST_POSSESSION_SPLINE_TRUE_ARRAY[ownScoreDiffBeforePlay + 50] : 0d)//
        );
        return exp / (1 + exp);
    }

}
