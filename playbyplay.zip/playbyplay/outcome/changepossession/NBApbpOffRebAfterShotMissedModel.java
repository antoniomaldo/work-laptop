package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.changepossession;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;

public class NBApbpOffRebAfterShotMissedModel implements PBPProbabilityModel<NbaPBPGameState> {

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {
        return 0;
    }
}
