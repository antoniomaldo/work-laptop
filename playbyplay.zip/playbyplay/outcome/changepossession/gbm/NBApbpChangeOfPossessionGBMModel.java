package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.changepossession.gbm;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.gmbpredictions.NBAGBMPrediction;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpChangeOfPossessionGBMModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final NBAGBMPrediction GBM_PREDICTIONS = NBAGBMPrediction.forChangeOfPossession();

    private static final double[] COEF = {1.16593d, -0.04802538d, -0.2072058d, 0.06140826d, 0.115677d, 0.1241215d, -0.02081738d, 0.109154d, -0.02595545d, 0.02236045d, 0.02579645d, 0.03518654d, 0.0540481d, 0.06759693d, 0.08352632d, -0.01924383d, -0.01985203d, -0.02053274d, -0.02118278d, 0.001765772d, -0.02583259d, 0.01301354d, -0.0174233d, -0.03593031d, -0.0932178d, -0.05152663d, 0.008688584d, -0.03680146d, -0.04320241d, -0.07954061d, -0.06142355d, -0.05887201d, -0.1316557d, -0.03261488d, 0.1361209d, -0.05107548d, -0.2700245d, 0.04724248d, -0.3401391d, -0.1708759d, -0.1089489d, -0.1044084d, -0.08916976d, -0.1126324d, -0.1222191d, -0.1862d, -0.1313891d, -0.247967d, -0.1641845d, -0.08211856d, -0.09564069d, -0.1224601d, -0.1712268d, -0.255157d, -0.1986476d, -0.3236935d, -0.2606069d, -0.0822825d, -0.1733883d, 0.01396772d, 0.01027489d, 0.009213662d, 0.003312027d};
    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_TIME_OUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double FIRST_PLAY_QUARTER = COEF[COUNTER++];

    private static final double MORE_THAN_FIFTEEN_THREE_POINTERS_FOURTH_QUARTER = COEF[COUNTER++];

    private static final double OWN_TEAM_IN_BONUS = COEF[COUNTER++];
    private static final double OPP_TEAM_IN_BONUS = COEF[COUNTER++];

    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_AND_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);

            TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
        }

    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {

        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        double percGamePlayed = simpleGameState.getPercentageGamePlayed();
        int timeRemInMatch = simpleGameState.getMatchSecondsRemaining();

        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = simpleGameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = simpleGameState.getBoundedOwnScoreDiffBeforePlay();
        int ownCumTwoPointers = simpleGameState.getOwnTwoPointers();
        int ownTeamInBonus = simpleGameState.getOwnTeamInBonus();
        int oppTeamInBonus = simpleGameState.getOppTeamInBonus();

        Pair<Integer, Integer> timeSinceLastTimeOuts = simpleGameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppMissedShotInLastPossession = simpleGameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = simpleGameState.getOppTurnoverInLastPossession();
        boolean oppScoredOrFreeThrowsInLastPossession = simpleGameState.getOppScoredOrFreeThrowsInLastPossession();
        boolean ownTimeOutCalledLastPossession = simpleGameState.getOwnTimeOutCalledLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = simpleGameState.getOwnDefensiveFoulReceivedLastPossession();
        boolean firstPlayOfQuarter = simpleGameState.getFirstPlayOfPeriod();

        int ownCumShotMissed = simpleGameState.getOwnCumShotMissed();
        int ownCumThreePointers = simpleGameState.getOwnThreePointers();

        double gbmPrediction = GBM_PREDICTIONS.getPrediction(timeRemInMatch, ownScoreDiffBeforePlay);

        return getProbability(gbmPrediction, quarter, percGamePlayed, ownTeamInBonus, oppTeamInBonus, ownExpHalfPoints, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, ownCumThreePointers, simpleGameState.getCurrentNBASeasonYear(), oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter);
    }

    public static double getProbability(double predictionsGBM, int quarter, double percGamePlayed, int ownTeamInBonus, int oppTeamInBonus, double ownExpHalfPoints, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int ownCumThreePointers, int seasonYear, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean oppScoredOrFreeThrowsInLastPossession, boolean ownTimeOutCalledLastPossession, boolean ownDefensiveFoulReceivedLastPossession, boolean firstPlayOfQuarter) {

        final int qtrIndex = quarter - 1;
        double exp = MathRnD.fastExp(INTERCEPT +//
                FastMath.log(predictionsGBM / (1 - predictionsGBM)) + //

                getPreviousPossessionCoefficient(oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter) +//
                (quarter == 4 && ownCumThreePointers > 15 ? MORE_THAN_FIFTEEN_THREE_POINTERS_FOURTH_QUARTER : 0) +//

                ownTeamInBonus * OWN_TEAM_IN_BONUS +//
                oppTeamInBonus * OPP_TEAM_IN_BONUS +//

                SEASON_YEAR_ARRAY[seasonYear - 2014] +//

                OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[qtrIndex] * ownExpHalfPoints + //
                getTimeSinceLastOwnTimeOutSpline(quarter)[timeSinceLastOwnTimeOut] + //
                getTimeSinceLastOppTimeOutSpline(quarter)[timeSinceLastOppTimeOut] + //

                percGamePlayed * FastMath.min(15, FastMath.max(4.5, ownCumThreePointers / FastMath.max(0.001, percGamePlayed))) * OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_AND_QUARTER[qtrIndex] //
        );

        return exp / (1 + exp);
    }

    private static double getPreviousPossessionCoefficient(boolean oppMissedShot, boolean oppTurnover, boolean oppScored, boolean ownTimeOut, boolean ownDefFoulRec, boolean firstPlay) {
        if (oppMissedShot) {
            return OPP_TEAM_MISSED_SHOT_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TEAM_TURNOVER_LAST_POSSESSION;
        } else if (oppScored) {
            return OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TEAM_TIME_OUT_LAST_POSSESSION;
        } else if (ownDefFoulRec) {
            return OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION;
        } else if (firstPlay) {
            return FIRST_PLAY_QUARTER;
        } else {
            return 0d;
        }
    }

    private static double[] getTimeSinceLastOwnTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOppTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }
}
