package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.changepossession;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.ISimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpChangeOfPossessionModel implements PBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = {0.7088532d, -0.04709884d, -0.2052169d, 0.06003176d, 0.1040339d, 0.11205d, -0.01474359d, 0.07910535d, -0.01352051d, 0.04086314d, -2.123073d, -2.217202d, -0.9372739d, -1.040743d, 0.214186d, 0.238205d, 0.01306674d, 0.03350792d, 0.01657971d, 0.03780355d, -0.01096733d, -0.01184013d, -0.0133003d, -0.01421636d, 0.007857645d, 0.007441977d, 0.005083942d, 0.005609078d, 0.2296008d, -0.02744168d, -0.04451311d, 0.09773841d, 0.001008902d, -0.02921764d, 0.03266241d, 0.004572617d, -0.06754842d, -0.06427278d, -0.05850696d, -0.02866113d, -0.1419857d, -0.07002663d, -0.07462442d, -0.01225686d, -0.0970896d, -0.09114469d, -0.04403805d, 0.04248602d, -0.03590931d, -0.1418622d, 0.10912d, 0.05805145d, -0.1083566d, -0.100364d, -0.1438847d, -0.1130871d, -0.1445074d, -0.1172564d, -0.1561248d, -0.1062099d, -0.2165882d, -0.1632554d, -0.1381361d, -0.1234621d, -0.1529578d, -0.1329139d, -0.1517524d, -0.11478d, -0.2135663d, -0.1374782d, -0.08790044d, -0.085784d, -0.01783874d, -0.01139839d, -0.01393737d, 0.0159676d, 0.004432036d, -0.00115854d, -0.04142327d, -0.0001087138d, -0.0006524153d, -0.009129573d, 0.0004473751d, 0.004615414d, 7.213329e-05d, 0.01152822d, 0.003246913d, 0.003514404d, 0.001978133d, -0.01913906d, -0.01177856d, -0.006297753d, -0.003944222d, -0.01171823d, -0.012976d, -0.02017661d, -0.01570582d, -0.01373007d, -0.01128851d, -0.01944629d, -0.01259707d, -0.01264331d, -0.008962786d, -0.01768161d, -0.01383516d, -0.0156865d, -0.0153359d, -0.01724018d, -0.0143249d, -0.01351995d, -0.01249094d, -0.01842176d, -0.01019697d};
    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double OPP_TEAM_MISSED_SHOT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_TURNOVER_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_TIME_OUT_LAST_POSSESSION = COEF[COUNTER++];
    private static final double OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION = COEF[COUNTER++];
    private static final double FIRST_PLAY_QUARTER = COEF[COUNTER++];

    private static final double MORE_THAN_FIFTEEN_THREE_POINTERS_FOURTH_QUARTER = COEF[COUNTER++];

    private static final double OWN_TEAM_IN_BONUS = COEF[COUNTER++];
    private static final double OPP_TEAM_IN_BONUS = COEF[COUNTER++];

    private static final double LAST_POSSESSION_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_THREE = COEF[COUNTER++];
    private static final double LAST_POSSESSION_WINNING_BY_LESS_THAN_FOUR = COEF[COUNTER++];

    private static final double LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_SIX = COEF[COUNTER++];
    private static final double LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_SEVEN_AND_MORE_THAN_THREE = COEF[COUNTER++];

    private static final double LOSING_BY_MORE_THAN_FOUR_AND_LESS_THAN_TEN_LAST_POSSESSION = COEF[COUNTER++];

    private static final double LESS_THAN_THREE_SECONDS = COEF[COUNTER++];
    private static final double[] SEASON_YEAR_ARRAY = {0, COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_HALF_POINTS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] WINNING_BY_MORE_THAN_TWENTY_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OWN_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[0]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[1]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[2]});
    private static final IntegerSpline TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER = new IntegerBoundedSpline(new double[] {0, 100, 300, 720}, new double[] {FIRST_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], SECOND_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], THIRD_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FOURTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3], FIFTH_COEF_TIME_SINCE_OPP_TIMEOUT_SPLINE_BY_QUARTER[3]});

    private static final double[] LAST_TWENTY_FOUR_SECONDS_INTERACTION_QUARTER = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double LAST_MINUTE_LOSING_BY_THREE_FALSE = COEF[COUNTER++];
    private static final double LAST_MINUTE_LOSING_BY_THREE_TRUE = COEF[COUNTER++];

    private static final double LAST_POSSESSION_LOSING_BY_THREE_FALSE = COEF[COUNTER++];
    private static final double LAST_POSSESSION_LOSING_BY_THREE_TRUE = 0d;

    private static final double LAST_FIVE_MINUTES_LOSING_BY_TWO_FALSE = COEF[COUNTER++];
    private static final double LAST_FIVE_MINUTES_LOSING_BY_TWO_TRUE = COEF[COUNTER++];

    private static final double[] OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_AND_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_SHOT_MISSED_INTERACTION_PERC_GAME_AND_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_CUM_TWO_POINTERS_INTERACTION_PERC_GAME_AND_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] FIRST_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] SECOND_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] THIRD_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] FOURTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] FIFTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] SIXTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] SEVENTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    //    private static final double[] EIGHTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    //    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_QUARTER = new IntegerSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {FIRST_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], SECOND_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], THIRD_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], FOURTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], FIFTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], SIXTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], SEVENTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0], EIGHTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[0]});
    //    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_SECOND_QUARTER = new IntegerSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {FIRST_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], SECOND_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], THIRD_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], FOURTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], FIFTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], SIXTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], SEVENTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1], EIGHTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[1]});
    //    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_THIRD_QUARTER = new IntegerSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {FIRST_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], SECOND_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], THIRD_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], FOURTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], FIFTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], SIXTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], SEVENTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2], EIGHTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[2]});
    //    private static final IntegerSpline OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FOURTH_QUARTER = new IntegerSpline(new double[] {-58, -10, -5, 0, 5, 10, 58}, new double[] {FIRST_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], SECOND_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], THIRD_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], FOURTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], FIFTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], SIXTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], SEVENTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3], EIGHTH_COEF_OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_BY_QUARTER[3]});

    private static final double[] OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_15 = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_16 = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_17 = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_18 = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_19 = new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY = new double[721];
    private static final double[] TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY = new double[721];

    //    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_QUARTER_ARRAY = new double[101];
    //    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_SECOND_QUARTER_ARRAY = new double[101];
    //    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_THIRD_QUARTER_ARRAY = new double[101];
    //    private static final double[] OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FOURTH_QUARTER_ARRAY = new double[101];

    static {
        for (int time = 0; time <= 720; time++) {
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);

            TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER.value(time);
            TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY[time] = TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER.value(time);
        }

        //        for (int ownScoreDiff = -50; ownScoreDiff <= 50; ownScoreDiff++) {
        //            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_QUARTER_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_QUARTER.value(ownScoreDiff);
        //            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_SECOND_QUARTER_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_SECOND_QUARTER.value(ownScoreDiff);
        //            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_THIRD_QUARTER_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_THIRD_QUARTER.value(ownScoreDiff);
        //            OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FOURTH_QUARTER_ARRAY[ownScoreDiff + 50] = OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FOURTH_QUARTER.value(ownScoreDiff);
        //        }
    }

    @Override
    public double getProbability(ISimplePBPGameState simpleGameState) {

        int quarter = simpleGameState.getModelPeriod();
        int startTime = simpleGameState.getPeriodSecondsRemaining();
        double percGamePlayed = simpleGameState.getPercentageGamePlayed();
        double timeRemInMatch = simpleGameState.getMatchSecondsRemaining();

        double ownExpHalfPoints = simpleGameState.getOwnExpHalfPoints();
        double oppExpHalfPoints = simpleGameState.getOppExpHalfPoints();
        int ownScoreDiffBeforePlay = simpleGameState.getBoundedOwnScoreDiffBeforePlay();
        int ownCumTwoPointers = simpleGameState.getOwnTwoPointers();
        int ownTeamInBonus = simpleGameState.getOwnTeamInBonus();
        int oppTeamInBonus = simpleGameState.getOppTeamInBonus();

        Pair<Integer, Integer> timeSinceLastTimeOuts = simpleGameState.getTimeSinceLastTimeOuts();
        int timeSinceLastOwnTimeOut = timeSinceLastTimeOuts.getFirst();
        int timeSinceLastOppTimeOut = timeSinceLastTimeOuts.getSecond();

        boolean oppMissedShotInLastPossession = simpleGameState.getOppMissedShotInLastPossession();
        boolean oppTurnoverInLastPossession = simpleGameState.getOppTurnoverInLastPossession();
        boolean oppScoredOrFreeThrowsInLastPossession = simpleGameState.getOppScoredOrFreeThrowsInLastPossession();
        boolean ownTimeOutCalledLastPossession = simpleGameState.getOwnTimeOutCalledLastPossession();
        boolean ownDefensiveFoulReceivedLastPossession = simpleGameState.getOwnDefensiveFoulReceivedLastPossession();
        boolean firstPlayOfQuarter = simpleGameState.getFirstPlayOfPeriod();

        int ownCumShotMissed = simpleGameState.getOwnCumShotMissed();
        int ownCumThreePointers = simpleGameState.getOwnThreePointers();

        return getProbability(quarter, startTime, timeRemInMatch, percGamePlayed, ownTeamInBonus, oppTeamInBonus, ownExpHalfPoints, oppExpHalfPoints, timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut, ownScoreDiffBeforePlay, ownCumTwoPointers, ownCumShotMissed, ownCumThreePointers, simpleGameState.getCurrentNBASeasonYear(), oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter);
    }

    public static double getProbability(int quarter, double startTime, double timeRemInMatch, double percGamePlayed, int ownTeamInBonus, int oppTeamInBonus, double ownExpHalfPoints, double oppExpHalfPoints, int timeSinceLastOwnTimeOut, int timeSinceLastOppTimeOut, int ownScoreDiffBeforePlay, int ownCumTwoPointers, int ownCumShotMissed, int ownCumThreePointers, int seasonYear, boolean oppMissedShotInLastPossession, boolean oppTurnoverInLastPossession, boolean oppScoredOrFreeThrowsInLastPossession, boolean ownTimeOutCalledLastPossession, boolean ownDefensiveFoulReceivedLastPossession, boolean firstPlayOfQuarter) {

        final int qtrIndex = quarter - 1;
        double exp = MathRnD.fastExp(INTERCEPT +//

                (quarter == 4 && ownCumThreePointers > 15 ? MORE_THAN_FIFTEEN_THREE_POINTERS_FOURTH_QUARTER : 0) +//

                ownTeamInBonus * OWN_TEAM_IN_BONUS +//
                oppTeamInBonus * OPP_TEAM_IN_BONUS +//
                getPreviousPossessionCoefficient(oppMissedShotInLastPossession, oppTurnoverInLastPossession, oppScoredOrFreeThrowsInLastPossession, ownTimeOutCalledLastPossession, ownDefensiveFoulReceivedLastPossession, firstPlayOfQuarter) +//

                (timeRemInMatch < 25 && ownScoreDiffBeforePlay > 3 && ownScoreDiffBeforePlay < 10 ? LAST_POSSESSION_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_THREE : 0d) +//
                (timeRemInMatch < 25 && ownScoreDiffBeforePlay > 0 && ownScoreDiffBeforePlay < 4 ? LAST_POSSESSION_WINNING_BY_LESS_THAN_FOUR : 0d) +//
                (timeRemInMatch < 60 && timeRemInMatch > 25 && ownScoreDiffBeforePlay > 6 && ownScoreDiffBeforePlay < 10 ? LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_TEN_AND_MORE_THAN_SIX : 0d) +//
                (timeRemInMatch < 60 && timeRemInMatch > 25 && ownScoreDiffBeforePlay > 3 && ownScoreDiffBeforePlay < 7 ? LAST_MIN_NO_LAST_POSS_WINNING_BY_LESS_THAN_SEVEN_AND_MORE_THAN_THREE : 0d) +//
                (timeRemInMatch < 24 && ownScoreDiffBeforePlay > -10 & ownScoreDiffBeforePlay < -3 ? LOSING_BY_MORE_THAN_FOUR_AND_LESS_THAN_TEN_LAST_POSSESSION : 0d) +//
                FastMath.max(3 - timeRemInMatch, 0) * LESS_THAN_THREE_SECONDS +//
                SEASON_YEAR_ARRAY[seasonYear - 2015] +//
                OWN_EXP_HALF_POINTS_INTERACTION_QUARTER[qtrIndex] * ownExpHalfPoints + //
                ownScoreDiffBeforePlay * OWN_SCORE_DIFF_BEFORE_PLAY_INTERACTION_QUARTER[qtrIndex] + //
                getTimeSinceLastOwnTimeOutSpline(quarter)[timeSinceLastOwnTimeOut] + //
                getTimeSinceLastOppTimeOutSpline(quarter)[timeSinceLastOppTimeOut] + //

                FastMath.max(0, 24 - startTime) * LAST_TWENTY_FOUR_SECONDS_INTERACTION_QUARTER[qtrIndex] + //
                (ownScoreDiffBeforePlay > 20 ? WINNING_BY_MORE_THAN_TWENTY_INTERACTION_QUARTER[qtrIndex] : 0d) +//

                FastMath.max(60 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay == -3 ? LAST_MINUTE_LOSING_BY_THREE_TRUE : LAST_MINUTE_LOSING_BY_THREE_FALSE) +//
                FastMath.max(24 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay == -3 ? LAST_POSSESSION_LOSING_BY_THREE_TRUE : LAST_POSSESSION_LOSING_BY_THREE_FALSE) +//
                FastMath.max(300 - timeRemInMatch, 0) * (ownScoreDiffBeforePlay == -2 ? LAST_FIVE_MINUTES_LOSING_BY_TWO_TRUE : LAST_FIVE_MINUTES_LOSING_BY_TWO_FALSE) +//

                percGamePlayed * FastMath.min(15, FastMath.max(4.5, ownCumThreePointers / FastMath.max(0.001, percGamePlayed))) * OWN_CUM_THREE_POINTERS_INTERACTION_PERC_GAME_AND_QUARTER[qtrIndex] +//
                percGamePlayed * FastMath.min(37, FastMath.max(27, ownCumShotMissed / FastMath.max(0.001, percGamePlayed))) * OWN_SHOT_MISSED_INTERACTION_PERC_GAME_AND_QUARTER[qtrIndex] +//
                percGamePlayed * FastMath.min(37, FastMath.max(27, ownCumTwoPointers / FastMath.max(0.001, percGamePlayed))) * OWN_CUM_TWO_POINTERS_INTERACTION_PERC_GAME_AND_QUARTER[qtrIndex] +//
                //                getOwnScoreDiffBeforePlaySpline(quarter)[ownScoreDiffBeforePlay + 50] * (ownExpHalfPoints - oppExpHalfPoints) +
                (ownExpHalfPoints - oppExpHalfPoints) * getArrayForSeason(seasonYear)[qtrIndex]

        );

        return exp / (1 + exp);
    }

    private static double getPreviousPossessionCoefficient(boolean oppMissedShot, boolean oppTurnover, boolean oppScored, boolean ownTimeOut, boolean ownDefFoulRec, boolean firstPlay) {
        if (oppMissedShot) {
            return OPP_TEAM_MISSED_SHOT_LAST_POSSESSION;
        } else if (oppTurnover) {
            return OPP_TEAM_TURNOVER_LAST_POSSESSION;
        } else if (oppScored) {
            return OPP_TEAM_SCORED_OR_THROW_FREE_THROWS_LAST_POSSESSION;
        } else if (ownTimeOut) {
            return OWN_TEAM_TIME_OUT_LAST_POSSESSION;
        } else if (ownDefFoulRec) {
            return OWN_TEAM_RECEIVED_DEFENSIVE_FOUL_LAST_POSSESSION;
        } else if (firstPlay) {
            return FIRST_PLAY_QUARTER;
        } else {
            return 0d;
        }
    }

    private static double[] getTimeSinceLastOwnTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OWN_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    private static double[] getTimeSinceLastOppTimeOutSpline(int quarter) {
        if (quarter == 1) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FIRST_QUARTER_ARRAY;
        } else if (quarter == 2) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_SECOND_QUARTER_ARRAY;
        } else if (quarter == 3) {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_THIRD_QUARTER_ARRAY;
        } else {
            return TIME_SINCE_OPP_TIMEOUT_SPLINE_FOURTH_QUARTER_ARRAY;
        }
    }

    //    private static double[] getOwnScoreDiffBeforePlaySpline(double quarter) {
    //        if (quarter == 1) {
    //            return OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FIRST_QUARTER_ARRAY;
    //        } else if (quarter == 2) {
    //            return OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_SECOND_QUARTER_ARRAY;
    //        } else if (quarter == 3) {
    //            return OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_THIRD_QUARTER_ARRAY;
    //        } else {
    //            return OWN_SCORE_DIFF_BEFORE_PLAY_SPLINE_FOURTH_QUARTER_ARRAY;
    //        }
    //    }

    private static double[] getArrayForSeason(int seasonYear) {
        if (seasonYear == 2015) {
            return OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_15;
        } else if (seasonYear == 2016) {
            return OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_16;
        } else if (seasonYear == 2017) {
            return OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_17;
        } else if (seasonYear == 2018) {
            return OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_18;
        } else if (seasonYear == 2019) {
            return OWN_EXP_DIFF_INTERACTION_HALF_PER_SEASON_19;
        } else {
            throw new IllegalArgumentException("Illegal season year passed");
        }

    }
}
