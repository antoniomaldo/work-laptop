package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome;

import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Pair;

import com.williamhill.rnd.basketball.domain.model.common.FortyEightMinuteMatchTimeConstants;
import com.williamhill.rnd.basketball.domain.model.common.FortyMinuteMatchTimeConstants;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.BasketballPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimulationGameTime;

public class PossessionOutcomeModelUtils {

    public static <G extends BasketballPBPGameState> Pair<Integer, Integer> getTimeSinceLastTimeOutsForNBA(G gameState, SimulationGameTime lastOwnTimeOutGameTime, SimulationGameTime lastOppTimeOutGameTime) {

        int timeSinceLastOwnTimeOut = getTimeSinceLastTimeOut(gameState, lastOwnTimeOutGameTime,FortyEightMinuteMatchTimeConstants.LENGTH_OF_OVERTIME_IN_SECONDS, FortyEightMinuteMatchTimeConstants.LENGTH_OF_PERIOD_IN_SECS);
        int timeSinceLastOppTimeOut = getTimeSinceLastTimeOut(gameState, lastOppTimeOutGameTime,FortyEightMinuteMatchTimeConstants.LENGTH_OF_OVERTIME_IN_SECONDS, FortyEightMinuteMatchTimeConstants.LENGTH_OF_PERIOD_IN_SECS);

        return new Pair<>(timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut);
    }

    public static <G extends BasketballPBPGameState> Pair<Integer, Integer> getTimeSinceLastTimeOutsForWNBA(G gameState, SimulationGameTime lastOwnTimeOutGameTime, SimulationGameTime lastOppTimeOutGameTime) {

        int timeSinceLastOwnTimeOut = getTimeSinceLastTimeOut(gameState, lastOwnTimeOutGameTime, FortyMinuteMatchTimeConstants.LENGTH_OF_OVERTIME_IN_SECONDS, FortyMinuteMatchTimeConstants.TEN_MINUTES_IN_SECS);
        int timeSinceLastOppTimeOut = getTimeSinceLastTimeOut(gameState, lastOppTimeOutGameTime, FortyMinuteMatchTimeConstants.LENGTH_OF_OVERTIME_IN_SECONDS, FortyMinuteMatchTimeConstants.TEN_MINUTES_IN_SECS);

        return new Pair<>(timeSinceLastOwnTimeOut, timeSinceLastOppTimeOut);
    }

    private static <G extends BasketballPBPGameState> int getTimeSinceLastTimeOut(G gameState, SimulationGameTime lastOwnTimeOut, int lengthOfOvertimeInSeconds, int lengthOfPeriodInSecs) {
        if (lastOwnTimeOut.getPeriod() != gameState.getPeriod()) {
            if (gameState.getPeriod() == 5) {
                return lengthOfOvertimeInSeconds - gameState.getSecondsRemainingInPeriod();
            } else {
                return lengthOfPeriodInSecs - gameState.getSecondsRemainingInPeriod();
            }
        } else {
            return FastMath.max(0, lastOwnTimeOut.getGameSeconds() - gameState.getSecondsRemainingInPeriod());
        }
    }

    public static double roundExpHalfPoints(double expHalfPoints) {
        return Math.round(4 * expHalfPoints) / 4d;
    }

    public static double square(double number) {
        return number * number;
    }
}
