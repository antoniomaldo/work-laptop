package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.freethrowsuccess;

import org.apache.commons.math3.util.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.FreeThrowPBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.FreeThrowSimplePBPGameState;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;

public class NBApbpFreeThrowSuccessModel implements FreeThrowPBPProbabilityModel<NbaPBPGameState> {

    private static final double[] COEF = new double[] {1.233993d,-0.708335d,-0.0007591749d,-0.005649988d};

    private static int COUNTER = 0;

    private static final double INTERCEPT = COEF[COUNTER++];
    private static final double LESS_THAN_FIVE_SECONDS_LOSING_BY_TWO_THREE_OR_FOUR = COEF[COUNTER++];

    private static final double ABS_OWN_SCORE_DIFF_BEFORE_FT_IN_FOURTH_QUARTER_FALSE = COEF[COUNTER++];
    private static final double ABS_OWN_SCORE_DIFF_BEFORE_FT_IN_FOURTH_QUARTER_TRUE = COEF[COUNTER++];

    @Override
    public double getProbability(FreeThrowSimplePBPGameState simpleGameState) {
        int quarter = simpleGameState.getModelPeriod();
        int timeRemInSecs = simpleGameState.getMatchSecondsRemaining();
        int ownScoreDiffBeforePlay = simpleGameState.getOwnScoreDiffBeforePlay();

        return getProbability(quarter, timeRemInSecs, ownScoreDiffBeforePlay);
    }

    public static double getProbability(int quarter, int timeRemInSecs, int ownScoreDiffBeforePlay) {

        double exp = FastMath.exp(INTERCEPT + //
                (timeRemInSecs < 5 & (ownScoreDiffBeforePlay == -4 || ownScoreDiffBeforePlay == -3 || ownScoreDiffBeforePlay == -2) ? LESS_THAN_FIVE_SECONDS_LOSING_BY_TWO_THREE_OR_FOUR : 0d) +//
                FastMath.abs(ownScoreDiffBeforePlay) * (quarter == 4 ? ABS_OWN_SCORE_DIFF_BEFORE_FT_IN_FOURTH_QUARTER_TRUE : ABS_OWN_SCORE_DIFF_BEFORE_FT_IN_FOURTH_QUARTER_FALSE) //
        );

        return exp / (1 + exp);
    }
}
