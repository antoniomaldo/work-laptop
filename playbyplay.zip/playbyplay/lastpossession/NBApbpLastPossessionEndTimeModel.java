package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.lastpossession;

import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator.NbaPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPLastPossessionModel;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NBApbpLastPossessionEndTimeModel implements PBPLastPossessionModel<NbaPBPGameState> {

    private static final NBApbpLastPossessionEndTimeFirstThreeQuartersModel<NbaPBPGameState> GLM_MODEL = new NBApbpLastPossessionEndTimeFirstThreeQuartersModel<>();
    private static final NBApbpLastPossessionFourthQuarterGLM<NbaPBPGameState> GLM_MODEL_LAST_QUARTER = new NBApbpLastPossessionFourthQuarterGLM<>();

    @Override
    public boolean isSuccess(NbaPBPGameState gameState, Team team, PossessionOutcome possessionOutcome) {
        if (gameState.getSecondsRemainingInPeriod() > 60) {
            return false;
        } else if (gameState.getPeriod() < 4) {
            return GLM_MODEL.isSuccess(gameState, possessionOutcome);
        } else {
            return GLM_MODEL_LAST_QUARTER.isSuccess(gameState, team, possessionOutcome);
        }
    }
}
