package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.lastpossession;

import org.apache.commons.math3.util.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.BasketballPBPGameState;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.distribution.Rdists;
import com.williamhill.trading.framework.math.common.splines.IntegerBoundedSpline;
import com.williamhill.trading.framework.math.common.splines.IntegerSpline;

public class NBApbpLastPossessionFourthQuarterGLM<T extends BasketballPBPGameState<?>> {

    private static final double[] COEF = {-46.74661d, -0.5700332d, -0.2236378d, 0.6929003d, 10.82567d, 28.22982d, 5.44118d, 0.6633586d, 1.367004d, -0.328493d, 0.7890127d, -0.1845819d, 1.009003d, 0.7552234d, 3.083709d, 2.630976d, 0.7309858d, 0.6187532d, 0.01108436d, -0.06516058d, -0.09944877d, 0.1665413d, 0.1446255d, 0.314518d, 0.3505919d, -0.592869d, -0.8059864d, 1.363649d, 0.7141595d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double MORE_THAN_TWENTY_FOUR_SECONDS = COEF[COUNTER++];

    private static final IntegerSpline END_TIME_SPLINE = new IntegerBoundedSpline(new double[] {0, 3, 10, 60}, new double[] {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]});

    private static final double POSSESSION_OUTCOME_SHOOTING_FOUL_RECEIVED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_SHOT_MISSED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TECH_FOUL_CONCEDED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_THREE_POINTS_SCORED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TIME_OUT = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TURNOVER = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TWO_POINTS_SCORED = COEF[COUNTER++];

    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_LESS_THAN_THREE = COEF[COUNTER++];
    private static final double MORE_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_LESS_THAN_THREE = COEF[COUNTER++];

    private static final double LESS_THAN_THIRTY_FOUR_SECONDS_LOSING_BETWEEN_ONE_AND_FOUR_FALSE = COEF[COUNTER++];
    private static final double LESS_THAN_THIRTY_FOUR_SECONDS_LOSING_BETWEEN_ONE_AND_FOUR_TRUE = COEF[COUNTER++];

    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_WINNING_BY_LESS_THAN_TEN = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_MORE_THAN_TEN = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_TIED_GAME = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_ONE = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_TWO = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_THREE = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_FOUR = COEF[COUNTER++];

    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_MORE_THAN_FOUR_AND_LESS_THAN_ELEVEN_FALSE = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_MORE_THAN_FOUR_AND_LESS_THAN_ELEVEN_TRUE = COEF[COUNTER++];

    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_WINNING_BY_MORE_THAN_TEN_FALSE = COEF[COUNTER++];
    private static final double LESS_THAN_TWENTY_FOUR_SECONDS_WINNING_BY_MORE_THAN_TEN_TRUE = COEF[COUNTER++];

    private static final double[] END_TIME_SPLINE_ARRAY = new double[61];

    static {
        for (int time = 0; time <= 60; time++) {
            END_TIME_SPLINE_ARRAY[time] = END_TIME_SPLINE.value(time);
        }
    }

    public boolean isSuccess(T gameState, Team team, PossessionOutcome possessionOutcome) {
        return Rdists.uniform() < getProbability(gameState, team, possessionOutcome);
    }

    public double getProbability(T gameState, Team team, PossessionOutcome possessionOutcome) {

        int endTime = gameState.getSecondsRemainingInPeriod();
        boolean threePointsScored = false;
        boolean twoPointsScored = false;
        boolean turnover = false;
        boolean shootingFoulReceived = false;
        boolean timeOut = false;
        boolean shotMissed = false;
        boolean techFoul = false;

        if (possessionOutcome == PossessionOutcome.THREE_POINTS_SCORED) {
            threePointsScored = true;
        } else if (possessionOutcome == PossessionOutcome.TWO_POINTS_SCORED) {
            twoPointsScored = true;
        } else if (possessionOutcome == PossessionOutcome.TURNOVER) {
            turnover = true;
        } else if (possessionOutcome == PossessionOutcome.SHOOTING_FOUL_RECEIVED) {
            shootingFoulReceived = true;
        } else if (possessionOutcome == PossessionOutcome.TIME_OUT) {
            timeOut = true;
        } else if (possessionOutcome == PossessionOutcome.SHOT_MISSED) {
            shotMissed = true;
        }

        int homeSup = gameState.getMatchHomeScore() - gameState.getMatchAwayScore();
        int ownScoreDiff = team == Team.HOME ? homeSup : -1 * homeSup;

        return getProbability(endTime, ownScoreDiff, shotMissed, techFoul, threePointsScored, twoPointsScored, turnover, shootingFoulReceived, timeOut);
    }

    public static double getProbability(int endTime, int ownScoreDiff, boolean shotMissed, boolean techFoul, boolean threePointsScored, boolean twoPointsScored, boolean turnover, boolean shootingFoulReceived, boolean timeOut) {
        double v = END_TIME_SPLINE_ARRAY[endTime];
        double x = INTERCEPT + //
                (endTime > 24 ? MORE_THAN_TWENTY_FOUR_SECONDS : 0d) +//
                v + //
                getPossessionCoef(shotMissed, techFoul, threePointsScored, twoPointsScored, turnover, shootingFoulReceived, timeOut) +//
                (ownScoreDiff > -3 && ownScoreDiff <= 0 ? endTime > 24 ? MORE_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_LESS_THAN_THREE : LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_LESS_THAN_THREE : 0d) +//
                FastMath.max(60 - endTime, 26) * (ownScoreDiff == -1 || ownScoreDiff == -2 || ownScoreDiff == -3 || ownScoreDiff == -4 ? LESS_THAN_THIRTY_FOUR_SECONDS_LOSING_BETWEEN_ONE_AND_FOUR_TRUE : LESS_THAN_THIRTY_FOUR_SECONDS_LOSING_BETWEEN_ONE_AND_FOUR_FALSE) +//
                FastMath.max(24 - endTime, 0) * FastMath.min(FastMath.max(ownScoreDiff, 0), 10) * LESS_THAN_TWENTY_FOUR_SECONDS_WINNING_BY_LESS_THAN_TEN +//
                FastMath.max(24 - endTime, 0) * (ownScoreDiff < -10 ? LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_MORE_THAN_TEN : 0d) +//
                FastMath.max(24 - endTime, 0) * getOwnScoreDiffFactor(ownScoreDiff) +//
                (endTime < 24 ? LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_MORE_THAN_FOUR_AND_LESS_THAN_ELEVEN_TRUE : LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_MORE_THAN_FOUR_AND_LESS_THAN_ELEVEN_FALSE) * FastMath.max(FastMath.min(ownScoreDiff, -4), -11) +//
                (ownScoreDiff > 10 ? endTime < 24 ? LESS_THAN_TWENTY_FOUR_SECONDS_WINNING_BY_MORE_THAN_TEN_TRUE : LESS_THAN_TWENTY_FOUR_SECONDS_WINNING_BY_MORE_THAN_TEN_FALSE : 0d);
        double exp = MathRnD.fastExp(x);

        return exp / (1 + exp);
    }

    private static double getOwnScoreDiffFactor(int ownScoreDiff) {
        if (ownScoreDiff == 0) {
            return LESS_THAN_TWENTY_FOUR_SECONDS_TIED_GAME;
        } else if (ownScoreDiff == -1) {
            return LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_ONE;
        } else if (ownScoreDiff == -2) {
            return LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_TWO;
        } else if (ownScoreDiff == -3) {
            return LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_THREE;
        } else if (ownScoreDiff == -4) {
            return LESS_THAN_TWENTY_FOUR_SECONDS_LOSING_BY_FOUR;
        } else {
            return 0;
        }
    }

    private static double getPossessionCoef(boolean shotMissed, boolean techFoul, boolean threePointsScored, boolean twoPointsScored, boolean turnover, boolean shootingFoulReceived, boolean timeOut) {
        if (threePointsScored) {
            return POSSESSION_OUTCOME_THREE_POINTS_SCORED;
        } else if (twoPointsScored) {
            return POSSESSION_OUTCOME_TWO_POINTS_SCORED;
        } else if (turnover) {
            return POSSESSION_OUTCOME_TURNOVER;
        } else if (shootingFoulReceived) {
            return POSSESSION_OUTCOME_SHOOTING_FOUL_RECEIVED;
        } else if (timeOut) {
            return POSSESSION_OUTCOME_TIME_OUT;
        } else if (shotMissed) {
            return POSSESSION_OUTCOME_SHOT_MISSED;
        } else if (techFoul) {
            return POSSESSION_OUTCOME_TECH_FOUL_CONCEDED;
        } else {
            return 0;
        }
    }
}
