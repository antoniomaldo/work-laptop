package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.lastpossession;

import net.jafama.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PossessionOutcome;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.BasketballPBPGameState;
import com.williamhill.trading.framework.math.common.MathRnD;
import com.williamhill.trading.framework.math.common.distribution.Rdists;

public class NBApbpLastPossessionEndTimeFirstThreeQuartersModel<T extends BasketballPBPGameState<?>> {

    private static final double[] COEF = {-6.866124d, 0.332422d, 0.6437884d, 0.006967837d, 0.7300226d, -0.5119872d, -0.1572546d, 0.5115112d, -0.4078453d, -0.4166654d, -0.4113535d, 0.3441216d, 0.3640827d, 0.3598329d, -0.1659369d, -0.1481651d, -0.2077971d, -0.4401419d, -0.4080724d, -0.390809d};

    private static int COUNTER = 0;
    private static final double INTERCEPT = COEF[COUNTER++];

    private static final double POSSESSION_OUTCOME_SHOOTING_FOUL_RECEIVED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_SHOT_MISSED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TECH_FOUL_CONCEDED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_THREE_POINTS_SCORED = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TIME_OUT = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TURNOVER = COEF[COUNTER++];
    private static final double POSSESSION_OUTCOME_TWO_POINTS_SCORED = COEF[COUNTER++];

    private static final double[] LESS_THAN_THIRTY_FIVE_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LESS_THAN_TWENTY_FOUR_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LESS_THAN_TEN_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};
    private static final double[] LESS_THAN_FIVE_SECONDS_INTERACTION_QUARTER = {COEF[COUNTER++], COEF[COUNTER++], COEF[COUNTER++]};

    public boolean isSuccess(T gameState, PossessionOutcome possessionOutcome) {
        return Rdists.uniform() < getProbability(gameState, possessionOutcome);
    }

    public double getProbability(T gameState, PossessionOutcome possessionOutcome) {
        int quarter = gameState.getPeriod();
        int endTime = gameState.getSecondsRemainingInPeriod();
        boolean threePointsScored = false;
        boolean shotMissed = false;
        boolean twoPointsScored = false;
        boolean turnover = false;
        boolean shootingFoulReceived = false;
        boolean timeOut = false;

        if (possessionOutcome == PossessionOutcome.THREE_POINTS_SCORED) {
            threePointsScored = true;
        } else if (possessionOutcome == PossessionOutcome.SHOT_MISSED) {
            shotMissed = true;
        } else if (possessionOutcome == PossessionOutcome.TWO_POINTS_SCORED) {
            twoPointsScored = true;
        } else if (possessionOutcome == PossessionOutcome.TURNOVER) {
            turnover = true;
        } else if (possessionOutcome == PossessionOutcome.SHOOTING_FOUL_RECEIVED) {
            shootingFoulReceived = true;
        } else if (possessionOutcome == PossessionOutcome.TIME_OUT) {
            timeOut = true;
        }

        boolean techFoul = false;//TODO add techFoul
        return getProbability(endTime, quarter, threePointsScored, shotMissed, techFoul, twoPointsScored, turnover, shootingFoulReceived, timeOut);

    }

    public static double getProbability(double endTime, int quarter, boolean threePointsScored, boolean shotMissed, boolean techFoul, boolean twoPointsScored, boolean turnover, boolean shootingFoulReceived, boolean timeOut) {
        double exp = MathRnD.fastExp(INTERCEPT + getPossessionCoef(threePointsScored, shotMissed, techFoul, twoPointsScored, turnover, shootingFoulReceived, timeOut) +//
                FastMath.min(endTime - 35, 0) * LESS_THAN_THIRTY_FIVE_SECONDS_INTERACTION_QUARTER[quarter - 1] +//
                FastMath.min(endTime - 24, 0) * LESS_THAN_TWENTY_FOUR_SECONDS_INTERACTION_QUARTER[quarter - 1] +//
                FastMath.min(endTime - 10, 0) * LESS_THAN_TEN_SECONDS_INTERACTION_QUARTER[quarter - 1] +//
                FastMath.min(endTime - 5, 0) * LESS_THAN_FIVE_SECONDS_INTERACTION_QUARTER[quarter - 1]);//

        return exp / (1 + exp);
    }

    private static double getPossessionCoef(boolean threePointsScored, boolean shotMissed, boolean techFoul, boolean twoPointsScored, boolean turnover, boolean shootingFoulReceived, boolean timeOut) {
        if (threePointsScored) {
            return POSSESSION_OUTCOME_THREE_POINTS_SCORED;
        } else if (shotMissed) {
            return POSSESSION_OUTCOME_SHOT_MISSED;
        } else if (techFoul) {
            return POSSESSION_OUTCOME_TECH_FOUL_CONCEDED;
        } else if (twoPointsScored) {
            return POSSESSION_OUTCOME_TWO_POINTS_SCORED;
        } else if (turnover) {
            return POSSESSION_OUTCOME_TURNOVER;
        } else if (shootingFoulReceived) {
            return POSSESSION_OUTCOME_SHOOTING_FOUL_RECEIVED;
        } else if (timeOut) {
            return POSSESSION_OUTCOME_TIME_OUT;
        } else {
            return 0;
        }
    }

}
