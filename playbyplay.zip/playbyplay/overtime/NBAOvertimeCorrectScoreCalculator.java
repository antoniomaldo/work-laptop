package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.overtime;

import org.apache.commons.math3.util.FastMath;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.overtime.OvertimeCorrectScoreCalculator;
import com.williamhill.trading.framework.math.common.collections.Pair;

public class NBAOvertimeCorrectScoreCalculator extends OvertimeCorrectScoreCalculator {

    @Override
    protected double getLambda1(double homeOtScorePred) {
        return FastMath.exp(1.13845423 + 0.10507017 * homeOtScorePred);
    }

    @Override
    protected double getLambda2(double awayOtScorePred) {
        return FastMath.exp(1.01544184 + 0.11649648 * awayOtScorePred);
    }

    @Override
    protected double getLambda3(double matchSpread) {
        return FastMath.exp(0.22121255 + 0.01866295 * matchSpread);
    }

    @Override
    protected double getP() {
        return 0.06119806;
    }

    @Override
    protected double getTheta() {
        return 8.38520590;
    }

    @Override
    protected Pair<Double, Double> getTeamsPredictedOtPoints(double matchSpread, double totalPoints) {
        double otPredTotalPoints = FastMath.exp(1.908860 + totalPoints * 0.005465);
        double otPredSpread = -0.55642 + matchSpread * 0.16727;

        double homeOtScorePred = (otPredTotalPoints - otPredSpread) / 2;
        double awayOtScorePred = otPredTotalPoints - homeOtScorePred;

        return Pair.of(homeOtScorePred, awayOtScorePred);
    }
}
