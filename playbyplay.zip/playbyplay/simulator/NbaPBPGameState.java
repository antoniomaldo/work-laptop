package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator;

import java.util.Map;
import java.util.Optional;

import com.williamhill.rnd.basketball.domain.event.BasketballEventDetails;
import com.williamhill.rnd.basketball.domain.event.Opinion;
import com.williamhill.rnd.basketball.domain.event.PointsOccurrence;
import com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncident;
import com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentHistory;
import com.williamhill.rnd.basketball.domain.event.incidents.BasketballSimulationIncidentHistory;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.FortyEightMinuteMatchActualTimeConstants;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.FreeThrowsState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.IScores;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.LastTimeOutDetails;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.QuarterFouls;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.QuarterScores;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.QuarterTimeOuts;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.RaceToXResults;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.TeamHalfPointsExpectancies;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.QuarterBasedPBPGameState;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.QuarterBasedPBPGameStatistics;
import com.williamhill.trading.framework.domain.team.event.Team;
import com.williamhill.trading.framework.math.common.probability.CorrectScoreProbabilityTable;
import com.williamhill.trading.rnd.frameworks.model.api.market.enums.SelectionType;

public class NbaPBPGameState extends QuarterBasedPBPGameState<QuarterBasedPBPGameStatistics> {

    public NbaPBPGameState(BasketballEventDetails eventDetails, Opinion opinion, int secondsElapsed, QuarterScores scores, Team teamInPossession, Optional<Team> tipOffWinner, FreeThrowsState homeFreeThrowsState, FreeThrowsState awayFreeThrowsState, QuarterTimeOuts timeOuts, QuarterFouls fouls, BasketballIncidentHistory<BasketballIncident> incidentHistory, TeamHalfPointsExpectancies teamHalfPointsExpectancies, CorrectScoreProbabilityTable<PointsOccurrence> overtimeCorrectScoreProbabilityTable, LastTimeOutDetails lastTimeOutDetails, RaceToXResults raceToXResults, BasketballIncident lastIncident, BasketballSimulationIncidentHistory simulationIncidentHistory, boolean isAfterEndOfRegulationTime, Map<SelectionType, Double> moneyLineProbs) {
        super(eventDetails, opinion, secondsElapsed, scores, teamInPossession, timeOuts, fouls, tipOffWinner, homeFreeThrowsState, awayFreeThrowsState, incidentHistory, teamHalfPointsExpectancies, overtimeCorrectScoreProbabilityTable, lastTimeOutDetails, raceToXResults, lastIncident, simulationIncidentHistory, isAfterEndOfRegulationTime, moneyLineProbs);
    }

    @Override
    protected int getTimeForEndOfOvertimePeriod() {
        return FortyEightMinuteMatchActualTimeConstants.FIFTY_THREE_MINUTES_IN_SECS;
    }

    @Override
    protected int getLengthOfRegulationPeriod() {
        return FortyEightMinuteMatchActualTimeConstants.TWELVE_MINUTES_IN_SECS;
    }

    @Override
    protected int getMinutesInMatch() {
        return FortyEightMinuteMatchActualTimeConstants.MINUTES_IN_MATCH;
    }


    @Override
    protected QuarterBasedPBPGameStatistics getGameStatistics(IScores scores, RaceToXResults raceToXResults, Map<SelectionType, Double> pmMoneyLineProbs) {
        return new QuarterBasedPBPGameStatistics(scores, raceToXResults, pmMoneyLineProbs);
    }
}
