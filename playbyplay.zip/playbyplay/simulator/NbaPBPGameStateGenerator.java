package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator;

import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.FT_SCORED_AWAY;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.FT_SCORED_AWAY_CANCELLED;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.FT_SCORED_HOME;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.FT_SCORED_HOME_CANCELLED;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.THREE_PTS_AWAY;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.THREE_PTS_AWAY_CANCELLED;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.THREE_PTS_HOME;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.THREE_PTS_HOME_CANCELLED;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.TIMEOUT_AWAY;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.TIMEOUT_HOME;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.TWO_PTS_AWAY;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.TWO_PTS_AWAY_CANCELLED;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.TWO_PTS_HOME;
import static com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentType.TWO_PTS_HOME_CANCELLED;

import java.util.Collections;
import java.util.stream.Collectors;

import com.williamhill.rnd.basketball.domain.event.BasketballEvent;
import com.williamhill.rnd.basketball.domain.event.BasketballGameTime;
import com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncident;
import com.williamhill.rnd.basketball.domain.event.incidents.BasketballIncidentHistory;
import com.williamhill.rnd.basketball.domain.event.period.BasketballPeriod;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.LastTimeOutDetails;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.overtime.OvertimeCorrectScoreCalculator;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.QuarterBasedPBPGameStateGenerator;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.SimulationGameTime;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.overtime.NBAOvertimeCorrectScoreCalculator;
import com.williamhill.trading.framework.model.goalexpectancy.dao.GoalsExpectancyDao;

public class NbaPBPGameStateGenerator extends QuarterBasedPBPGameStateGenerator<NbaPBPGameState> {

    private static final OvertimeCorrectScoreCalculator NBA_OVERTIME_CORRECT_SCORE_CALCULATOR = new NBAOvertimeCorrectScoreCalculator();

    public NbaPBPGameStateGenerator(BasketballEvent event, GoalsExpectancyDao goalsExpectancyDao) {
        super(event, goalsExpectancyDao);
    }

    @Override
    public NbaPBPGameState generate() {
        return new NbaPBPGameState(this.eventDetails, this.opinion, this.secondsElapsed, scores(), this.teamInPossession, this.tipOffWinner, this.homeFreeThrowsState, this.awayFreeThrowsState, timeOuts(), fouls(), this.incidentHistory, this.teamHalfPointsExpectancies, this.overtimeCorrectScoreProbabilityTable, this.lastTimeOutDetails, this.raceToXResults, this.lastIncident, this.simulationIncidentHistory, this.isAfterEndOfRegulationTime, this.moneyLineProbs);
    }

    @Override
    protected LastTimeOutDetails getLastTimeOutDetails(BasketballEvent event) {
        BasketballIncidentHistory<BasketballIncident> allIncidentHistory = event.getAllIncidentHistory();

        BasketballIncident lastHomeTimeOutIncident = allIncidentHistory.getLastIncidentOfTypesInPeriod(Collections.singletonList(TIMEOUT_HOME), event.getCurrentBasketballPeriod());
        BasketballIncident lastAwayTimeOutIncident = allIncidentHistory.getLastIncidentOfTypesInPeriod(Collections.singletonList(TIMEOUT_AWAY), event.getCurrentBasketballPeriod());

        BasketballGameTime lastHomeTimeOutGameTime;
        BasketballGameTime lastAwayTimeOutGameTime;

        BasketballPeriod currentBasketballPeriod = event.getCurrentBasketballPeriod();
        int gameSeconds = currentBasketballPeriod.isOvertime() ? 300 : 720;

        if (lastHomeTimeOutIncident == null) {
            lastHomeTimeOutGameTime = new BasketballGameTime(currentBasketballPeriod, gameSeconds);
        } else {
            lastHomeTimeOutGameTime = lastHomeTimeOutIncident.getGameTime();
        }
        if (lastAwayTimeOutIncident == null) {
            lastAwayTimeOutGameTime = new BasketballGameTime(currentBasketballPeriod, gameSeconds);
        } else {
            lastAwayTimeOutGameTime = lastAwayTimeOutIncident.getGameTime();
        }

        BasketballGameTime latestTimeOutIncidentGameTime = lastAwayTimeOutGameTime.isAfter(lastHomeTimeOutGameTime) ? lastAwayTimeOutGameTime : lastHomeTimeOutGameTime;

        BasketballIncidentHistory<BasketballIncident> incidentsBeforeTimeOut = new BasketballIncidentHistory<>(allIncidentHistory.stream().filter(i->i.getGameTime().isAfter(latestTimeOutIncidentGameTime)).collect(Collectors.toList()));

        int homeScoreLastTimeOut = getScoreFromIncidents(incidentsBeforeTimeOut, FT_SCORED_HOME, FT_SCORED_HOME_CANCELLED, TWO_PTS_HOME, TWO_PTS_HOME_CANCELLED, THREE_PTS_HOME, THREE_PTS_HOME_CANCELLED);
        int awayScoreLastTimeOut = getScoreFromIncidents(incidentsBeforeTimeOut, FT_SCORED_AWAY, FT_SCORED_AWAY_CANCELLED, TWO_PTS_AWAY, TWO_PTS_AWAY_CANCELLED, THREE_PTS_AWAY, THREE_PTS_AWAY_CANCELLED);

        return new LastTimeOutDetails(toSim(lastHomeTimeOutGameTime), toSim(lastAwayTimeOutGameTime), homeScoreLastTimeOut, awayScoreLastTimeOut);
    }

    private SimulationGameTime toSim(BasketballGameTime gameTime) {
        return new SimulationGameTime(gameTime.getBasketballPeriod().getModelInt(), gameTime.getGameSeconds());
    }
}
