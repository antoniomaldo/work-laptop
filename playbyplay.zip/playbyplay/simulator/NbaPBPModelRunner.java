package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator;

import java.util.Collection;

import com.williamhill.rnd.basketball.domain.event.BasketballEvent;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.BasketballQuartersPBPAggregatedSimulationResults;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.BasketballQuartersPBPGameStatisticsContainer;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.QuarterBasedPBPGameStatistics;
import com.williamhill.trading.framework.math.common.simulationframework.GameSimulator;
import com.williamhill.trading.framework.math.common.simulationframework.IModelResultsCollectionFactory;
import com.williamhill.trading.framework.math.common.simulationframework.ModelRunnerProperties;
import com.williamhill.trading.framework.math.common.simulationframework.ParallelModelRunner;
import com.williamhill.trading.framework.model.goalexpectancy.dao.GoalsExpectancyDao;

public class NbaPBPModelRunner extends ParallelModelRunner<BasketballQuartersPBPAggregatedSimulationResults, NbaPBPGameState, QuarterBasedPBPGameStatistics, BasketballQuartersPBPGameStatisticsContainer> {

    private static final ModelRunnerProperties DEFAULT = ModelRunnerProperties.builder().withTimeOutInSeconds(60).withNumberOfSimulations(40000).build();

    private final GoalsExpectancyDao nbaGoalExpectancyDao;

    public NbaPBPModelRunner(GameSimulator<NbaPBPGameState, QuarterBasedPBPGameStatistics> gameSimulator, GoalsExpectancyDao nbaGoalExpectancyDao) {

        super(gameSimulator, new IModelResultsCollectionFactory<BasketballQuartersPBPGameStatisticsContainer>() {
            @Override
            public BasketballQuartersPBPGameStatisticsContainer newCollection(int i) {
                return new BasketballQuartersPBPGameStatisticsContainer(i);
            }

            @Override
            public BasketballQuartersPBPGameStatisticsContainer combine(Collection<BasketballQuartersPBPGameStatisticsContainer> collection) {
                return new BasketballQuartersPBPGameStatisticsContainer(collection);
            }
        }, DEFAULT);
        this.nbaGoalExpectancyDao = nbaGoalExpectancyDao;
    }

    public BasketballQuartersPBPAggregatedSimulationResults process(BasketballEvent event) {
        ModelRunnerProperties modelRunnerProperties = ModelRunnerProperties.builder().withTimeOutInSeconds(60).withNumberOfSimulations(event.getNumberOfSimulations()).build();
        return process(event, modelRunnerProperties);
    }

    public BasketballQuartersPBPAggregatedSimulationResults process(BasketballEvent event, ModelRunnerProperties modelRunnerProperties) {
        NbaPBPGameStateGenerator nbaGameStateGenerator = new NbaPBPGameStateGenerator(event, this.nbaGoalExpectancyDao);
        return runSimulations(nbaGameStateGenerator, modelRunnerProperties);
    }
}
