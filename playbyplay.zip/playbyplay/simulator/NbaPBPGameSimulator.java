package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.simulator;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.FreeThrowPBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPDurationModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPLastPossessionModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.PBPProbabilityModel;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.BasketballPBPGameSimulator;
import com.williamhill.rnd.basketball.domain.model.common.playbyplay.simulator.QuarterBasedPBPGameStatistics;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.changepossession.NBApbpDurationChangePossessionModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.deffensivefoul.nonzeroduration.NBApbpDurationDefensiveFoulReceivedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.deffensivefoul.zeroduration.NBApbpDurationZeroDefensiveFoulReceivedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shootingfoul.nonzeroduration.NBApbpDurationShootingFoulReceivedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.shootingfoul.zeroduration.NBApbpDurationZeroShootingFoulReceivedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.threepoints.NBApbpDurationThreePointsScoredModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.timeout.NBApbpDurationTimeoutModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.timeout.NBApbpDurationZeroTimeoutModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.duration.twopoints.NBApbpDurationTwoPointsModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.lastpossession.NBApbpLastPossessionEndTimeModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.changepossession.NBApbpChangeOfPossessionModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.changepossession.NBApbpTurnoverOrShotMissedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.deffensivefoul.NBApbpDefensiveFoulReceivedModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.freethrowsuccess.NBApbpFreeThrowSuccessModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.threepoints.NBApbpAdditionalFTAfterThreePointerModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.threepoints.NBApbpThreePointsScoredModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.timeout.NBApbpTimeOutModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.twopoints.NBApbpAdditionalFTAfterTwoPointerModel;
import com.williamhill.rnd.basketball.domain.model.nba.playbyplay.outcome.twopoints.NBApbpTwoPointsScoredModel;
import com.williamhill.trading.framework.domain.team.event.Team;

public class NbaPBPGameSimulator extends BasketballPBPGameSimulator<NbaPBPGameState, QuarterBasedPBPGameStatistics> {

    private static final PBPProbabilityModel<NbaPBPGameState> CHANGE_OF_POSSESSION_MODEL = new NBApbpChangeOfPossessionModel();
    private static final PBPProbabilityModel<NbaPBPGameState> TURNOVER_OR_SHOT_MISSED_MODEL = new NBApbpTurnoverOrShotMissedModel();
    private static final PBPProbabilityModel<NbaPBPGameState> DEFENSIVE_FOUL_RECEIVED_MODEL = new NBApbpDefensiveFoulReceivedModel();
    private static final FreeThrowPBPProbabilityModel<NbaPBPGameState> FREE_THROW_SUCCESS_MODEL = new NBApbpFreeThrowSuccessModel();
    private static final PBPProbabilityModel<NbaPBPGameState> THREE_POINTS_SCORED_MODEL = new NBApbpThreePointsScoredModel();
    private static final FreeThrowPBPProbabilityModel<NbaPBPGameState> FREE_THROW_AFTER_THREE_POINT_MODEL = new NBApbpAdditionalFTAfterThreePointerModel();
    private static final PBPProbabilityModel<NbaPBPGameState> TIME_OUT_MODEL = new NBApbpTimeOutModel();
    private static final PBPProbabilityModel<NbaPBPGameState> TWO_POINTS_SCORED_MODEL = new NBApbpTwoPointsScoredModel();
    private static final FreeThrowPBPProbabilityModel<NbaPBPGameState> FREE_THROW_AFTER_TWO_POINT_MODEL = new NBApbpAdditionalFTAfterTwoPointerModel();

    private static final PBPDurationModel<NbaPBPGameState> CHANGE_OF_POSSESSION_DURATION_MODEL = new NBApbpDurationChangePossessionModel();
    private static final PBPDurationModel<NbaPBPGameState> DEFENSIVE_FOUL_RECEIVED_NON_ZERO_DURATION_MODEL = new NBApbpDurationDefensiveFoulReceivedModel();
    private static final PBPProbabilityModel<NbaPBPGameState> DEFENSIVE_FOUL_RECEIVED_ZERO_DURATION_MODEL = new NBApbpDurationZeroDefensiveFoulReceivedModel();
    private static final PBPDurationModel<NbaPBPGameState> SHOOTING_FOUL_RECEIVED_NON_ZERO_DURATION_MODEL = new NBApbpDurationShootingFoulReceivedModel();
    private static final PBPProbabilityModel<NbaPBPGameState> SHOOTING_FOUL_RECEIVED_ZERO_DURATION_MODEL = new NBApbpDurationZeroShootingFoulReceivedModel();
    private static final PBPDurationModel<NbaPBPGameState> THREE_POINTS_DURATION_MODEL = new NBApbpDurationThreePointsScoredModel();
    private static final PBPDurationModel<NbaPBPGameState> TIME_OUT_NON_ZERO_DURATION_MODEL = new NBApbpDurationTimeoutModel();
    private static final PBPProbabilityModel<NbaPBPGameState> TIME_OUT_ZERO_DURATION_MODEL = new NBApbpDurationZeroTimeoutModel();
    private static final PBPDurationModel<NbaPBPGameState> TWO_POINTS_DURATION_MODEL = new NBApbpDurationTwoPointsModel();

    private static final PBPLastPossessionModel<NbaPBPGameState> LAST_POSSESSION_MODEL = new NBApbpLastPossessionEndTimeModel();
//    private static final PBPLastPossessionModel<NbaPBPGameState> LAST_POSSESSION_MODEL = new NBApbpLastPossessionEndTimeGBMModel();

    public NbaPBPGameSimulator() {
        super(CHANGE_OF_POSSESSION_MODEL, TURNOVER_OR_SHOT_MISSED_MODEL, DEFENSIVE_FOUL_RECEIVED_MODEL, //
                FREE_THROW_SUCCESS_MODEL, THREE_POINTS_SCORED_MODEL, FREE_THROW_AFTER_THREE_POINT_MODEL, TIME_OUT_MODEL, TWO_POINTS_SCORED_MODEL, //
                FREE_THROW_AFTER_TWO_POINT_MODEL, CHANGE_OF_POSSESSION_DURATION_MODEL, DEFENSIVE_FOUL_RECEIVED_NON_ZERO_DURATION_MODEL, //
                DEFENSIVE_FOUL_RECEIVED_ZERO_DURATION_MODEL, SHOOTING_FOUL_RECEIVED_NON_ZERO_DURATION_MODEL, SHOOTING_FOUL_RECEIVED_ZERO_DURATION_MODEL, THREE_POINTS_DURATION_MODEL, //
                TIME_OUT_NON_ZERO_DURATION_MODEL, TIME_OUT_ZERO_DURATION_MODEL, TWO_POINTS_DURATION_MODEL, LAST_POSSESSION_MODEL);
    }

    @Override
    protected void simulateFreeThrowForEventType(NbaPBPGameState gameState, Team team) {
        if (isOppTeamInBonus(gameState, team)) {
            simulateFreeThrow(gameState, team, 2);
        }
    }
}
