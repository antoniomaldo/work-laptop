package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.gmbpredictions;

class NBASingleLastPossessionPrediction {

    private final String combinedPredString;
    private final double prediction;

    NBASingleLastPossessionPrediction(String csvRow) {
        String[] split = csvRow.split(",");
        this.combinedPredString = split[0] + "-" + split[1] + "-" + split[2];
        this.prediction = Double.parseDouble(split[3]);
    }

    public String getCombinedPredString() {
        return this.combinedPredString;
    }

    double getPrediction() {
        return this.prediction;
    }
}
