package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.gmbpredictions;

import com.williamhill.rnd.basketball.domain.model.common.playbyplay.BaseGBMPrediction;

public class NBAGBMPrediction extends BaseGBMPrediction {

    public NBAGBMPrediction(String resourcePath) {
        super(resourcePath);
    }

    public static NBAGBMPrediction forChangeOfPossession() {
        return new NBAGBMPrediction("nba-gbm-predictions/outcome/change-possession.csv.gz");
    }
}
