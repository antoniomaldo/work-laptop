package com.williamhill.rnd.basketball.domain.model.nba.playbyplay.gmbpredictions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.stream.Collectors;

import com.williamhill.trading.framework.model.factory.GzipEnabledResourceLoader;

public class NBAGBMLastPossessionPrediction {

    private final Map<String, Double> predictionsMap;

    public NBAGBMLastPossessionPrediction() {
        String resourcePath = "ncaa-gbm-predictions/lastpossession/last-possession.csv.gz";
        BufferedReader csvFile;
        try {
            csvFile = new BufferedReader(new InputStreamReader(new GzipEnabledResourceLoader().getResource(resourcePath).getInputStream()));
        } catch (IOException e) {
            throw new RuntimeException("Failed to load csv for resource: " + resourcePath);
        }
        this.predictionsMap = csvFile.lines().skip(1).map(NBASingleLastPossessionPrediction::new).
                collect(Collectors.toMap(NBASingleLastPossessionPrediction::getCombinedPredString, NBASingleLastPossessionPrediction::getPrediction));
    }

    public double getPrediction(int timeRemInMatch, int ownScoreDiffOrDefFoulsReceived, String possessionOutcome) {
        ownScoreDiffOrDefFoulsReceived = ownScoreDiffOrDefFoulsReceived < -40 ? -40 : ownScoreDiffOrDefFoulsReceived > 40 ? 40 : ownScoreDiffOrDefFoulsReceived;

        return this.predictionsMap.get(timeRemInMatch + "-" + ownScoreDiffOrDefFoulsReceived + "-\"" + possessionOutcome + "\"");
    }

}
